#!/usr/bin/env bash
#
# self-test.sh —— 验收自测：确保服务在运行 → 执行并发 20 / 10 秒压测 → 校验 QPS/P95/P99/错误率。
#
# 退出码 0 表示通过；日志写入 logs/self-test-<时间戳>.log。
#
# 可用环境变量覆盖默认参数：
#   SELF_TEST_CONCURRENCY=20   SELF_TEST_DURATION=10   SELF_TEST_URL=http://127.0.0.1:8801/sample
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${SELF_TEST_PORT:-${PORT:-8801}}"
NODE_BIN="${NODE_BIN:-node}"
LOG_DIR="$DIR/logs"
mkdir -p "$LOG_DIR"

STAMP="$(date +%Y%m%d-%H%M%S)"
LOG_FILE="$LOG_DIR/self-test-$STAMP.log"

export SELF_TEST_PORT="$PORT"
export SELF_TEST_CONCURRENCY="${SELF_TEST_CONCURRENCY:-20}"
export SELF_TEST_DURATION="${SELF_TEST_DURATION:-10}"
export SELF_TEST_URL="${SELF_TEST_URL:-http://127.0.0.1:$PORT/sample}"

echo "[self-test] 日志文件：$LOG_FILE"

# 服务未运行则自动启动
if ! "$NODE_BIN" -e "fetch('http://127.0.0.1:${PORT}/api/health').then(r=>process.exit(r.ok?0:1)).catch(()=>process.exit(1))" >/dev/null 2>&1; then
  echo "[self-test] 服务未运行，执行 ./start.sh 启动…"
  "$DIR/start.sh" >/dev/null
  sleep 1
fi

set +e
"$NODE_BIN" "$DIR/tests/self-test.js" 2>&1 | tee "$LOG_FILE"
CODE=${PIPESTATUS[0]}
set -e

echo "[self-test] 完成，退出码 ${CODE}，日志：${LOG_FILE}"
exit "$CODE"
