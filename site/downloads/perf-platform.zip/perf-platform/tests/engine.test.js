'use strict';
/**
 * tests/engine.test.js —— 压测引擎单元测试：请求头归一化、失败口径与错误信息、
 * 硬超时（P1-1）、停止即中止在途请求（P1-2）。
 * 零第三方依赖，仅使用 Node 标准库（node:test / node:http）。
 */

const test = require('node:test');
const assert = require('node:assert');
const http = require('node:http');

const { buildHeaders, performRequest, RunEngine } = require('../server/engine');
const { MetricsAggregator } = require('../server/metrics');

/** 启动一个一次性本地服务，返回指定状态码 */
function startServer(handler) {
  return new Promise((resolve) => {
    const server = http.createServer(handler);
    server.listen(0, '127.0.0.1', () => {
      resolve({ server, port: server.address().port });
    });
  });
}

/** 滴流服务器：保持连接并持续吐数据，socket 永不空闲 */
function startTrickleServer(intervalMs = 50) {
  return startServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    const timer = setInterval(() => res.write('x'), intervalMs);
    res.on('close', () => clearInterval(timer));
  });
}

test('buildHeaders：保留头（Host / Content-Length / Connection）由引擎接管，不被用户覆盖', () => {
  const headers = buildHeaders([
    { name: 'Host', value: 'evil.example.com' },
    { name: 'content-length', value: '999' },
    { name: 'Connection', value: 'keep-alive' },
    { name: 'X-Test', value: '1' },
  ]);

  assert.strictEqual(headers['Host'], undefined);
  assert.strictEqual(headers['host'], undefined);
  assert.strictEqual(headers['content-length'], undefined);
  assert.strictEqual(headers['Content-Length'], undefined);
  assert.strictEqual(headers['Connection'], 'close');
  assert.strictEqual(headers['X-Test'], '1');
  assert.ok(headers['User-Agent']);
  assert.ok(headers['Accept']);
});

test('buildHeaders：同名不同大小写的自定义头只保留一个（后写覆盖先写）', () => {
  const headers = buildHeaders([
    { name: 'X-Token', value: 'a' },
    { name: 'x-token', value: 'b' },
  ]);
  const tokenKeys = Object.keys(headers).filter((k) => k.toLowerCase() === 'x-token');
  assert.strictEqual(tokenKeys.length, 1);
  assert.strictEqual(headers[tokenKeys[0]], 'b');
});

test('performRequest：状态码 >= 400 记 http_error 失败并带错误信息', async () => {
  const { server, port } = await startServer((req, res) => {
    res.writeHead(503, { 'Content-Type': 'text/plain' });
    res.end('busy');
  });

  try {
    const result = await performRequest({
      url: `http://127.0.0.1:${port}/x`,
      method: 'GET',
      headers: [],
      body: '',
      timeoutMs: 5000,
    });
    assert.strictEqual(result.statusCode, 503);
    assert.strictEqual(result.errorType, 'http_error');
    assert.ok(result.errorMessage && result.errorMessage.includes('503'));
    assert.ok(result.latencyMs >= 0);
  } finally {
    server.close();
  }
});

test('performRequest：3xx 不跟随，原样返回状态码且不算失败', async () => {
  const { server, port } = await startServer((req, res) => {
    res.writeHead(302, { Location: '/elsewhere' });
    res.end();
  });

  try {
    const result = await performRequest({
      url: `http://127.0.0.1:${port}/x`,
      method: 'GET',
      headers: [],
      body: '',
      timeoutMs: 5000,
    });
    assert.strictEqual(result.statusCode, 302);
    assert.strictEqual(result.errorType, null);
    assert.strictEqual(result.errorMessage, null);
  } finally {
    server.close();
  }
});

test('performRequest：连接失败记 network_error 失败并带错误信息', async () => {
  // 先占用一个端口再释放，确保该端口无人监听 → 连接被拒绝
  const { server, port } = await startServer((req, res) => res.end('ok'));
  await new Promise((resolve) => server.close(resolve));

  const result = await performRequest({
    url: `http://127.0.0.1:${port}/x`,
    method: 'GET',
    headers: [],
    body: '',
    timeoutMs: 3000,
  });
  assert.strictEqual(result.statusCode, null);
  assert.strictEqual(result.errorType, 'network_error');
  assert.ok(result.errorMessage && result.errorMessage.length > 0);
});

test('performRequest：超时记 network_error 失败', async () => {
  const { server, port } = await startServer(() => {
    // 永不响应 → 触发单请求超时
  });

  try {
    const result = await performRequest({
      url: `http://127.0.0.1:${port}/slow`,
      method: 'GET',
      headers: [],
      body: '',
      timeoutMs: 300,
    });
    assert.strictEqual(result.statusCode, null);
    assert.strictEqual(result.errorType, 'network_error');
    assert.ok(result.errorMessage && result.errorMessage.includes('超时'));
  } finally {
    server.close();
    server.closeAllConnections && server.closeAllConnections();
  }
});

// ---------------------------------------------------------------------------
// P1-1：硬超时 —— 目标持续吐数据时，请求也必须在 timeoutMs 内结算
// ---------------------------------------------------------------------------

test('P1-1 硬超时：目标持续滴流时，请求仍在 timeoutMs 内超时结算', async () => {
  const { server, port } = await startTrickleServer(40);

  try {
    const startedAt = Date.now();
    const result = await performRequest({
      url: `http://127.0.0.1:${port}/trickle`,
      method: 'GET',
      headers: [],
      body: '',
      timeoutMs: 600,
    });
    const elapsed = Date.now() - startedAt;

    assert.strictEqual(result.statusCode, null);
    assert.strictEqual(result.errorType, 'network_error');
    assert.ok(result.errorMessage && result.errorMessage.includes('超时'), `错误信息应含「超时」：${result.errorMessage}`);
    assert.ok(elapsed < 2000, `滴流目标下也应按硬超时结算，实际耗时 ${elapsed}ms`);
    assert.ok(result.latencyMs <= 1200, `上报延迟应贴近超时值，实际 ${result.latencyMs}ms`);
  } finally {
    server.close();
    server.closeAllConnections && server.closeAllConnections();
  }
});

test('P1-1 硬超时：滴流目标的单次请求耗时不超过 timeoutMs 的两倍', async () => {
  const { server, port } = await startTrickleServer(30);

  try {
    const startedAt = Date.now();
    await performRequest({
      url: `http://127.0.0.1:${port}/trickle`,
      method: 'GET',
      headers: [],
      body: '',
      timeoutMs: 500,
    });
    const elapsed = Date.now() - startedAt;
    assert.ok(elapsed <= 1500, `实际耗时 ${elapsed}ms 应受 timeoutMs=500 约束`);
  } finally {
    server.close();
    server.closeAllConnections && server.closeAllConnections();
  }
});

// ---------------------------------------------------------------------------
// P1-2：停止压测 —— 在途请求被立即中止，运行及时收尾
// ---------------------------------------------------------------------------

test('P1-2 停止：中止信号触发后请求立即以 aborted 结算', async () => {
  const { server, port } = await startTrickleServer(50);
  const controller = new AbortController();

  try {
    const pending = performRequest({
      url: `http://127.0.0.1:${port}/trickle`,
      method: 'GET',
      headers: [],
      body: '',
      timeoutMs: 30000,
      signal: controller.signal,
    });

    setTimeout(() => controller.abort(), 200);
    const startedAt = Date.now();
    const result = await pending;
    const elapsed = Date.now() - startedAt;

    assert.strictEqual(result.errorType, 'aborted');
    assert.strictEqual(result.statusCode, null);
    assert.ok(elapsed < 3000, `中止应立即生效，实际耗时 ${elapsed}ms`);
  } finally {
    server.close();
    server.closeAllConnections && server.closeAllConnections();
  }
});

test('P1-2 停止：RunEngine.stop() 后运行立即收尾且状态为 stopped', async () => {
  const { server, port } = await startTrickleServer(50);
  const metrics = new MetricsAggregator(Date.now());
  const run = { id: 'run_test', status: 'running', startedAt: Date.now() };
  let finished = null;

  const engine = new RunEngine({
    task: {
      url: `http://127.0.0.1:${port}/trickle`,
      method: 'GET',
      headers: [],
      body: '',
      timeoutMs: 30000,
      concurrency: 3,
      durationSec: 60,
    },
    run,
    metrics,
    onFinish: (r) => { finished = r; },
  });

  try {
    const done = engine.start();
    await new Promise((resolve) => setTimeout(resolve, 600));

    const stopAt = Date.now();
    engine.stop('手动停止');
    await done;
    const stopElapsed = Date.now() - stopAt;

    assert.ok(finished, '应触发 onFinish 回调');
    assert.strictEqual(finished.status, 'stopped');
    assert.strictEqual(finished.stopReason, '手动停止');
    assert.ok(stopElapsed < 3000, `停止应收尾及时，实际 ${stopElapsed}ms`);

    const report = metrics.snapshot();
    assert.strictEqual(report.aborted, 3, '3 个在途请求应被中止');
    assert.strictEqual(report.total, 0, '被中止的请求不计入总请求数');
    assert.strictEqual(report.failed, 0, '被中止的请求不计为失败');
  } finally {
    server.close();
    server.closeAllConnections && server.closeAllConnections();
  }
});
