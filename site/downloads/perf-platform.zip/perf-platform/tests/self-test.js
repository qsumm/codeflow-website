'use strict';
/**
 * tests/self-test.js —— 验收自测（由 self-test.sh 调用）。
 *
 * 流程：健康检查 → 首页可访问 → 创建任务（默认并发 20 / 10 秒 / 目标 /sample）
 *       → 发起运行 → 轮询直至结束 → 断言 QPS / P95 / P99 / 错误率 / 状态码分布。
 *
 * 环境变量：
 *   SELF_TEST_PORT         默认 8801
 *   SELF_TEST_URL          默认 http://127.0.0.1:<port>/sample
 *   SELF_TEST_CONCURRENCY  默认 20
 *   SELF_TEST_DURATION     默认 10（秒）
 *   SELF_TEST_TIMEOUT      默认 180（秒，等待运行结束的墙钟超时）
 */

const PORT = process.env.SELF_TEST_PORT || process.env.PORT || '8801';
const BASE = `http://127.0.0.1:${PORT}`;
const TARGET_URL = process.env.SELF_TEST_URL || `${BASE}/sample`;
const CONCURRENCY = Number(process.env.SELF_TEST_CONCURRENCY || 20);
const DURATION = Number(process.env.SELF_TEST_DURATION || 10);
const TIMEOUT_MS = Number(process.env.SELF_TEST_TIMEOUT || 180) * 1000;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const results = [];

function log(msg) {
  process.stdout.write(`${msg}\n`);
}

function check(name, ok, detail = '') {
  results.push({ name, ok, detail });
  log(`  ${ok ? '✅' : '❌'} ${name}${detail ? ` —— ${detail}` : ''}`);
  return ok;
}

async function json(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  let payload = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }
  if (!res.ok) {
    const message = payload && payload.error ? payload.error.message : `HTTP ${res.status}`;
    const err = new Error(message);
    err.payload = payload;
    throw err;
  }
  return payload;
}

async function main() {
  log('==========================================');
  log(' 性能测试平台 · 验收自测');
  log('==========================================');
  log(`访问地址：${BASE}`);
  log(`压测目标：${TARGET_URL}`);
  log(`参数：并发 ${CONCURRENCY} / 持续 ${DURATION} 秒`);
  log('----------------------------------------------');

  // 1. 健康检查
  log('[1/5] 健康检查');
  let health = null;
  try {
    health = await json('/api/health');
  } catch (err) {
    log(`  ❌ 服务不可访问：${err.message}`);
    log('  请先执行 ./start.sh 启动服务后重试。');
    return 1;
  }
  check('GET /api/health 返回 ok', health.status === 'ok', `version=${health.version}`);

  // 2. 首页可访问
  log('[2/5] 首页可访问');
  const homeRes = await fetch(`${BASE}/`);
  const homeHtml = await homeRes.text();
  check('GET / 返回 200', homeRes.status === 200, `status=${homeRes.status}`);
  check('首页包含平台标题', homeHtml.includes('性能测试平台'));

  // 3. 创建任务
  log('[3/5] 创建压测任务');
  const taskData = await json('/api/tasks', {
    method: 'POST',
    body: {
      name: `自测任务 ${new Date().toISOString()}`,
      url: TARGET_URL,
      method: 'GET',
      concurrency: CONCURRENCY,
      durationSec: DURATION,
      timeoutMs: 10000,
      headers: [],
      body: '',
    },
  });
  const task = taskData.task;
  check('POST /api/tasks 创建成功', !!task && !!task.id, `id=${task && task.id}`);

  // 4. 发起运行并等待结束
  log('[4/5] 发起压测并等待结束…');
  const runData = await json('/api/runs', { method: 'POST', body: { taskId: task.id } });
  const runId = runData.run.id;
  check('POST /api/runs 发起成功', !!runId, `runId=${runId}`);

  const started = Date.now();
  let run = null;
  let live = null;
  while (Date.now() - started < TIMEOUT_MS) {
    await sleep(500);
    const data = await json(`/api/runs/${encodeURIComponent(runId)}`);
    run = data.run;
    live = run.report;
    if (run.status !== 'running') break;
  }
  if (!run) {
    check('运行结束状态可获取', false);
    return 1;
  }
  check('运行已结束', run.status !== 'running', `status=${run.status}, 用时 ${((Date.now() - started) / 1000).toFixed(1)}s`);
  check('运行状态为 completed', run.status === 'completed', `status=${run.status}`);

  // 5. 断言报告指标
  log('[5/5] 校验报告指标');
  const report = live || {};
  const latency = report.latency || {};
  check('总请求数 > 0', Number(report.total) > 0, `total=${report.total}`);
  check('QPS 存在且 > 0', Number.isFinite(Number(report.qps)) && Number(report.qps) > 0, `qps=${report.qps}`);
  check('TPS 存在且 > 0', Number.isFinite(Number(report.tps)) && Number(report.tps) > 0, `tps=${report.tps}`);
  check('P95 存在', latency.p95 !== null && latency.p95 !== undefined, `p95=${latency.p95}`);
  check('P99 存在', latency.p99 !== null && latency.p99 !== undefined, `p99=${latency.p99}`);
  check('平均延迟存在', latency.avg !== null && latency.avg !== undefined, `avg=${latency.avg}`);
  check('错误率存在', report.errorRate !== null && report.errorRate !== undefined, `errorRate=${report.errorRate}%`);
  check('错误率为 0%（样例页恒 200）', Number(report.errorRate) === 0, `errorRate=${report.errorRate}%`);
  const codes = (report.statusCodes || []).map((c) => c.code);
  check('状态码分布含 200', codes.includes('200'), `statusCodes=${codes.join(',') || '无'}`);
  check('每秒时间序列非空', Array.isArray(report.series) && report.series.length > 0, `点数=${(report.series || []).length}`);
  check('延迟直方图非空', Array.isArray(report.histogram) && report.histogram.length > 0);

  // 6. SSE 实时推送复核（对已完成运行补一次订阅，验证能收到 done 帧）
  let sawDone = false;
  try {
    const controller = new AbortController();
    const res = await fetch(`${BASE}/api/runs/${encodeURIComponent(runId)}/stream`, { signal: controller.signal });
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    const deadline = Date.now() + 8000;
    while (Date.now() < deadline) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      if (buffer.includes('event: done')) {
        sawDone = true;
        break;
      }
    }
    controller.abort();
  } catch {
    /* SSE 复核失败不作为致命错误 */
  }
  check('SSE 推送包含 done 结束帧', sawDone);

  // 7. 任务删除级联（清理自测数据）
  const del = await json(`/api/tasks/${encodeURIComponent(task.id)}`, { method: 'DELETE' });
  check('DELETE /api/tasks 级联删除历史报告', del.deleted === true, `removedRuns=${del.removedRuns}`);

  // ------------------------------------------------------------ 报告摘要
  log('----------------------------------------------');
  log('压测报告摘要');
  log(`  运行 ID      ：${runId}`);
  log(`  压测目标    ：${report.task ? report.task.url : TARGET_URL}`);
  log(`  压测时长    ：${report.durationSec} 秒`);
  log(`  总请求数    ：${report.total}`);
  log(`  成功 / 失败 ：${report.success} / ${report.failed}`);
  log(`  QPS / TPS   ：${report.qps} / ${report.tps}（成功 QPS ${report.successQps}）`);
  log(`  平均延迟    ：${latency.avg} ms`);
  log(`  P95 / P99   ：${latency.p95} ms / ${latency.p99} ms`);
  log(`  错误率      ：${report.errorRate}%`);
  log(`  状态码分布  ：${(report.statusCodes || []).map((c) => `${c.code}×${c.count}`).join('  ') || '无'}`);
  log('----------------------------------------------');

  const failed = results.filter((r) => !r.ok);
  log(`断言结果：${results.length - failed.length}/${results.length} 通过`);
  if (failed.length) {
    log('未通过断言：');
    for (const f of failed) log(`  - ${f.name}${f.detail ? `（${f.detail}）` : ''}`);
  }
  log(failed.length ? '自测结论：未通过' : '自测结论：通过 ✅');
  return failed.length ? 1 : 0;
}

main()
  .then((code) => process.exit(code))
  .catch((err) => {
    log(`自测执行异常：${err && err.stack ? err.stack : err}`);
    process.exit(1);
  });
