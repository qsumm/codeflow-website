'use strict';
/**
 * tests/frontend.test.js —— 前端逻辑回归测试（node:test 内置框架，零第三方依赖）。
 *
 * 背景：步骤 10000 复核出 18 项前端缺陷（F-01 ~ F-18），其中涉及**可判定规则**的部分
 * （刻度口径、末尾不满一秒的桶、SSE 流状态判定、空态判定）原先埋在 DOM 操作代码里，
 * 无法被自动化断言。本步骤把这些规则抽到 `web/lib/core.js`（纯函数），
 * 并用一套极简 DOM 桩把 `web/charts.js` 的 SVG 渲染也纳入自动化。
 *
 * 本文件同时被浏览器与 Node 使用同一份实现（`web/package.json` 声明 `"type": "module"`），
 * 因此测试的就是线上真实代码，而不是复制品。
 */

const test = require('node:test');
const assert = require('node:assert');

// ------------------------------------------------------------------ 极简 DOM 桩

const SVG_NS = 'http://www.w3.org/2000/svg';

class StubNode {
  constructor(tag, ns) {
    this.tagName = tag;
    this.namespaceURI = ns;
    this.attributes = new Map();
    this.childNodes = [];
    this.parentNode = null;
    this.parentElement = null;
    this.textContent = '';
    this.style = {};
    this.className = '';
    this.listeners = new Map();
    this._innerHTML = '';
  }

  setAttribute(key, value) { this.attributes.set(key, String(value)); }

  getAttribute(key) { return this.attributes.has(key) ? this.attributes.get(key) : null; }

  hasAttribute(key) { return this.attributes.has(key); }

  removeAttribute(key) { this.attributes.delete(key); }

  appendChild(child) {
    child.parentNode = this;
    child.parentElement = this;
    this.childNodes.push(child);
    return child;
  }

  removeChild(child) {
    const i = this.childNodes.indexOf(child);
    if (i >= 0) this.childNodes.splice(i, 1);
    child.parentNode = null;
    child.parentElement = null;
    return child;
  }

  get firstChild() { return this.childNodes[0] || null; }

  addEventListener(type, fn) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(fn);
  }

  removeEventListener() {}

  dispatch(type, event) {
    for (const fn of this.listeners.get(type) || []) fn(event);
  }

  getBoundingClientRect() { return { left: 0, top: 0, width: 760, height: 260 }; }

  get clientWidth() { return 760; }

  get clientHeight() { return 260; }

  get innerHTML() { return this._innerHTML; }

  set innerHTML(value) { this._innerHTML = String(value); }

  /** 支持 `.cls`、`tag`、`:scope > .cls` 三种选择器，够 charts.js 使用 */
  querySelectorAll(selector) {
    const s = String(selector).trim();
    const direct = s.startsWith(':scope >');
    const rest = (direct ? s.slice(':scope >'.length) : s).trim();
    const cls = rest.startsWith('.') ? rest.slice(1) : null;
    const tag = cls ? null : rest;
    const out = [];
    const isMatch = (n) => (cls
      ? String(n.className || '').split(/\s+/).includes(cls)
      : n.tagName === tag);
    if (direct) {
      for (const child of this.childNodes) if (isMatch(child)) out.push(child);
    } else {
      const walk = (node) => {
        for (const child of node.childNodes) {
          if (isMatch(child)) out.push(child);
          walk(child);
        }
      };
      walk(this);
    }
    return out;
  }

  querySelector(selector) {
    const found = this.querySelectorAll(selector);
    return found.length ? found[0] : null;
  }
}

global.document = {
  createElementNS: (ns, tag) => new StubNode(tag, ns),
  createElement: (tag) => new StubNode(tag, 'http://www.w3.org/1999/xhtml'),
};

/** 递归收集某标签的所有后代 */
function collect(node, tag) {
  const out = [];
  const walk = (n) => {
    for (const child of n.childNodes) {
      if (!tag || child.tagName === tag) out.push(child);
      walk(child);
    }
  };
  walk(node);
  return out;
}

/** Y 轴刻度标签：text-anchor="end" */
function yLabels(svg) {
  return collect(svg, 'text')
    .filter((t) => t.getAttribute('text-anchor') === 'end')
    .map((t) => t.textContent);
}

/** X 轴刻度标签：text-anchor="middle" 且内容为纯数字（轴标题为中文，不会误入） */
function xTickLabels(svg) {
  return collect(svg, 'text')
    .filter((t) => t.getAttribute('text-anchor') === 'middle')
    .map((t) => t.textContent)
    .filter((t) => /^-?\d+(\.\d+)?$/.test(t));
}

/** 构造一个带父容器的 svg 元素 */
function makeSvg() {
  const container = new StubNode('div', 'http://www.w3.org/1999/xhtml');
  const svg = global.document.createElementNS(SVG_NS, 'svg');
  container.appendChild(svg);
  return { container, svg };
}

// ------------------------------------------------------------------ 模块加载

let corePromise = null;
let chartsPromise = null;

/** 载入 web/lib/core.js（纯函数模块） */
function loadCore() {
  if (!corePromise) corePromise = import('../web/lib/core.js');
  return corePromise;
}

/** 载入 web/charts.js（SVG 渲染模块） */
function loadCharts() {
  if (!chartsPromise) chartsPromise = import('../web/charts.js');
  return chartsPromise;
}

// ------------------------------------------------------------------ core.js 纯函数

test('formatNumber：空值显示为 -，整数不带小数，非整数按位数四舍五入', async () => {
  const { formatNumber } = await loadCore();
  assert.strictEqual(formatNumber(null), '-');
  assert.strictEqual(formatNumber(undefined), '-');
  assert.strictEqual(formatNumber(''), '-');
  assert.strictEqual(formatNumber(NaN), '-');
  assert.strictEqual(formatNumber(Infinity), '-');
  assert.strictEqual(formatNumber(42), '42');
  assert.strictEqual(formatNumber(0), '0');
  assert.strictEqual(formatNumber(3.14159), '3.14');
  assert.strictEqual(formatNumber(3.14159, 3), '3.142');
  assert.strictEqual(formatNumber(0.125, 2), '0.13');
});

test('escapeHtml：转义 & < > " 五类字符', async () => {
  const { escapeHtml } = await loadCore();
  assert.strictEqual(escapeHtml('<a href="x">&\'</a>'), '&lt;a href=&quot;x&quot;&gt;&amp;&#39;&lt;/a&gt;');
  assert.strictEqual(escapeHtml('普通文本'), '普通文本');
});

test('statusText：内置状态映射为中文，未知状态走 HTML 转义（F-16）', async () => {
  const { statusText } = await loadCore();
  assert.strictEqual(statusText('running'), '运行中');
  assert.strictEqual(statusText('completed'), '已完成');
  assert.strictEqual(statusText('stopped'), '已停止');
  assert.strictEqual(statusText('failed'), '已失败');
  assert.strictEqual(statusText('idle'), '空闲');
  assert.strictEqual(statusText(''), '-');
  const hostile = statusText('<img src=x onerror=alert(1)>');
  assert.ok(!hostile.includes('<'), '未知状态不得把原始尖括号带进 innerHTML');
  assert.ok(hostile.includes('&lt;'));
});

test('isValidY：null / 空串 / undefined 视为「无样本」，不得当作 0 画进图里（F-11）', async () => {
  const { isValidY } = await loadCore();
  assert.strictEqual(isValidY(null), false);
  assert.strictEqual(isValidY(undefined), false);
  assert.strictEqual(isValidY(''), false);
  assert.strictEqual(isValidY(NaN), false);
  assert.strictEqual(isValidY(0), true);
  assert.strictEqual(isValidY('0'), true);
  assert.strictEqual(isValidY('12.5'), true);
});

test('niceScale：低值步长不塌缩，刻度值严格递减且互不相同（F-09 根因）', async () => {
  const { niceScale } = await loadCore();
  const low = niceScale(0.5);
  assert.ok(low.step < 1, `步长应小于 1，实际 ${low.step}`);
  assert.ok(low.max >= 0.5);
  assert.strictEqual(low.ticks[low.ticks.length - 1], 0);
  assert.strictEqual(new Set(low.ticks).size, low.ticks.length, '刻度值不得重复');
  for (let i = 1; i < low.ticks.length; i += 1) {
    assert.ok(low.ticks[i] < low.ticks[i - 1], '刻度值必须严格递减');
  }
});

test('niceScale：常规量级落在 1/2/2.5/5×10^k 阶梯上', async () => {
  const { niceScale } = await loadCore();
  const s = niceScale(8065);
  assert.strictEqual(s.step, 2500);
  assert.strictEqual(s.max, 10000);
  assert.deepStrictEqual(s.ticks, [10000, 7500, 5000, 2500, 0]);

  assert.deepStrictEqual(niceScale(0).ticks, [1, 0.75, 0.5, 0.25, 0]);
  assert.strictEqual(niceScale(-5).max, 1);
  assert.strictEqual(niceScale(NaN).max, 1);
});

test('tickDigits：标签精度由步长决定，小步长不被抹平（F-09）', async () => {
  const { tickDigits } = await loadCore();
  assert.strictEqual(tickDigits(10), 0);
  assert.strictEqual(tickDigits(2500), 0);
  assert.strictEqual(tickDigits(5), 0);
  assert.strictEqual(tickDigits(2.5), 1);
  assert.strictEqual(tickDigits(0.2), 2);
  assert.strictEqual(tickDigits(0.005), 3);
});

test('fullBuckets：剔除末尾不满一秒的桶，消除虚假"跌落"（F-18）', async () => {
  const { fullBuckets } = await loadCore();
  const series = [{ second: 0 }, { second: 9 }, { second: 10 }];
  const kept = fullBuckets({ durationSec: 10.02, series });
  assert.deepStrictEqual(kept.map((p) => p.second), [0, 9]);

  assert.deepStrictEqual(
    fullBuckets({ durationSec: 10, series: [{ second: 0 }, { second: 9 }] }).map((p) => p.second),
    [0, 9],
  );
  // 缺少时长信息时不过滤（保持原样，避免整图空白）
  assert.strictEqual(fullBuckets({ series }).length, 3);
  assert.strictEqual(fullBuckets(null).length, 0);
});

test('shouldCloseStream：只看被订阅运行自身的状态（F-01/F-04）', async () => {
  const { shouldCloseStream, EVENT_SOURCE_CLOSED } = await loadCore();
  // 运行仍在进行 —— 不得关闭
  assert.strictEqual(
    shouldCloseStream({ isCurrent: true, readyState: 1, liveRunStatus: 'running' }), false,
  );
  // 运行已结束 —— 应当关闭
  assert.strictEqual(
    shouldCloseStream({ isCurrent: true, readyState: 1, liveRunStatus: 'completed' }), true,
  );
  // 已被新订阅取代 —— 不动它
  assert.strictEqual(
    shouldCloseStream({ isCurrent: false, readyState: 1, liveRunStatus: 'completed' }), false,
  );
  // 已经关闭过 —— 无需重复关闭
  assert.strictEqual(
    shouldCloseStream({ isCurrent: true, readyState: EVENT_SOURCE_CLOSED, liveRunStatus: 'completed' }),
    false,
  );
  // 未知状态 —— 不贸然关闭
  assert.strictEqual(
    shouldCloseStream({ isCurrent: true, readyState: 1, liveRunStatus: null }), false,
  );
});

test('resolveStreamError：区分重连 / 收尾 / 中断三种处置（F-02）', async () => {
  const { resolveStreamError } = await loadCore();
  const reconnect = resolveStreamError({ runStatus: 'running', fetchFailed: false });
  assert.strictEqual(reconnect.action, 'reconnect');
  assert.strictEqual(reconnect.status, 'running');
  assert.ok(reconnect.hint.length > 0);

  const finalize = resolveStreamError({ runStatus: 'completed', fetchFailed: false });
  assert.strictEqual(finalize.action, 'finalize');
  assert.strictEqual(finalize.status, 'completed');

  const abort = resolveStreamError({ runStatus: 'running', fetchFailed: true });
  assert.strictEqual(abort.action, 'abort');
  assert.strictEqual(abort.status, 'failed');
  assert.ok(abort.hint.length > 0);
});

test('resolveStreamDone：旧运行的 done 帧不得拆掉新订阅（F-03）', async () => {
  const { resolveStreamDone } = await loadCore();
  assert.deepStrictEqual(resolveStreamDone({ isCurrent: true }), { teardown: true, clearLiveRunId: true });
  assert.deepStrictEqual(resolveStreamDone({ isCurrent: false }), { teardown: false, clearLiveRunId: false });
});

// ------------------------------------------------------------------ charts.js 渲染

test('折线图 Y 轴刻度标签正确：低 QPS 不再出现重复刻度与 "0.75→1" 错标（F-09）', async () => {
  const charts = await loadCharts();
  const { svg } = makeSvg();
  charts.renderLineChart(svg, {
    series: [{
      name: '每秒 QPS',
      color: '#4f8cff',
      points: [{ x: 0, y: 0.5 }, { x: 1, y: 0.4 }, { x: 2, y: 0.3 }],
    }],
    yLabel: 'QPS',
  });
  const labels = yLabels(svg);
  assert.ok(labels.length >= 3, `刻度过少：${labels}`);
  assert.strictEqual(new Set(labels).size, labels.length, `刻度标签重复：${labels}`);
  const values = labels.map(Number);
  for (let i = 1; i < values.length; i += 1) {
    assert.ok(values[i] < values[i - 1], `刻度未严格递减：${labels}`);
  }
  assert.strictEqual(values[values.length - 1], 0);
  assert.ok(values[0] >= 0.5, '坐标轴上限不得低于数据最大值');
  // 旧实现会把 0.75 抹成 "1"，导致首尾标签相同
  assert.ok(!labels.includes('1'), `低 QPS 场景不得出现整数刻度标签：${labels}`);
});

test('折线图 Y 轴刻度标签与真实量级一致（QPS 8065 → 0/2500/5000/7500/10000）', async () => {
  const charts = await loadCharts();
  const { svg } = makeSvg();
  charts.renderLineChart(svg, {
    series: [{
      name: '每秒 QPS',
      color: '#4f8cff',
      points: [{ x: 0, y: 8065 }, { x: 1, y: 7800 }, { x: 2, y: 8100 }],
    }],
  });
  assert.deepStrictEqual(yLabels(svg), ['10000', '7500', '5000', '2500', '0']);
});

test('折线图 X 轴刻度落在整秒上，不出现错位标签（F-10）', async () => {
  const charts = await loadCharts();
  const { svg } = makeSvg();
  const points = [];
  for (let i = 0; i <= 14; i += 1) points.push({ x: i, y: i * 10 });
  charts.renderLineChart(svg, { series: [{ name: 'QPS', color: '#4f8cff', points }] });
  const labels = xTickLabels(svg);
  assert.ok(labels.length >= 2, 'X 轴至少要有两个刻度');
  for (const label of labels) {
    assert.match(label, /^\d+$/, `X 轴刻度必须是整数秒，实际 "${label}"`);
  }
  assert.strictEqual(labels[0], '0');
});

test('折线图：全部 Y 为 null 时显示空态文案且不画曲线（F-11）', async () => {
  const charts = await loadCharts();
  const { svg } = makeSvg();
  charts.renderLineChart(svg, {
    series: [{
      name: '每秒 QPS',
      color: '#4f8cff',
      points: [{ x: 0, y: null }, { x: 1, y: null }],
    }],
    emptyText: '暂无数据',
  });
  assert.strictEqual(collect(svg, 'path').length, 0, '空态不应绘制任何折线');
  const texts = collect(svg, 'text').map((t) => t.textContent);
  assert.ok(texts.includes('暂无数据'), `缺少空态文案，实际 ${JSON.stringify(texts)}`);
});

test('折线图：Y 为字符串数字时按数值绘制，不误判为空态（F-11 边界）', async () => {
  const charts = await loadCharts();
  const { svg } = makeSvg();
  charts.renderLineChart(svg, {
    series: [{ name: 'QPS', color: '#4f8cff', points: [{ x: 0, y: '5' }, { x: 1, y: '6' }] }],
  });
  assert.ok(collect(svg, 'path').length >= 1, '字符串数值应被正常绘制');
});

test('折线图：面积填充与数据点圆圈均被绘制', async () => {
  const charts = await loadCharts();
  const { svg } = makeSvg();
  charts.renderLineChart(svg, {
    series: [{
      name: 'QPS', color: '#4f8cff', fill: true, points: [{ x: 0, y: 1 }, { x: 1, y: 2 }],
    }],
  });
  const paths = collect(svg, 'path');
  assert.strictEqual(paths.length, 2, '应有面积填充 + 折线两条路径');
  assert.ok(paths[0].getAttribute('d').endsWith('Z'), '面积路径应闭合');
  assert.strictEqual(collect(svg, 'circle').length, 2);
});

test('柱状图渲染图例：色块 + 文字（F-08）', async () => {
  const charts = await loadCharts();
  const { svg } = makeSvg();
  charts.renderBarChart(svg, {
    bars: [{ label: '200', value: 120 }],
    legend: [
      { label: '成功', color: '#3ecf8e' },
      { label: '失败', color: '#ff5f6d' },
    ],
  });
  const legendRects = collect(svg, 'rect').filter((r) => r.getAttribute('rx') === '2');
  assert.strictEqual(legendRects.length, 2, '图例应有两个色块');
  assert.deepStrictEqual(legendRects.map((r) => r.getAttribute('fill')), ['#3ecf8e', '#ff5f6d']);
  const texts = collect(svg, 'text').map((t) => t.textContent);
  assert.ok(texts.includes('成功'), '图例应包含「成功」文字');
  assert.ok(texts.includes('失败'), '图例应包含「失败」文字');
});

test('柱状图：未传图例时不渲染任何图例色块', async () => {
  const charts = await loadCharts();
  const { svg } = makeSvg();
  charts.renderBarChart(svg, { bars: [{ label: '200', value: 12 }] });
  const legendRects = collect(svg, 'rect').filter((r) => r.getAttribute('rx') === '2');
  assert.strictEqual(legendRects.length, 0);
});

test('柱状图：堆叠柱区分成功/失败两段，失败段位于上方（F-12）', async () => {
  const charts = await loadCharts();
  const { svg } = makeSvg();
  charts.renderBarChart(svg, {
    bars: [{
      label: '200',
      stack: [
        { label: '成功', value: 10, color: '#3ecf8e' },
        { label: '失败', value: 2, color: '#ff5f6d' },
      ],
    }],
    legend: [
      { label: '成功', color: '#3ecf8e' },
      { label: '失败', color: '#ff5f6d' },
    ],
  });
  // 堆叠段没有 rx 属性（普通柱有 rx="3"，图例色块有 rx="2"）
  const segments = collect(svg, 'rect').filter((r) => r.getAttribute('rx') === null);
  assert.strictEqual(segments.length, 2, '堆叠柱应有成功/失败两段');
  const success = segments.find((r) => r.getAttribute('fill') === '#3ecf8e');
  const failed = segments.find((r) => r.getAttribute('fill') === '#ff5f6d');
  assert.ok(success && failed, '成功段与失败段颜色应各自可见');
  assert.ok(
    Number(failed.getAttribute('y')) < Number(success.getAttribute('y')),
    '失败段应绘制在成功段上方（y 更小）',
  );
  // 失败段高度按 2/总量 计算
  assert.ok(Number(failed.getAttribute('height')) < Number(success.getAttribute('height')));
});

test('柱状图：空数据时显示空态文案', async () => {
  const charts = await loadCharts();
  const { svg } = makeSvg();
  charts.renderBarChart(svg, { bars: [], emptyText: '暂无数据' });
  const texts = collect(svg, 'text').map((t) => t.textContent);
  assert.ok(texts.includes('暂无数据'));
  assert.strictEqual(collect(svg, 'rect').length, 0);
});

test('柱状图：Y 轴刻度随数据量级自适应且互不重复', async () => {
  const charts = await loadCharts();
  const { svg } = makeSvg();
  charts.renderBarChart(svg, {
    bars: [{ label: '0-10ms', value: 80000 }, { label: '10-50ms', value: 1200 }],
  });
  const labels = yLabels(svg);
  assert.ok(labels.length >= 3);
  assert.strictEqual(new Set(labels).size, labels.length, `刻度标签重复：${labels}`);
  assert.strictEqual(Number(labels[labels.length - 1]), 0);
});
