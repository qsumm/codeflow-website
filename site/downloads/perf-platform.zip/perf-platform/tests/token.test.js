'use strict';
/**
 * tests/token.test.js —— 访问令牌（P2-2）集成测试。
 *
 * 服务端配置 PERF_TOKEN 后：除 /api/health（探活）外，所有 /api 接口都必须携带令牌
 * （请求头 `X-Perf-Token` 或查询参数 `?token=`）；静态页面与样例目标不受影响。
 *
 * 使用独立端口与临时数据目录，不影响 8801 常驻服务。
 */

const test = require('node:test');
const assert = require('node:assert');
const { spawn } = require('node:child_process');
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');
const net = require('node:net');

const TOKEN = 'test-token-123';
const SERVER = path.resolve(__dirname, '..', 'server', 'index.js');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function freePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.on('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const { port } = srv.address();
      srv.close(() => resolve(port));
    });
  });
}

let child = null;
let base = '';
let dataDir = null;

test.before(async () => {
  const port = await freePort();
  base = `http://127.0.0.1:${port}`;
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'perf-platform-token-'));
  child = spawn(process.execPath, [SERVER], {
    env: { ...process.env, PORT: String(port), HOST: '127.0.0.1', DATA_DIR: dataDir, PERF_TOKEN: TOKEN },
    stdio: 'ignore',
  });
  const deadline = Date.now() + 15000;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`${base}/api/health`);
      if (res.ok) return;
    } catch {
      /* 尚未就绪 */
    }
    await sleep(150);
  }
  throw new Error('带令牌的测试服务启动超时');
});

test.after(() => {
  if (child) {
    child.kill('SIGTERM');
    child = null;
  }
  if (dataDir) {
    try {
      fs.rmSync(dataDir, { recursive: true, force: true });
    } catch {
      /* 忽略清理失败 */
    }
  }
});

test('健康检查保持公开（供 start.sh / status.sh 探活）', async () => {
  const res = await fetch(`${base}/api/health`);
  assert.strictEqual(res.status, 200);
});

test('未携带令牌的 API 请求返回 401', async () => {
  const res = await fetch(`${base}/api/tasks`);
  assert.strictEqual(res.status, 401);
  const payload = await res.json();
  assert.strictEqual(payload.error.code, 'UNAUTHORIZED');
});

test('请求头 X-Perf-Token 携带令牌可正常访问', async () => {
  const res = await fetch(`${base}/api/tasks`, { headers: { 'X-Perf-Token': TOKEN } });
  assert.strictEqual(res.status, 200);
  const payload = await res.json();
  assert.ok(Array.isArray(payload.tasks));
});

test('查询参数 ?token= 携带令牌可正常访问（EventSource 场景）', async () => {
  const res = await fetch(`${base}/api/tasks?token=${encodeURIComponent(TOKEN)}`);
  assert.strictEqual(res.status, 200);
});

test('错误令牌被拒绝', async () => {
  const res = await fetch(`${base}/api/tasks`, { headers: { 'X-Perf-Token': 'wrong' } });
  assert.strictEqual(res.status, 401);
});

test('静态页面与压测样例目标不受令牌影响', async () => {
  const home = await fetch(`${base}/`);
  assert.strictEqual(home.status, 200);
  const sample = await fetch(`${base}/sample`);
  assert.strictEqual(sample.status, 200);
});
