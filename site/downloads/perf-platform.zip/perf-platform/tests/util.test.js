'use strict';
/**
 * tests/util.test.js —— 参数校验与工具函数单元测试。
 */

const test = require('node:test');
const assert = require('node:assert');

const { HttpError, validateTaskInput, newId, round2 } = require('../server/util');

function expectInvalid(input, field) {
  assert.throws(
    () => validateTaskInput(input),
    (err) => {
      assert.ok(err instanceof HttpError, '应抛出 HttpError');
      assert.strictEqual(err.code, 'INVALID_PARAM');
      assert.strictEqual(err.status, 400);
      assert.ok(err.fields && err.fields[field], `字段错误应包含 ${field}`);
      return true;
    },
  );
}

test('合法输入被归一化并填充默认值', () => {
  const task = validateTaskInput({ url: 'http://localhost:8801/sample' });
  assert.strictEqual(task.url, 'http://localhost:8801/sample');
  assert.strictEqual(task.concurrency, 20);
  assert.strictEqual(task.durationSec, 10);
  assert.strictEqual(task.timeoutMs, 10000);
  assert.strictEqual(task.method, 'GET');
  assert.deepStrictEqual(task.headers, []);
  assert.strictEqual(task.body, '');
});

test('URL 缺失 / 非法 / 非 http(s) 协议被拒绝', () => {
  expectInvalid({}, 'url');
  expectInvalid({ url: 'not a url' }, 'url');
  expectInvalid({ url: 'ftp://example.com/x' }, 'url');
  expectInvalid({ url: 'file:///etc/passwd' }, 'url');
});

test('并发数护栏：1–200', () => {
  assert.strictEqual(validateTaskInput({ url: 'http://a.test/', concurrency: 1 }).concurrency, 1);
  assert.strictEqual(validateTaskInput({ url: 'http://a.test/', concurrency: 200 }).concurrency, 200);
  expectInvalid({ url: 'http://a.test/', concurrency: 0 }, 'concurrency');
  expectInvalid({ url: 'http://a.test/', concurrency: 201 }, 'concurrency');
  expectInvalid({ url: 'http://a.test/', concurrency: 1.5 }, 'concurrency');
});

test('持续时间护栏：1–600 秒', () => {
  assert.strictEqual(validateTaskInput({ url: 'http://a.test/', durationSec: 600 }).durationSec, 600);
  expectInvalid({ url: 'http://a.test/', durationSec: 0 }, 'durationSec');
  expectInvalid({ url: 'http://a.test/', durationSec: 601 }, 'durationSec');
});

test('超时护栏：100–60000 毫秒', () => {
  expectInvalid({ url: 'http://a.test/', timeoutMs: 99 }, 'timeoutMs');
  expectInvalid({ url: 'http://a.test/', timeoutMs: 60001 }, 'timeoutMs');
  assert.strictEqual(validateTaskInput({ url: 'http://a.test/', timeoutMs: 60000 }).timeoutMs, 60000);
});

test('请求方法白名单', () => {
  assert.strictEqual(validateTaskInput({ url: 'http://a.test/', method: 'post' }).method, 'POST');
  expectInvalid({ url: 'http://a.test/', method: 'TRACE' }, 'method');
});

test('请求头必须为数组且名称非空', () => {
  expectInvalid({ url: 'http://a.test/', headers: 'X-Test: 1' }, 'headers');
  expectInvalid({ url: 'http://a.test/', headers: [{ name: '', value: 'x' }] }, 'headers');
  expectInvalid({ url: 'http://a.test/', headers: [{ name: 'bad header', value: 'x' }] }, 'headers');
  const task = validateTaskInput({ url: 'http://a.test/', headers: [{ name: 'X-Token', value: 'abc' }] });
  assert.deepStrictEqual(task.headers, [{ name: 'X-Token', value: 'abc' }]);
});

test('名称超长被拒绝', () => {
  expectInvalid({ url: 'http://a.test/', name: 'x'.repeat(65) }, 'name');
});

test('newId 前缀唯一且 round2 保留两位小数', () => {
  const a = newId('task');
  const b = newId('task');
  assert.ok(a.startsWith('task_'));
  assert.notStrictEqual(a, b);
  assert.strictEqual(round2(1.23456), 1.23);
  assert.strictEqual(round2(3.14159), 3.14);
});
