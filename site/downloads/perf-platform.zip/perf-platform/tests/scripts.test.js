'use strict';
/**
 * tests/scripts.test.js —— 运维脚本行为测试（start.sh / stop.sh）。
 *
 * 覆盖：
 *  1. start.sh 后台启动成功 → 健康检查通过 → 写 PID 文件与日志；
 *  2. 重复执行 start.sh → 退出码 0 并提示「服务已在运行」（P1-1：
 *     PID 文件检测必须早于端口占用检测，否则会误报「端口被他人占用」）；
 *  3. 残留（失效）PID 文件 → 清理后可正常启动；
 *  4. 端口被他人进程占用 → 报错退出（退出码 1）且**不 kill** 占用者；
 *  5. stop.sh 优雅停止后 PID 文件被清理、端口释放。
 *
 * 所有实例都跑在临时端口与临时目录上，不影响 8801 常驻服务与交付目录的 data/。
 */

const test = require('node:test');
const assert = require('node:assert');
const { spawnSync, spawn } = require('node:child_process');
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');
const net = require('node:net');

const ROOT = path.resolve(__dirname, '..');
const START_SH = path.join(ROOT, 'start.sh');
const STOP_SH = path.join(ROOT, 'stop.sh');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

function freePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.on('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const { port } = srv.address();
      srv.close(() => resolve(port));
    });
  });
}

function runScript(script, env) {
  const result = spawnSync('bash', [script], {
    env: { ...process.env, ...env },
    encoding: 'utf8',
    timeout: 30000,
  });
  return {
    code: result.status,
    stdout: result.stdout || '',
    stderr: result.stderr || '',
    out: `${result.stdout || ''}${result.stderr || ''}`,
  };
}

async function waitHealthy(port, timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`http://127.0.0.1:${port}/api/health`);
      if (res.ok) return true;
    } catch {
      /* 尚未就绪 */
    }
    await sleep(150);
  }
  return false;
}

async function portBusy(port) {
  const srv = net.createServer();
  try {
    await new Promise((resolve, reject) => {
      srv.once('error', reject);
      srv.listen(port, '127.0.0.1', resolve);
    });
    return srv;
  } catch {
    return null;
  }
}

test('start.sh 幂等：重复执行提示「服务已在运行」；端口被他人占用时报错退出且不 kill', async (t) => {
  const port = await freePort();
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'perf-platform-script-'));
  const env = {
    PORT: String(port),
    HOST: '127.0.0.1',
    RUN_DIR: path.join(tmp, 'run'),
    LOG_DIR: path.join(tmp, 'logs'),
    DATA_DIR: path.join(tmp, 'data'),
  };
  const pidFile = path.join(env.RUN_DIR, 'server.pid');

  t.after(() => {
    runScript(STOP_SH, env);
    try {
      fs.rmSync(tmp, { recursive: true, force: true });
    } catch {
      /* 忽略清理失败 */
    }
  });

  // 1) 首次启动
  const first = runScript(START_SH, env);
  assert.strictEqual(first.code, 0, `start.sh 应成功退出，实际输出：${first.out}`);
  assert.ok(first.out.includes('服务已就绪'), `应提示服务已就绪：${first.out}`);
  assert.ok(fs.existsSync(pidFile), '应写入 PID 文件');
  assert.ok(fs.existsSync(path.join(env.LOG_DIR, 'server.log')), '应写入日志文件');
  assert.ok(await waitHealthy(port), '服务应能通过健康检查');

  // 2) 重复启动：P1-1 —— 提示「服务已在运行」而非误报「端口被占用」，且退出码为 0
  const second = runScript(START_SH, env);
  assert.strictEqual(second.code, 0, `重复启动应友好退出 0：${second.out}`);
  assert.ok(second.out.includes('服务已在运行'), `应提示服务已在运行：${second.out}`);
  assert.ok(!second.out.includes('已被占用'), `不应误报端口被占用：${second.out}`);

  // 3) 失效 PID 文件：实例已停止、端口已释放时应清理残留并正常启动
  runScript(STOP_SH, env); // 先停掉本实例
  await sleep(400);
  fs.writeFileSync(pidFile, '999999\n', 'utf8'); // 制造失效 PID 残留
  const stale = runScript(START_SH, env);
  assert.strictEqual(stale.code, 0, `失效 PID 文件不应阻塞启动：${stale.out}`);
  assert.ok(stale.out.includes('服务已就绪'), `失效 PID 文件后应能启动：${stale.out}`);
  assert.ok(await waitHealthy(port), '重启后服务应能通过健康检查');

  // 4) 端口被他人进程占用：报错退出，且不终止占用者
  runScript(STOP_SH, env); // 先停掉本实例，释放端口
  await sleep(300);
  const blocker = await portBusy(port);
  assert.ok(blocker, '应能占用测试端口');
  const occupied = runScript(START_SH, env);
  assert.strictEqual(occupied.code, 1, `端口被占用应退出 1：${occupied.out}`);
  assert.ok(occupied.out.includes('已被占用'), `应提示端口被占用：${occupied.out}`);
  assert.ok(blocker.listening, '不得终止占用端口的他人进程');

  // 5) stop.sh 停止后 PID 文件清理、端口释放
  await new Promise((resolve) => blocker.close(resolve));
  const stopped = runScript(STOP_SH, env);
  assert.strictEqual(stopped.code, 0, `stop.sh 应成功退出：${stopped.out}`);
  assert.ok(!fs.existsSync(pidFile), '停止后应清理 PID 文件');

  const after = runScript(STOP_SH, env);
  assert.strictEqual(after.code, 0, '无 PID 文件时 stop.sh 应友好退出');
  assert.ok(after.out.includes('未找到 PID 文件'), `应提示未找到 PID 文件：${after.out}`);
});
