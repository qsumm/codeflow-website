'use strict';
/**
 * tests/api.test.js —— 端到端集成测试：真实启动服务进程，走完整 REST + SSE 流程。
 * 使用独立端口（默认 18901），避免与 8801 常驻服务冲突。
 */

const test = require('node:test');
const assert = require('node:assert');
const { spawn } = require('node:child_process');
const path = require('node:path');
const os = require('node:os');
const fs = require('node:fs');

const PORT = process.env.TEST_PORT || '18901';
const BASE = `http://127.0.0.1:${PORT}`;
const SERVER = path.resolve(__dirname, '..', 'server', 'index.js');

let child = null;
let dataDir = null;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitForHealth(timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const res = await fetch(`${BASE}/api/health`);
      if (res.ok) return await res.json();
    } catch {
      /* 尚未就绪 */
    }
    await sleep(150);
  }
  throw new Error('测试服务启动超时');
}

async function api(pathname, options = {}) {
  const res = await fetch(`${BASE}${pathname}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  let payload = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }
  return { status: res.status, payload, headers: res.headers };
}

test.before(async () => {
  // 测试数据与生产 data/ 隔离，避免污染交付目录的持久化快照
  dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'perf-platform-test-'));
  child = spawn(process.execPath, [SERVER], {
    env: { ...process.env, PORT, HOST: '127.0.0.1', DATA_DIR: dataDir },
    stdio: 'ignore',
  });
  await waitForHealth();
});

test.after(() => {
  if (child) {
    child.kill('SIGTERM');
    child = null;
  }
  if (dataDir) {
    try {
      fs.rmSync(dataDir, { recursive: true, force: true });
    } catch {
      /* 忽略清理失败 */
    }
  }
});

test('GET /api/health 返回 ok', async () => {
  const { status, payload } = await api('/api/health');
  assert.strictEqual(status, 200);
  assert.strictEqual(payload.status, 'ok');
  assert.ok(payload.version);
});

test('GET / 首页可打开且含平台标题；/sample 为压测样例目标', async () => {
  const home = await fetch(`${BASE}/`);
  assert.strictEqual(home.status, 200);
  const html = await home.text();
  assert.ok(html.includes('性能测试平台'));

  const sample = await fetch(`${BASE}/sample`);
  assert.strictEqual(sample.status, 200);
  const sampleHtml = await sample.text();
  assert.ok(sampleHtml.includes('压测样例目标'));
});

test('创建任务：非法参数返回 400 且带字段级错误', async () => {
  const { status, payload } = await api('/api/tasks', {
    method: 'POST',
    body: { url: 'ftp://x/', concurrency: 999, durationSec: 9999 },
  });
  assert.strictEqual(status, 400);
  assert.strictEqual(payload.error.code, 'INVALID_PARAM');
  assert.ok(payload.error.fields.url);
  assert.ok(payload.error.fields.concurrency);
  assert.ok(payload.error.fields.durationSec);
});

test('创建任务成功并出现在列表中', async () => {
  const created = await api('/api/tasks', {
    method: 'POST',
    body: {
      name: '集成测试任务',
      url: `${BASE}/sample`,
      method: 'GET',
      concurrency: 5,
      durationSec: 2,
      timeoutMs: 5000,
      headers: [{ name: 'X-Test', value: '1' }],
    },
  });
  assert.strictEqual(created.status, 201);
  const task = created.payload.task;
  assert.ok(task.id);
  assert.strictEqual(task.concurrency, 5);
  assert.strictEqual(task.status, 'idle');

  const list = await api('/api/tasks');
  assert.strictEqual(list.status, 200);
  assert.ok(list.payload.tasks.some((t) => t.id === task.id));
});

test('发起压测 → SSE 实时推送 → 运行结束并产出 QPS/P95/P99 报告', async () => {
  const created = await api('/api/tasks', {
    method: 'POST',
    body: { name: '压测运行任务', url: `${BASE}/sample`, concurrency: 5, durationSec: 2, timeoutMs: 5000 },
  });
  const task = created.payload.task;

  const started = await api('/api/runs', { method: 'POST', body: { taskId: task.id } });
  assert.strictEqual(started.status, 202);
  const runId = started.payload.run.id;
  assert.ok(runId);
  assert.strictEqual(started.payload.run.status, 'running');

  // SSE：应至少收到一帧 stats 与最终的 done 帧
  const controller = new AbortController();
  const sseRes = await fetch(`${BASE}/api/runs/${runId}/stream`, { signal: controller.signal });
  assert.strictEqual(sseRes.status, 200);
  assert.ok(String(sseRes.headers.get('content-type')).includes('text/event-stream'));

  const reader = sseRes.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let sawStats = false;
  let sawDone = false;
  const deadline = Date.now() + 20000;
  while (Date.now() < deadline) {
    const { value, done } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    if (buffer.includes('event: stats')) sawStats = true;
    if (buffer.includes('event: done')) {
      sawDone = true;
      break;
    }
  }
  controller.abort();
  assert.ok(sawStats, '应收到 stats 帧');
  assert.ok(sawDone, '应收到 done 帧');

  // 轮询直到结束
  let run = null;
  for (let i = 0; i < 60; i += 1) {
    const data = await api(`/api/runs/${runId}`);
    run = data.payload.run;
    if (run.status !== 'running') break;
    await sleep(250);
  }
  assert.strictEqual(run.status, 'completed');

  const report = run.report;
  assert.ok(report, '应包含报告');
  assert.ok(report.total > 0, '总请求数应大于 0');
  assert.ok(report.qps > 0, 'QPS 应大于 0');
  assert.ok(report.tps > 0, 'TPS 应大于 0');
  assert.ok(report.latency.p95 !== null, 'P95 应存在');
  assert.ok(report.latency.p99 !== null, 'P99 应存在');
  assert.strictEqual(report.errorRate, 0, '样例页错误率应为 0');
  assert.ok(report.statusCodes.some((c) => c.code === '200'), '状态码分布应含 200');
  assert.ok(report.series.length > 0, '应含每秒时间序列');
  assert.ok(report.histogram.length > 0, '应含延迟直方图');

  // 运行历史可回看
  const runs = await api('/api/runs');
  assert.ok(runs.payload.runs.some((r) => r.id === runId));

  // 已结束的运行不可再停止
  const stop = await api(`/api/runs/${runId}/stop`, { method: 'POST' });
  assert.strictEqual(stop.status, 409);

  // 删除任务级联删除历史报告
  const del = await api(`/api/tasks/${task.id}`, { method: 'DELETE' });
  assert.strictEqual(del.status, 200);
  assert.strictEqual(del.payload.deleted, true);
  assert.ok(del.payload.removedRuns >= 1);

  const gone = await api(`/api/runs/${runId}`);
  assert.strictEqual(gone.status, 404);
});

test('未知任务发起运行返回 404；未知接口返回 404', async () => {
  const run = await api('/api/runs', { method: 'POST', body: { taskId: 'task_not_exist' } });
  assert.strictEqual(run.status, 404);

  const missing = await api('/api/not-exists');
  assert.strictEqual(missing.status, 404);
});

test('缺少 taskId 时返回 400', async () => {
  const res = await api('/api/runs', { method: 'POST', body: {} });
  assert.strictEqual(res.status, 400);
  assert.ok(res.payload.error.fields.taskId);
});

/** 发起一次运行并轮询到结束，返回最终 run 对象 */
async function runToEnd(taskId, timeoutMs = 30000) {
  const started = await api('/api/runs', { method: 'POST', body: { taskId } });
  assert.strictEqual(started.status, 202);
  const runId = started.payload.run.id;
  const deadline = Date.now() + timeoutMs;
  let run = null;
  while (Date.now() < deadline) {
    const data = await api(`/api/runs/${runId}`);
    run = data.payload.run;
    if (run.status !== 'running') break;
    await sleep(250);
  }
  assert.ok(run, '应能获取运行记录');
  assert.notStrictEqual(run.status, 'running', '运行应在超时前结束');
  return run;
}

test('失败口径：状态码 >= 400 记 http_error，报告含错误明细摘要', async () => {
  const created = await api('/api/tasks', {
    method: 'POST',
    body: { name: '404 目标', url: `${BASE}/api/definitely-not-found`, concurrency: 2, durationSec: 2, timeoutMs: 5000 },
  });
  assert.strictEqual(created.status, 201);
  const task = created.payload.task;

  const run = await runToEnd(task.id);
  const report = run.report;

  assert.ok(report.total > 0, '总请求数应大于 0');
  assert.strictEqual(report.failed, report.total, '404 目标下全部请求应失败');
  assert.strictEqual(report.success, 0, '不应有成功请求');
  assert.strictEqual(report.httpErrors, report.total, '失败应全部归类为 http_error');
  assert.strictEqual(report.networkErrors, 0, '不应出现 network_error');
  assert.ok(report.errorRate > 0, `错误率应大于 0，实际 ${report.errorRate}`);
  assert.strictEqual(report.errorRate, 100);

  // 错误明细摘要：类型 + 状态码 + 次数
  assert.ok(Array.isArray(report.errorSamples), '报告应含 errorSamples 数组');
  assert.ok(report.errorSamples.length > 0, '错误明细不应为空');
  const sample = report.errorSamples[0];
  assert.strictEqual(sample.type, 'http_error');
  assert.strictEqual(sample.statusCode, 404);
  assert.ok(sample.count > 0, '错误样例应带发生次数');
  assert.ok(typeof sample.message === 'string' && sample.message.length > 0, '错误样例应带描述');
  assert.ok(report.errorTypes.http_error > 0, 'errorTypes 应统计 http_error');

  // 状态码分布：3xx/4xx 原样计入，不跟随
  assert.ok(report.statusCodes.some((c) => c.code === '404' && c.failed === c.count), '状态码分布应含 404 且全部计失败');

  await api(`/api/tasks/${task.id}`, { method: 'DELETE' });
});

test('失败口径：连接失败记 network_error', async () => {
  // 127.0.0.1:1 上无监听 → ECONNREFUSED → network_error
  const created = await api('/api/tasks', {
    method: 'POST',
    body: { name: '连接失败目标', url: 'http://127.0.0.1:1/never', concurrency: 2, durationSec: 2, timeoutMs: 2000 },
  });
  assert.strictEqual(created.status, 201);
  const task = created.payload.task;

  const run = await runToEnd(task.id);
  const report = run.report;

  assert.ok(report.total > 0, '总请求数应大于 0');
  assert.strictEqual(report.failed, report.total, '全部请求应失败');
  assert.strictEqual(report.networkErrors, report.total, '失败应全部归类为 network_error');
  assert.strictEqual(report.httpErrors, 0, '不应出现 http_error');
  assert.ok(report.errorSamples.some((s) => s.type === 'network_error'), '错误明细应含 network_error');
  assert.strictEqual(report.statusCodes.length, 0, '无响应时不应有状态码分布');

  await api(`/api/tasks/${task.id}`, { method: 'DELETE' });
});

test('手动停止：运行状态变为 stopped 且不再产生新请求', async () => {
  const created = await api('/api/tasks', {
    method: 'POST',
    body: { name: '可停止任务', url: `${BASE}/sample`, concurrency: 4, durationSec: 30, timeoutMs: 5000 },
  });
  const task = created.payload.task;

  const started = await api('/api/runs', { method: 'POST', body: { taskId: task.id } });
  assert.strictEqual(started.status, 202);
  const runId = started.payload.run.id;

  await sleep(1200); // 让它先跑一会儿
  const stop = await api(`/api/runs/${runId}/stop`, { method: 'POST' });
  assert.strictEqual(stop.status, 200);

  const deadline = Date.now() + 15000;
  let run = null;
  while (Date.now() < deadline) {
    const data = await api(`/api/runs/${runId}`);
    run = data.payload.run;
    if (run.status !== 'running') break;
    await sleep(200);
  }
  assert.strictEqual(run.status, 'stopped');
  assert.ok(run.total > 0, '停止前应已完成若干请求');

  const totalAfterStop = run.total;
  await sleep(1500);
  const later = await api(`/api/runs/${runId}`);
  assert.strictEqual(later.payload.run.total, totalAfterStop, '停止后不应再产生新请求');
  assert.ok(run.actualDurationSec < 30, '实际时长应短于设定时长');

  await api(`/api/tasks/${task.id}`, { method: 'DELETE' });
});
