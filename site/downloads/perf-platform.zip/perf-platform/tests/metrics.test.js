'use strict';
/**
 * tests/metrics.test.js —— 指标聚合器单元测试（node:test 内置框架，零第三方依赖）。
 */

const test = require('node:test');
const assert = require('node:assert');

const { MetricsAggregator, percentileOf, averageOf, selectKth } = require('../server/metrics');

test('percentileOf 使用最近秩法 index = ceil(p/100 * n) - 1', () => {
  const sorted = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  assert.strictEqual(percentileOf(sorted, 50), 5);
  assert.strictEqual(percentileOf(sorted, 95), 10);
  assert.strictEqual(percentileOf(sorted, 99), 10);
  assert.strictEqual(percentileOf(sorted, 10), 1);
  assert.strictEqual(percentileOf([], 95), null);
  assert.strictEqual(percentileOf([42], 95), 42);
});

test('averageOf 与空集合处理', () => {
  assert.strictEqual(averageOf([10, 20, 30]), 20);
  assert.strictEqual(averageOf([1.5, 2.5]), 2);
  assert.strictEqual(averageOf([]), null);
});

test('计数与成功/失败口径：2xx/3xx 成功，>=400 失败', () => {
  const m = new MetricsAggregator(Date.now());
  m.record({ latencyMs: 10, statusCode: 200 });
  m.record({ latencyMs: 20, statusCode: 200 });
  m.record({ latencyMs: 30, statusCode: 302 });   // 3xx 不跟随，计成功
  m.record({ latencyMs: 40, statusCode: 404 });   // >=400 计失败
  m.record({ latencyMs: 50, statusCode: 500 });
  m.record({ latencyMs: 60, statusCode: null, errorType: 'network_error' });

  const r = m.snapshot();
  assert.strictEqual(r.total, 6);
  assert.strictEqual(r.success, 3);
  assert.strictEqual(r.failed, 3);
  assert.strictEqual(r.httpErrors, 2);
  assert.strictEqual(r.networkErrors, 1);
  assert.strictEqual(m.errorTypes.get('network_error'), 1);
});

test('状态码分布原样记录（含 3xx），且区分成功/失败', () => {
  const m = new MetricsAggregator(Date.now());
  m.record({ latencyMs: 5, statusCode: 200 });
  m.record({ latencyMs: 5, statusCode: 200 });
  m.record({ latencyMs: 5, statusCode: 301 });
  m.record({ latencyMs: 5, statusCode: 500 });

  const codes = m.snapshot().statusCodes;
  const byCode = Object.fromEntries(codes.map((c) => [c.code, c]));
  assert.strictEqual(byCode['200'].count, 2);
  assert.strictEqual(byCode['200'].success, 2);
  assert.strictEqual(byCode['301'].count, 1);
  assert.strictEqual(byCode['301'].success, 1);
  assert.strictEqual(byCode['500'].count, 1);
  assert.strictEqual(byCode['500'].failed, 1);
});

test('错误率 = 失败数 / 总请求数；总数为 0 时为 0', () => {
  const empty = new MetricsAggregator(Date.now()).snapshot();
  assert.strictEqual(empty.errorRate, 0);
  assert.strictEqual(empty.qps, 0);

  const m = new MetricsAggregator(Date.now());
  for (let i = 0; i < 8; i += 1) m.record({ latencyMs: 10, statusCode: 200 });
  for (let i = 0; i < 2; i += 1) m.record({ latencyMs: 10, statusCode: 500 });
  assert.strictEqual(m.snapshot().errorRate, 20);
});

test('延迟直方图按固定分桶统计', () => {
  const m = new MetricsAggregator(Date.now());
  [5, 15, 25, 120, 2000].forEach((latency) => m.record({ latencyMs: latency, statusCode: 200 }));
  const bins = m.snapshot().histogram;
  const count = (label) => bins.find((b) => b.label === label).count;
  assert.strictEqual(count('0-10'), 1);
  assert.strictEqual(count('10-20'), 1);
  assert.strictEqual(count('20-30'), 1);
  assert.strictEqual(count('100-150'), 1);
  assert.strictEqual(count('>=1000'), 1);
  assert.strictEqual(bins.reduce((s, b) => s + b.count, 0), 5);
});

test('每秒时间序列按秒分桶，含 qps 与分位数', () => {
  const m = new MetricsAggregator(Date.now());
  m.record({ latencyMs: 10, statusCode: 200 });
  m.record({ latencyMs: 30, statusCode: 200 });
  const series = m.snapshot().series;
  assert.ok(series.length >= 1);
  assert.strictEqual(series[0].count, 2);
  assert.strictEqual(series[0].success, 2);
  assert.strictEqual(series[0].failed, 0);
  assert.strictEqual(series[0].p95, 30);
});

test('延迟统计包含 avg/min/max/p50/p95/p99 与仅成功样本的 P95', () => {
  const m = new MetricsAggregator(Date.now());
  [10, 20, 30, 40, 50].forEach((l) => m.record({ latencyMs: l, statusCode: 200 }));
  m.record({ latencyMs: 900, statusCode: 500 });
  const { latency } = m.snapshot();
  assert.strictEqual(latency.min, 10);
  assert.strictEqual(latency.max, 900);
  assert.strictEqual(latency.avg, 175);
  assert.strictEqual(latency.p50, 30);
  assert.strictEqual(latency.p95, 900);
  assert.strictEqual(latency.successP95, 50);
  assert.strictEqual(latency.samples, 6);
});

// ---------------------------------------------------------------------------
// P2-1：quickselect 与「升序数组取最近秩下标」口径等价
// ---------------------------------------------------------------------------

test('selectKth：与升序排序取第 k 小完全等价（含重复值）', () => {
  const values = [];
  for (let i = 0; i < 500; i += 1) values.push((i * 37) % 101); // 大量重复值
  const sorted = [...values].sort((a, b) => a - b);
  for (const k of [0, 1, 25, 137, 250, 498, 499]) {
    assert.strictEqual(selectKth([...values], k), sorted[k], `k=${k}`);
  }
});

test('percentileOf：对乱序输入的结果与对升序输入的结果一致', () => {
  const values = [];
  for (let i = 1; i <= 1000; i += 1) values.push(i);
  const shuffled = [...values].sort(() => 0.5 - Math.random());
  for (const p of [50, 90, 95, 99]) {
    assert.strictEqual(percentileOf(shuffled, p), percentileOf(values, p), `p=${p}`);
  }
});

test('percentileOf：不改写调用方数组', () => {
  const values = [5, 1, 4, 2, 3];
  const copy = [...values];
  percentileOf(values, 50);
  assert.deepStrictEqual(values, copy);
});

test('大样本下分位数与最近秩法一致（quickselect 未改变口径）', () => {
  const m = new MetricsAggregator(Date.now());
  const n = 20000;
  for (let i = 1; i <= n; i += 1) m.record({ latencyMs: i % 1000, statusCode: 200 });
  const sorted = [];
  for (let i = 1; i <= n; i += 1) sorted.push(i % 1000);
  sorted.sort((a, b) => a - b);
  const { latency } = m.snapshot();
  assert.strictEqual(latency.p50, sorted[Math.ceil(0.5 * n) - 1]);
  assert.strictEqual(latency.p95, sorted[Math.ceil(0.95 * n) - 1]);
  assert.strictEqual(latency.p99, sorted[Math.ceil(0.99 * n) - 1]);
  assert.strictEqual(latency.samples, n);
});

// ---------------------------------------------------------------------------
// P1-2：错误明细摘要
// ---------------------------------------------------------------------------

test('错误类型统计包含 http_error 与 network_error 两类', () => {
  const m = new MetricsAggregator(Date.now());
  m.record({ latencyMs: 10, statusCode: 200 });
  m.record({ latencyMs: 20, statusCode: 500 });
  m.record({ latencyMs: 30, statusCode: 404 });
  m.record({ latencyMs: 40, statusCode: null, errorType: 'network_error', errorMessage: 'ECONNREFUSED' });

  const r = m.snapshot();
  assert.strictEqual(r.errorTypes.http_error, 2);
  assert.strictEqual(r.errorTypes.network_error, 1);
  assert.strictEqual(r.httpErrors, 2);
  assert.strictEqual(r.networkErrors, 1);
});

test('错误明细摘要按「类型+状态码+消息」聚合并记录次数', () => {
  const m = new MetricsAggregator(Date.now());
  m.record({ latencyMs: 10, statusCode: 500, errorType: 'http_error', errorMessage: 'HTTP 500' });
  m.record({ latencyMs: 11, statusCode: 500, errorType: 'http_error', errorMessage: 'HTTP 500' });
  m.record({ latencyMs: 12, statusCode: 502, errorType: 'http_error', errorMessage: 'HTTP 502' });
  m.record({ latencyMs: 13, statusCode: null, errorType: 'network_error', errorMessage: 'ECONNREFUSED' });

  const samples = m.snapshot().errorSamples;
  assert.strictEqual(samples.length, 3);

  const first = samples.find((s) => s.statusCode === 500);
  assert.ok(first, '应含 500 的错误条目');
  assert.strictEqual(first.count, 2);
  assert.strictEqual(first.type, 'http_error');
  assert.strictEqual(first.message, 'HTTP 500');
  assert.ok(first.lastAt > 0);

  const net = samples.find((s) => s.type === 'network_error');
  assert.strictEqual(net.count, 1);
  assert.strictEqual(net.statusCode, null);
});

test('未携带错误消息的 HTTP 失败会补默认描述', () => {
  const m = new MetricsAggregator(Date.now());
  m.record({ latencyMs: 10, statusCode: 503 });
  const samples = m.snapshot().errorSamples;
  assert.strictEqual(samples.length, 1);
  assert.strictEqual(samples[0].message, 'HTTP 503');
  assert.strictEqual(samples[0].type, 'http_error');
});

test('无失败时错误明细为空', () => {
  const m = new MetricsAggregator(Date.now());
  m.record({ latencyMs: 10, statusCode: 200 });
  const r = m.snapshot();
  assert.deepStrictEqual(r.errorSamples, []);
  assert.deepStrictEqual(r.errorTypes, {});
});

// ---------------------------------------------------------------------------
// P2-1：延迟样本有上限（蓄水池抽样），计数类指标始终精确
// ---------------------------------------------------------------------------

test('P2-1 样本上限：超过上限后保留样本数受限，并标记分位数为近似值', () => {
  const m = new MetricsAggregator(Date.now(), { maxSamples: 100, maxBucketSamples: 50 });
  for (let i = 1; i <= 1000; i += 1) m.record({ latencyMs: i % 500, statusCode: 200 });

  const r = m.snapshot();
  assert.strictEqual(r.total, 1000, '总请求数必须精确');
  assert.strictEqual(r.success, 1000);
  assert.strictEqual(r.latency.sampleSize, 100, '保留的样本数应受上限约束');
  assert.strictEqual(r.percentilesApproximate, true, '应标记分位数为抽样估计');
  assert.strictEqual(r.percentileSampleSize, 100);
  assert.strictEqual(r.latency.approximate, true);
});

test('P2-1 样本未超上限时分位数仍是精确值（不标记为近似）', () => {
  const m = new MetricsAggregator(Date.now(), { maxSamples: 1000, maxBucketSamples: 1000 });
  for (let i = 1; i <= 100; i += 1) m.record({ latencyMs: i, statusCode: 200 });

  const r = m.snapshot();
  assert.strictEqual(r.percentilesApproximate, false);
  assert.strictEqual(r.latency.sampleSize, 100);
  assert.strictEqual(r.latency.p95, 95);
});

test('P2-1 抽样状态下计数类指标仍然精确：直方图 / 状态码 / 错误率', () => {
  const m = new MetricsAggregator(Date.now(), { maxSamples: 50, maxBucketSamples: 20 });
  for (let i = 0; i < 500; i += 1) m.record({ latencyMs: 5, statusCode: 200 });
  for (let i = 0; i < 300; i += 1) m.record({ latencyMs: 15, statusCode: 404 });

  const r = m.snapshot();
  assert.strictEqual(r.total, 800);
  assert.strictEqual(r.success, 500);
  assert.strictEqual(r.failed, 300);
  assert.strictEqual(r.httpErrors, 300);
  assert.strictEqual(r.errorRate, 37.5);

  const bins = Object.fromEntries(r.histogram.map((b) => [b.label, b.count]));
  assert.strictEqual(bins['0-10'], 500, '直方图计数必须精确');
  assert.strictEqual(bins['10-20'], 300);
  assert.strictEqual(r.histogram.reduce((s, b) => s + b.count, 0), 800);

  const codes = Object.fromEntries(r.statusCodes.map((c) => [c.code, c.count]));
  assert.strictEqual(codes['200'], 500);
  assert.strictEqual(codes['404'], 300);
});

test('P2-1 抽样估计的分位数与精确值误差在可接受范围内', () => {
  const n = 20000;
  const m = new MetricsAggregator(Date.now(), { maxSamples: 2000, maxBucketSamples: 2000 });
  for (let i = 1; i <= n; i += 1) m.record({ latencyMs: i, statusCode: 200 });

  const sorted = [];
  for (let i = 1; i <= n; i += 1) sorted.push(i);
  sorted.sort((a, b) => a - b);
  const exactP95 = sorted[Math.ceil(0.95 * n) - 1];

  const { latency } = m.snapshot();
  const relError = Math.abs(latency.p95 - exactP95) / exactP95;
  assert.ok(relError < 0.03, `抽样 P95 相对误差应 < 3%，实际 ${(relError * 100).toFixed(2)}%（估计 ${latency.p95} / 精确 ${exactP95}）`);
});

test('P2-1 每秒时间序列：计数精确，桶内样本超限时标记为近似', () => {
  const m = new MetricsAggregator(Date.now(), { maxSamples: 100, maxBucketSamples: 10 });
  for (let i = 0; i < 200; i += 1) m.record({ latencyMs: 10, statusCode: 200 });

  const series = m.snapshot().series;
  assert.ok(series.length >= 1);
  const totalInSeries = series.reduce((s, p) => s + p.count, 0);
  assert.strictEqual(totalInSeries, 200, '每秒计数必须精确');
  assert.strictEqual(series[0].approximate, true, '桶内样本超限应标记近似');
});

// ---------------------------------------------------------------------------
// P1-2：被中止的请求单独计数，不进入总数与失败数
// ---------------------------------------------------------------------------

test('P1-2 aborted 请求单独计数，不计入总数、成功数与失败数', () => {
  const m = new MetricsAggregator(Date.now());
  m.record({ latencyMs: 10, statusCode: 200 });
  m.record({ latencyMs: 20, statusCode: null, errorType: 'aborted', errorMessage: '压测已停止，请求被中止' });

  const r = m.snapshot();
  assert.strictEqual(r.aborted, 1);
  assert.strictEqual(r.total, 1, '总数 = 成功 + 失败，不含 aborted');
  assert.strictEqual(r.success, 1);
  assert.strictEqual(r.failed, 0);
  assert.strictEqual(r.networkErrors, 0);
  assert.deepStrictEqual(r.errorTypes, {}, 'aborted 不属于失败类型');
  assert.deepStrictEqual(r.errorSamples, [], 'aborted 不进入错误明细');
});

// ---------------------------------------------------------------------------
// P2-4：错误消息归一化 —— 动态片段不再把同类错误拆成多条
// ---------------------------------------------------------------------------

test('P2-4 错误消息归一化：同类错误的动态片段合并为一条', () => {
  const m = new MetricsAggregator(Date.now());
  m.record({ latencyMs: 10, statusCode: null, errorType: 'network_error', errorMessage: 'connect ECONNREFUSED 127.0.0.1:54321' });
  m.record({ latencyMs: 11, statusCode: null, errorType: 'network_error', errorMessage: 'connect ECONNREFUSED 127.0.0.1:61002' });
  m.record({ latencyMs: 12, statusCode: null, errorType: 'network_error', errorMessage: 'connect ECONNREFUSED 127.0.0.1:60001' });

  const samples = m.snapshot().errorSamples;
  assert.strictEqual(samples.length, 1, '同类错误应合并为一条');
  assert.strictEqual(samples[0].count, 3);
  assert.strictEqual(samples[0].type, 'network_error');
});

test('P2-4 归一化不影响不同错误类型与不同状态码的区分', () => {
  const m = new MetricsAggregator(Date.now());
  m.record({ latencyMs: 10, statusCode: 500, errorType: 'http_error', errorMessage: 'HTTP 500' });
  m.record({ latencyMs: 11, statusCode: 502, errorType: 'http_error', errorMessage: 'HTTP 502' });
  m.record({ latencyMs: 12, statusCode: null, errorType: 'network_error', errorMessage: 'read ECONNRESET' });

  const samples = m.snapshot().errorSamples;
  assert.strictEqual(samples.length, 3);
});
