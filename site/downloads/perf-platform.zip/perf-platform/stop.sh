#!/usr/bin/env bash
#
# stop.sh —— 停止性能测试平台服务（按 PID 文件优雅停止：SIGTERM → 超时 SIGKILL）。
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${PORT:-8801}"
RUN_DIR="${RUN_DIR:-$DIR/run}"
PID_FILE="$RUN_DIR/server.pid"

log()  { printf '[stop.sh] %s\n' "$*"; }
fail() { printf '[stop.sh] 错误：%s\n' "$*" >&2; exit 1; }

if [ ! -f "$PID_FILE" ]; then
  log "未找到 PID 文件（${PID_FILE}），服务可能未由 start.sh 启动，未做任何操作。"
  exit 0
fi

PID="$(cat "$PID_FILE" 2>/dev/null || true)"
if [ -z "$PID" ] || ! kill -0 "$PID" 2>/dev/null; then
  log "进程不存在（PID: ${PID:-空}），清理 PID 文件。"
  rm -f "$PID_FILE"
  exit 0
fi

log "正在停止服务（PID ${PID}）…"
kill -TERM "$PID" 2>/dev/null || true

for _ in $(seq 1 40); do
  if ! kill -0 "$PID" 2>/dev/null; then
    rm -f "$PID_FILE"
    log "服务已停止。"
    exit 0
  fi
  sleep 0.25
done

log "优雅停止超时，发送 SIGKILL。"
kill -KILL "$PID" 2>/dev/null || true
sleep 0.5
rm -f "$PID_FILE"
log "服务已强制停止。"
