#!/usr/bin/env bash
#
# status.sh —— 查看服务状态：进程、端口监听、健康检查。
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${PORT:-8801}"
RUN_DIR="${RUN_DIR:-$DIR/run}"
PID_FILE="$RUN_DIR/server.pid"
NODE_BIN="${NODE_BIN:-node}"

echo "=========================================="
echo " 性能测试平台 · 服务状态"
echo "=========================================="
echo "部署路径：$DIR"
echo "访问地址：http://localhost:${PORT}"
echo "----------------------------------------------"

PID="无"
if [ -f "$PID_FILE" ]; then
  PID="$(cat "$PID_FILE" 2>/dev/null || echo 无)"
fi
echo "PID 文件：$PID_FILE"
if [ "$PID" != "无" ] && kill -0 "$PID" 2>/dev/null; then
  echo "进程状态：运行中（PID ${PID}）"
else
  echo "进程状态：未运行"
fi

echo -n "端口 ${PORT} 监听："
if command -v lsof >/dev/null 2>&1; then
  OUT="$(lsof -nP -iTCP:"$PORT" -sTCP:LISTEN 2>/dev/null || true)"
  if [ -n "$OUT" ]; then
    echo "是"
    echo "$OUT" | sed 's/^/    /'
  else
    echo "否"
  fi
else
  echo "（lsof 不可用，跳过）"
fi

echo "健康检查："
"$NODE_BIN" -e "
  fetch('http://127.0.0.1:${PORT}/api/health')
    .then(r => r.json())
    .then(d => console.log('    ' + JSON.stringify(d, null, 2).split('\n').join('\n    ')))
    .catch(e => { console.log('    无法访问服务：' + e.message); process.exitCode = 1; });
" 2>/dev/null || echo "    服务不可访问"
echo "=========================================="
