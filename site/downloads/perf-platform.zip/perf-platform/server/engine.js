'use strict';
/**
 * engine.js —— 并发压测引擎。
 *
 * 模型：固定 N 个 worker 循环发请求，直到超过设定时长或收到停止指令。
 * 传输：node:http / node:https 原生 request，agent:false（不启用 keep-alive）+ Connection: close，
 *       使单次延迟包含完整建连成本。
 * 失败口径：状态码 >= 400 → http_error；连接失败 / 超时 → network_error；3xx 不跟随，计为成功。
 *
 * 超时语义（P1-1）：单请求超时是**硬超时**——自请求发起起计时，超过 timeoutMs 立即销毁连接并记
 * network_error。仅依赖 req.setTimeout（socket 空闲超时）是不够的：目标只要持续缓慢吐数据就会不断
 * 重置该计时器，请求可以无限期挂住，实测会把 5s 的压测拖成 24s。
 *
 * 停止语义（P1-2）：stop() 会立即中止所有在途请求（AbortController），worker 随即退出，
 * 不再等待慢响应目标；被中止的请求记为 aborted，不计入成功/失败统计。
 */

const http = require('node:http');
const https = require('node:https');
const { URL } = require('node:url');

const { round2 } = require('./util');

/**
 * 由协议层接管、不接受用户覆盖的请求头（P2-2）。
 * - host：由 Node 依据 URL 自动生成，用户自带会造成重复 Host 头
 * - content-length：由引擎按请求体长度计算，用户自带会造成重复 Content-Length（服务端可能直接 400）
 * - connection：压测固定使用 close（不启用 keep-alive）
 */
const RESERVED_HEADERS = new Set(['host', 'content-length', 'connection']);

/**
 * 构造最终请求头：用户自定义头优先（大小写不敏感去重，后写覆盖先写），随后补齐默认值。
 * @param {Array<{name:string,value:string}>} headers
 */
function buildHeaders(headers) {
  const final = {};
  const lowerToKey = new Map(); // 小写名 -> 实际使用的键名
  for (const h of Array.isArray(headers) ? headers : []) {
    if (!h || typeof h.name !== 'string') continue;
    const lower = h.name.toLowerCase();
    if (RESERVED_HEADERS.has(lower)) continue; // 保留头由引擎统一控制
    const existingKey = lowerToKey.get(lower);
    if (existingKey) {
      final[existingKey] = h.value; // 同名不同大小写：覆盖值，保留首次的书写形式
      continue;
    }
    lowerToKey.set(lower, h.name);
    final[h.name] = h.value;
  }
  const has = (name) => lowerToKey.has(name);
  if (!has('user-agent')) final['User-Agent'] = 'perf-platform/1.0 (+node)';
  if (!has('accept')) final['Accept'] = '*/*';
  final['Connection'] = 'close'; // 固定不启用 keep-alive
  return final;
}

/**
 * 发起一次请求并结算计时。
 *
 * @param {object} options
 * @param {string} options.url
 * @param {string} options.method
 * @param {Array} [options.headers]
 * @param {string} [options.body]
 * @param {number} options.timeoutMs 硬超时（毫秒）
 * @param {AbortSignal} [options.signal] 外部中止信号（停止压测时触发）
 * @returns {Promise<{latencyMs:number, statusCode:number|null, errorType:string|null, errorMessage:string|null}>}
 *          errorType ∈ http_error | network_error | aborted
 */
function performRequest({ url, method, headers, body, timeoutMs, signal }) {
  return new Promise((resolve) => {
    const startedAt = process.hrtime.bigint();
    let settled = false;
    let hardTimer = null;
    let onAbort = null;

    const settle = (result) => {
      if (settled) return;
      settled = true;
      if (hardTimer) clearTimeout(hardTimer);
      if (onAbort && signal) signal.removeEventListener('abort', onAbort);
      const latencyMs = round2(Number(process.hrtime.bigint() - startedAt) / 1e6);
      resolve({ latencyMs, ...result });
    };

    let target;
    try {
      target = new URL(url);
    } catch (err) {
      settle({ statusCode: null, errorType: 'network_error', errorMessage: `URL 非法: ${err.message}` });
      return;
    }

    const lib = target.protocol === 'https:' ? https : http;
    const requestHeaders = buildHeaders(Array.isArray(headers) ? headers : []);
    if (method !== 'GET' && method !== 'HEAD') {
      requestHeaders['Content-Length'] = String(Buffer.byteLength(body || '', 'utf8'));
    }

    const req = lib.request(
      {
        protocol: target.protocol,
        hostname: target.hostname,
        port: target.port || (target.protocol === 'https:' ? 443 : 80),
        path: `${target.pathname}${target.search}`,
        method,
        headers: requestHeaders,
        agent: false, // 每次请求新建连接，不启用 keep-alive
      },
      (res) => {
        res.resume(); // 丢弃响应体，立即释放连接
        // 中止信号已触发时，响应侧的报错也归类为 aborted，避免被误计为失败
        const abortedNow = () => !!(signal && signal.aborted);
        res.on('error', (err) => {
          settle(abortedNow()
            ? { statusCode: null, errorType: 'aborted', errorMessage: '压测已停止，请求被中止' }
            : { statusCode: null, errorType: 'network_error', errorMessage: err.message });
        });
        res.on('aborted', () => {
          settle(abortedNow()
            ? { statusCode: null, errorType: 'aborted', errorMessage: '压测已停止，请求被中止' }
            : { statusCode: null, errorType: 'network_error', errorMessage: '响应被提前中断' });
        });
        res.on('end', () => {
          // 状态码 >= 400 记 http_error 失败；3xx 不跟随，原样计入状态码分布并计为成功
          const status = res.statusCode;
          const failed = typeof status === 'number' && status >= 400;
          settle({
            statusCode: status,
            errorType: failed ? 'http_error' : null,
            errorMessage: failed ? `HTTP ${status}` : null,
          });
        });
      },
    );

    // 硬超时：自请求发起起计时，到点立即销毁连接（不等 socket 空闲）。
    hardTimer = setTimeout(() => {
      req.destroy(new Error(`请求超时（>${timeoutMs}ms）`));
    }, timeoutMs);

    // 外部中止（停止压测）：立即销毁连接，worker 不再等待慢响应。
    if (signal) {
      onAbort = () => {
        req.destroy(new Error('压测已停止，请求被中止'));
      };
      if (signal.aborted) {
        onAbort();
      } else {
        signal.addEventListener('abort', onAbort, { once: true });
      }
    }

    req.on('error', (err) => {
      const aborted = signal && signal.aborted;
      settle({
        statusCode: null,
        errorType: aborted ? 'aborted' : 'network_error',
        errorMessage: aborted ? '压测已停止，请求被中止' : err.message,
      });
    });

    if (method !== 'GET' && method !== 'HEAD' && body) req.write(body);
    req.end();
  });
}

/**
 * 一次压测运行。run 对象由调用方（store / api）创建并传入。
 */
class RunEngine {
  /**
   * @param {object} options
   * @param {object} options.task 任务定义（url/method/headers/body/timeoutMs/concurrency/durationSec）
   * @param {object} options.run  运行记录（会被写入 startedAt / endedAt / status）
   * @param {object} options.metrics MetricsAggregator 实例
   * @param {function} [options.onFinish] 运行结束回调 (run) => void
   */
  constructor({ task, run, metrics, onFinish }) {
    this.task = task;
    this.run = run;
    this.metrics = metrics;
    this.onFinish = onFinish || (() => {});
    this.stopping = false;
    this.stopReason = null;
    this.deadline = 0;
    this.workers = [];
    this.finished = false;
    this.controllers = new Set(); // 在途请求的中止句柄（P1-2）
  }

  start() {
    this.deadline = Date.now() + this.task.durationSec * 1000;
    this.workers = Array.from({ length: this.task.concurrency }, () => this.worker());
    this.done = Promise.all(this.workers).then(() => this.finalize());
    return this.done;
  }

  /**
   * 停止发新请求，并立即中止在途请求（P1-2）。
   * 不再等待慢响应目标结算，停止即时生效。
   */
  stop(reason = '手动停止') {
    if (this.stopping) return;
    this.stopping = true;
    this.stopReason = reason;
    for (const controller of [...this.controllers]) {
      try {
        controller.abort();
      } catch {
        /* 忽略单个中止失败 */
      }
    }
    this.controllers.clear();
  }

  async worker() {
    while (!this.stopping && Date.now() < this.deadline) {
      const controller = new AbortController();
      this.controllers.add(controller);
      let result;
      try {
        result = await performRequest({
          url: this.task.url,
          method: this.task.method,
          headers: this.task.headers,
          body: this.task.body,
          timeoutMs: this.task.timeoutMs,
          signal: controller.signal,
        });
      } finally {
        this.controllers.delete(controller);
      }
      // aborted（停止导致）不计入成功/失败统计，由聚合器单独计数
      this.metrics.record(result);
    }
  }

  finalize() {
    if (this.finished) return this.run;
    this.finished = true;
    this.metrics.endedAt = Date.now();
    this.run.endedAt = this.metrics.endedAt;
    this.run.durationSec = this.metrics.elapsedSec();
    this.run.status = this.stopping ? 'stopped' : 'completed';
    this.run.stopReason = this.stopping ? this.stopReason : null;
    this.onFinish(this.run);
    return this.run;
  }
}

module.exports = {
  RunEngine,
  buildHeaders,
  performRequest,
};
