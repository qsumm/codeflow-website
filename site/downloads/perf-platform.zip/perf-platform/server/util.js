'use strict';
/**
 * util.js —— 公共工具：错误类型、ID 生成、JSON 体读取、参数校验。
 * 零第三方依赖，仅使用 Node 标准库。
 */

const crypto = require('node:crypto');

const METHODS = ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'HEAD'];

/** 参数护栏（与需求澄清 §2.1 / §3.4 一致） */
const LIMITS = {
  concurrency: { min: 1, max: 200, default: 20 },
  durationSec: { min: 1, max: 600, default: 10 },
  timeoutMs: { min: 100, max: 60000, default: 10000 },
  nameMaxLen: 64,
  bodyMaxBytes: 1024 * 1024,
  jsonMaxBytes: 1024 * 1024,
};

/** 统一的 HTTP 业务错误 */
class HttpError extends Error {
  constructor(code, message, status = 400, fields = null) {
    super(message);
    this.name = 'HttpError';
    this.code = code;
    this.status = status;
    this.fields = fields;
  }
  toJSON() {
    const error = { code: this.code, message: this.message };
    if (this.fields && Object.keys(this.fields).length > 0) error.fields = this.fields;
    return { error };
  }
}

function newId(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${crypto.randomBytes(5).toString('hex')}`;
}

function nowMs() {
  return Date.now();
}

function round2(n) {
  return Math.round(n * 100) / 100;
}

/** 读取并解析 JSON 请求体（带体积上限） */
function readJsonBody(req, limit = LIMITS.jsonMaxBytes) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    let done = false;
    req.on('data', (chunk) => {
      if (done) return;
      size += chunk.length;
      if (size > limit) {
        done = true;
        reject(new HttpError('INVALID_PARAM', `请求体过大（上限 ${limit} 字节）`, 413));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      if (done) return;
      done = true;
      const raw = Buffer.concat(chunks).toString('utf8').trim();
      if (!raw) return resolve({});
      try {
        const parsed = JSON.parse(raw);
        resolve(parsed);
      } catch {
        reject(new HttpError('INVALID_PARAM', '请求体不是合法 JSON', 400));
      }
    });
    req.on('error', (err) => {
      if (done) return;
      done = true;
      reject(err);
    });
  });
}

function isPlainObject(v) {
  return !!v && typeof v === 'object' && !Array.isArray(v);
}

/**
 * 校验并归一化压测任务输入。校验失败抛出 HttpError(INVALID_PARAM, ..., 400, fields)。
 */
function validateTaskInput(input) {
  if (!isPlainObject(input)) {
    throw new HttpError('INVALID_PARAM', '请求体必须是 JSON 对象', 400, {});
  }

  const fields = {};
  const out = {};

  // ---- 名称（可选） ----
  if (input.name === undefined || input.name === null) {
    out.name = '';
  } else if (typeof input.name !== 'string') {
    fields.name = '名称必须是字符串';
  } else if (input.name.trim().length > LIMITS.nameMaxLen) {
    fields.name = `名称长度不能超过 ${LIMITS.nameMaxLen} 个字符`;
  } else {
    out.name = input.name.trim();
  }

  // ---- 目标 URL（必填，限 http/https） ----
  const url = typeof input.url === 'string' ? input.url.trim() : '';
  if (!url) {
    fields.url = '目标 URL 不能为空';
  } else {
    let parsed = null;
    try {
      parsed = new URL(url);
    } catch {
      fields.url = 'URL 格式非法';
    }
    if (parsed && parsed.protocol !== 'http:' && parsed.protocol !== 'https:') {
      fields.url = '仅支持 http / https 协议';
    }
  }
  out.url = url;

  // ---- 并发数 ----
  const concurrency = pickNumber(input.concurrency, LIMITS.concurrency.default);
  if (!Number.isInteger(concurrency) || concurrency < LIMITS.concurrency.min || concurrency > LIMITS.concurrency.max) {
    fields.concurrency = `并发数必须是 ${LIMITS.concurrency.min}–${LIMITS.concurrency.max} 的整数`;
  }
  out.concurrency = concurrency;

  // ---- 持续时间（秒） ----
  const durationSec = pickNumber(input.durationSec, LIMITS.durationSec.default);
  if (!Number.isInteger(durationSec) || durationSec < LIMITS.durationSec.min || durationSec > LIMITS.durationSec.max) {
    fields.durationSec = `持续时间必须是 ${LIMITS.durationSec.min}–${LIMITS.durationSec.max} 秒的整数`;
  }
  out.durationSec = durationSec;

  // ---- 请求方法 ----
  const method = typeof input.method === 'string' && input.method.trim()
    ? input.method.trim().toUpperCase()
    : 'GET';
  if (!METHODS.includes(method)) {
    fields.method = `请求方法必须是 ${METHODS.join(' / ')} 之一`;
  }
  out.method = method;

  // ---- 单请求超时 ----
  const timeoutMs = pickNumber(input.timeoutMs, LIMITS.timeoutMs.default);
  if (!Number.isInteger(timeoutMs) || timeoutMs < LIMITS.timeoutMs.min || timeoutMs > LIMITS.timeoutMs.max) {
    fields.timeoutMs = `超时必须是 ${LIMITS.timeoutMs.min}–${LIMITS.timeoutMs.max} 毫秒的整数`;
  }
  out.timeoutMs = timeoutMs;

  // ---- 自定义请求头 ----
  const headers = [];
  if (input.headers !== undefined && input.headers !== null) {
    if (!Array.isArray(input.headers)) {
      fields.headers = '请求头必须是数组';
    } else {
      input.headers.forEach((h, idx) => {
        const pos = `第 ${idx + 1} 个`;
        if (!isPlainObject(h)) {
          fields.headers = `${pos}请求头格式非法`;
          return;
        }
        const name = typeof h.name === 'string' ? h.name.trim() : '';
        const value = h.value === undefined || h.value === null ? '' : String(h.value);
        if (!name) {
          fields.headers = `${pos}请求头名称不能为空`;
          return;
        }
        if (!/^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/.test(name)) {
          fields.headers = `${pos}请求头名称非法：${name}`;
          return;
        }
        headers.push({ name, value });
      });
    }
  }
  out.headers = headers;

  // ---- 请求体（仅非 GET/HEAD 生效） ----
  let body = '';
  if (input.body !== undefined && input.body !== null) {
    if (typeof input.body !== 'string') {
      fields.body = '请求体必须是文本';
    } else {
      body = input.body;
      if (Buffer.byteLength(body, 'utf8') > LIMITS.bodyMaxBytes) {
        fields.body = `请求体过大（上限 ${LIMITS.bodyMaxBytes} 字节）`;
      }
    }
  }
  out.body = body;

  if (Object.keys(fields).length > 0) {
    throw new HttpError('INVALID_PARAM', '参数校验失败', 400, fields);
  }
  return out;
}

function pickNumber(value, fallback) {
  if (value === undefined || value === null || value === '') return fallback;
  if (typeof value === 'number') return value;
  const parsed = Number(value);
  return Number.isNaN(parsed) ? NaN : parsed;
}

/** 生成不含请求体/请求头的任务摘要（供列表与历史展示） */
function taskSummary(task, extra = {}) {
  return {
    id: task.id,
    name: task.name,
    url: task.url,
    method: task.method,
    concurrency: task.concurrency,
    durationSec: task.durationSec,
    timeoutMs: task.timeoutMs,
    headerCount: Array.isArray(task.headers) ? task.headers.length : 0,
    hasBody: !!(task.body && task.body.length),
    createdAt: task.createdAt,
    ...extra,
  };
}

module.exports = {
  HttpError,
  LIMITS,
  METHODS,
  isPlainObject,
  newId,
  nowMs,
  pickNumber,
  readJsonBody,
  round2,
  taskSummary,
  validateTaskInput,
};
