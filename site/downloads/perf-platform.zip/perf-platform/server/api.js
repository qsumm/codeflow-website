'use strict';
/**
 * api.js —— REST 路由与 SSE 实时推送。
 *
 * 约定：所有错误统一返回 { "error": { "code", "message", "fields?" } }。
 */

const { HttpError, readJsonBody, taskSummary } = require('./util');

const SSE_INTERVAL_MS = 500;

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function sendError(res, err) {
  if (err instanceof HttpError) {
    sendJson(res, err.status, err.toJSON());
    return;
  }
  sendJson(res, 500, { error: { code: 'INTERNAL', message: err && err.message ? err.message : '服务器内部错误' } });
}

function runSummary(run, report) {
  const r = report || run.report || {};
  return {
    id: run.id,
    taskId: run.taskId,
    taskName: run.task && run.task.name ? run.task.name : '',
    url: run.task ? run.task.url : '',
    method: run.task ? run.task.method : 'GET',
    concurrency: run.task ? run.task.concurrency : null,
    durationSec: run.task ? run.task.durationSec : null,
    status: run.status,
    startedAt: run.startedAt,
    endedAt: run.endedAt,
    actualDurationSec: run.durationSec || (r.durationSec ?? null),
    total: r.total ?? 0,
    success: r.success ?? 0,
    failed: r.failed ?? 0,
    aborted: r.aborted ?? 0,
    qps: r.qps ?? 0,
    p95: r.latency ? r.latency.p95 : null,
    p99: r.latency ? r.latency.p99 : null,
    errorRate: r.errorRate ?? 0,
    error: run.error || null,
  };
}

/**
 * @param {object} deps
 * @param {import('./store').Store} deps.store
 * @param {function} deps.startRun (task) => run
 * @param {string} [deps.token] 可选访问令牌：设置后除 /api/health 外所有接口都需携带
 *   （请求头 `X-Perf-Token` 或查询参数 `?token=`），用于把平台收敛到本机/可信网络内使用（P2-2）
 */
function createApi({ store, startRun, version, token }) {
  async function handle(req, res, url) {
    const pathname = url.pathname;
    const method = req.method;

    // ------------------------------------------------------------ 健康检查
    if (method === 'GET' && pathname === '/api/health') {
      const stats = store.stats();
      sendJson(res, 200, {
        status: 'ok',
        version,
        uptimeSec: Math.round(process.uptime()),
        runningTasks: stats.running,
        tasks: stats.tasks,
        runs: stats.runs,
        now: Date.now(),
      });
      return true;
    }

    // ------------------------------------------------------- 访问令牌校验
    // 健康检查保持公开（供 start.sh / status.sh 探活），其余接口需携带令牌（若配置了 PERF_TOKEN）
    authorize(req, url);

    // ------------------------------------------------------------ 任务
    if (method === 'GET' && pathname === '/api/tasks') {
      const tasks = store.listTasks().map((task) => {
        const running = store.listRuns().some((run) => run.taskId === task.id && run.status === 'running');
        return taskSummary(task, { status: running ? 'running' : 'idle' });
      });
      sendJson(res, 200, { tasks });
      return true;
    }

    if (method === 'POST' && pathname === '/api/tasks') {
      const body = await readJsonBody(req);
      const task = store.createTask(body); // 校验失败在此抛出 HttpError
      sendJson(res, 201, { task: taskSummary(task, { status: 'idle' }) });
      return true;
    }

    const taskMatch = pathname.match(/^\/api\/tasks\/([^/]+)$/);
    if (taskMatch && method === 'DELETE') {
      const result = store.deleteTask(decodeURIComponent(taskMatch[1]));
      sendJson(res, 200, result);
      return true;
    }

    // ------------------------------------------------------------ 运行
    if (method === 'GET' && pathname === '/api/runs') {
      const runs = store.listRuns().map((run) => runSummary(run, store.liveReport(run.id)));
      sendJson(res, 200, { runs });
      return true;
    }

    if (method === 'POST' && pathname === '/api/runs') {
      const body = await readJsonBody(req);
      const taskId = typeof body.taskId === 'string' ? body.taskId.trim() : '';
      if (!taskId) throw new HttpError('INVALID_PARAM', '缺少 taskId', 400, { taskId: '不能为空' });
      const task = store.getTask(taskId);
      if (!task) throw new HttpError('NOT_FOUND', '任务不存在', 404);
      const run = startRun(task);
      sendJson(res, 202, { run: runSummary(run) });
      return true;
    }

    const stopMatch = pathname.match(/^\/api\/runs\/([^/]+)\/stop$/);
    if (stopMatch && method === 'POST') {
      const runId = decodeURIComponent(stopMatch[1]);
      const run = store.getRun(runId);
      if (!run) throw new HttpError('NOT_FOUND', '运行记录不存在', 404);
      if (run.status !== 'running') {
        throw new HttpError('CONFLICT', `运行已结束（状态：${run.status}），无法停止`, 409);
      }
      const engine = store.getEngine(runId);
      if (engine) engine.stop('手动停止');
      sendJson(res, 200, { run: runSummary(run) });
      return true;
    }

    const streamMatch = pathname.match(/^\/api\/runs\/([^/]+)\/stream$/);
    if (streamMatch && method === 'GET') {
      streamRun(req, res, decodeURIComponent(streamMatch[1]));
      return true;
    }

    const runMatch = pathname.match(/^\/api\/runs\/([^/]+)$/);
    if (runMatch && method === 'GET') {
      const runId = decodeURIComponent(runMatch[1]);
      const run = store.getRun(runId);
      if (!run) throw new HttpError('NOT_FOUND', '运行记录不存在', 404);
      const report = store.liveReport(runId) || run.report;
      sendJson(res, 200, { run: { ...runSummary(run, report), report } });
      return true;
    }

    return false;
  }

  /**
   * 访问令牌校验（P2-2）：仅在配置了 PERF_TOKEN 时生效；
   * 令牌可通过请求头 `X-Perf-Token` 或查询参数 `?token=` 携带（EventSource 不能自定义请求头）。
   */
  function authorize(req, url) {
    if (!token) return;
    const header = req.headers['x-perf-token'];
    const query = url.searchParams.get('token');
    const provided = typeof header === 'string' && header ? header : query;
    if (provided !== token) {
      throw new HttpError('UNAUTHORIZED', '缺少或错误的访问令牌（请在请求头 X-Perf-Token 或 ?token= 中携带）', 401);
    }
  }

  /** SSE：每 500ms 推送一帧增量统计，结束时推 done 帧 */
  function streamRun(req, res, runId) {
    const run = store.getRun(runId);
    if (!run) {
      sendJson(res, 404, { error: { code: 'NOT_FOUND', message: '运行记录不存在' } });
      return;
    }

    res.writeHead(200, {
      'Content-Type': 'text/event-stream; charset=utf-8',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    });

    let closed = false;
    const write = (event, payload) => {
      if (closed) return;
      res.write(`event: ${event}\n`);
      res.write(`data: ${JSON.stringify(payload)}\n\n`);
    };

    const pushStats = () => {
      const report = store.liveReport(runId);
      write('stats', { runId, status: run.status, report });
    };

    pushStats();

    const timer = setInterval(() => {
      if (closed) return;
      const current = store.getRun(runId);
      if (!current) {
        write('done', { runId, status: 'failed', report: null });
        clearInterval(timer);
        res.end();
        return;
      }
      if (current.status !== 'running') {
        clearInterval(timer);
        const report = current.report;
        write('done', { runId, status: current.status, report });
        res.end();
        closed = true;
        return;
      }
      pushStats();
    }, SSE_INTERVAL_MS);

    req.on('close', () => {
      closed = true;
      clearInterval(timer);
    });
  }

  return { handle };
}

module.exports = { createApi, sendJson, sendError, runSummary };
