'use strict';
/**
 * metrics.js —— 指标聚合器：计数、延迟分位、错误率、每秒时间序列、状态码分布、延迟直方图、错误明细摘要。
 *
 * 口径（与需求澄清 §3.4 一致）：
 *  - 总请求数 = 成功数 + 失败数（失败含 network_error / http_error；被停止中止的请求不计入总数）
 *  - 成功 = 2xx / 3xx（3xx 不跟随，原样计入状态码分布）
 *  - 失败 = 状态码 >= 400 或连接失败/超时
 *  - QPS(总) = 总请求数 / 实际压测时长；成功 QPS = 成功数 / 实际压测时长
 *  - 错误率 = 失败数 / 总请求数（总数为 0 记 0）
 *  - 分位数：最近秩法 index = ceil(p/100 * n) - 1
 *
 * 性能约定（P2-1）：
 *  1) 分位数用 quickselect（平均 O(n)）计算，口径与「最近秩法对升序数组取下标」完全等价
 *     （等价性断言见 tests/metrics.test.js）。
 *  2) 延迟样本**有上限**：全局最多保留 MAX_SAMPLES 个、每秒桶最多保留 MAX_BUCKET_SAMPLES 个，
 *     超出后用蓄水池抽样（Algorithm R，均匀无偏）替换。原因是长时高并发压测（如 600s × 高 QPS）
 *     会产生数百万样本，全量驻留会让内存峰值达到数百 MB，且每 500ms 的报告快照都要复制全量数组，
 *     与压测本身抢 CPU、虚高被测延迟。
 *     - 计数类指标（总数/成功/失败/QPS/错误率/状态码分布/直方图/avg/min/max）**始终精确**：
 *       直方图改为增量计数，不依赖样本数组。
 *     - 分位数在样本未超限时**完全精确**；超限时为抽样估计，报告中以
 *       `percentilesApproximate=true` 与 `percentileSampleSize` 显式标注，前端显示「≈」。
 */

const { round2 } = require('./util');

/** 延迟直方图固定分桶（ms）：0-10 / 10-20 / ... / >=1000 */
const HISTOGRAM_EDGES = [10, 20, 30, 40, 50, 75, 100, 150, 200, 300, 400, 500, 750, 1000];

/** 错误明细摘要：最多保留的不同错误条目数 / 报告中展示条数 */
const MAX_ERROR_SAMPLE_KEYS = 50;
const MAX_ERROR_SAMPLES = 20;

/** 延迟样本上限（P2-1）：全局样本 / 每秒桶样本 */
const MAX_SAMPLES = 500000;
const MAX_BUCKET_SAMPLES = 2000;

function histogramLabels() {
  const labels = [];
  let lower = 0;
  for (const edge of HISTOGRAM_EDGES) {
    labels.push({ label: `${lower}-${edge}`, min: lower, max: edge });
    lower = edge;
  }
  labels.push({ label: `>=${HISTOGRAM_EDGES[HISTOGRAM_EDGES.length - 1]}`, min: HISTOGRAM_EDGES[HISTOGRAM_EDGES.length - 1], max: Infinity });
  return labels;
}

/**
 * 蓄水池抽样（Algorithm R）。
 * 样本数不超过 cap 时全量保留；超过后按均匀概率替换既有样本，
 * 因此保留的样本是全量样本的无偏均匀子集，分位数估计误差随 1/sqrt(n) 收敛。
 */
class Reservoir {
  constructor(cap) {
    this.cap = Math.max(1, cap);
    this.items = [];
    this.seen = 0; // 已见样本总数（含被替换掉的）
  }

  push(value) {
    this.seen += 1;
    if (this.items.length < this.cap) {
      this.items.push(value);
      return;
    }
    const j = Math.floor(Math.random() * this.seen);
    if (j < this.cap) this.items[j] = value;
  }

  /** 当前保留的样本数 */
  get size() {
    return this.items.length;
  }

  /** 是否发生过抽样（true 表示分位数为估计值） */
  get sampled() {
    return this.seen > this.cap;
  }

  copy() {
    return this.items.slice();
  }
}

/** 三数取中位数，作为 quickselect 的 pivot 选择 */
function medianOfThree(arr, lo, mid, hi) {
  if (arr[lo] < arr[mid]) {
    if (arr[mid] < arr[hi]) return arr[mid];
    return arr[lo] < arr[hi] ? arr[hi] : arr[lo];
  }
  if (arr[lo] < arr[hi]) return arr[lo];
  return arr[mid] < arr[hi] ? arr[hi] : arr[mid];
}

/**
 * quickselect：就地选出数组中第 k 小的元素（k 从 0 开始），平均 O(n)。
 * 只会交换元素、不丢元素，因此同一数组可连续用于多个分位数的选取。
 * @param {number[]} arr 会被就地重排的数组
 * @param {number} k 目标下标（0 起）
 */
function selectKth(arr, k) {
  const n = arr.length;
  if (n === 0) return undefined;
  if (k < 0) k = 0;
  if (k > n - 1) k = n - 1;

  let lo = 0;
  let hi = n - 1;
  while (lo < hi) {
    const mid = (lo + hi) >> 1;
    const pivot = medianOfThree(arr, lo, mid, hi);
    let i = lo;
    let j = hi;
    while (i <= j) {
      while (arr[i] < pivot) i += 1;
      while (arr[j] > pivot) j -= 1;
      if (i <= j) {
        const tmp = arr[i];
        arr[i] = arr[j];
        arr[j] = tmp;
        i += 1;
        j -= 1;
      }
    }
    if (k <= j) hi = j;
    else if (k >= i) lo = i;
    else break;
  }
  return arr[k];
}

/** 最近秩法下标：index = ceil(p/100 * n) - 1 */
function nearestRankIndex(p, n) {
  return Math.max(0, Math.ceil((p / 100) * n) - 1);
}

/**
 * 最近秩分位数。入参可以是任意顺序（内部复制后 quickselect，不改写调用方数组）。
 * @param {number[]} values
 * @param {number} p 百分位（0–100）
 */
function percentileOf(values, p) {
  if (!values || !values.length) return null;
  const index = nearestRankIndex(p, values.length);
  return round2(selectKth([...values], index));
}

function averageOf(values) {
  if (!values.length) return null;
  let sum = 0;
  for (const v of values) sum += v;
  return round2(sum / values.length);
}

/**
 * 错误消息归一化（P2-4）：
 * 连接类错误消息常含随机端口、地址、长度等动态片段，直接按原文聚合会把同类错误拆成多条。
 * 这里把 IP:port、端口号、纯数字统一替换为占位符，保证同类错误聚合到同一条。
 */
function normalizeErrorMessage(message) {
  return String(message || '')
    .replace(/\b\d{1,3}(?:\.\d{1,3}){3}(?::\d+)?\b/g, '<addr>')
    .replace(/:\d{2,5}\b/g, ':<port>')
    .replace(/\b\d+\b/g, '#');
}

/** 延迟值所属的直方图桶下标（与 histogramLabels() 的分桶语义严格一致） */
function histogramIndex(latency) {
  for (let i = 0; i < HISTOGRAM_EDGES.length; i += 1) {
    if (latency < HISTOGRAM_EDGES[i]) return i;
  }
  return HISTOGRAM_EDGES.length; // >= 1000
}

class MetricsAggregator {
  /**
   * @param {number} [startedAt]
   * @param {object} [options]
   * @param {number} [options.maxSamples] 全局延迟样本上限（测试可调小）
   * @param {number} [options.maxBucketSamples] 每秒桶延迟样本上限（测试可调小）
   */
  constructor(startedAt = Date.now(), options = {}) {
    this.startedAt = startedAt;
    this.endedAt = null;
    this.total = 0;
    this.success = 0;
    this.failed = 0;
    this.httpErrors = 0;
    this.networkErrors = 0;
    this.aborted = 0;          // 被「停止压测」中止的请求数（不计入总数与失败数）
    this.latencySum = 0;         // 增量维护，避免每次快照重算
    this.minLatency = null;
    this.maxLatency = null;
    this.maxSamples = options.maxSamples || MAX_SAMPLES;
    this.maxBucketSamples = options.maxBucketSamples || MAX_BUCKET_SAMPLES;
    this.latencyReservoir = new Reservoir(this.maxSamples);       // 全部请求的延迟样本
    this.successReservoir = new Reservoir(this.maxSamples);       // 仅成功请求的延迟样本
    this.statusCodes = new Map(); // code -> { code, count, success, failed }
    this.errorTypes = new Map();  // 'http_error' | 'network_error' -> count
    this.errorSamples = new Map();// key -> { type, message, statusCode, count, lastAt }
    this.buckets = new Map();     // 秒偏移 -> { second, count, success, failed, reservoir }
    this.histogramCounts = new Array(HISTOGRAM_EDGES.length + 1).fill(0); // 精确计数
  }

  /** 记录一次已完成请求 */
  record({ latencyMs, statusCode = null, errorType = null, errorMessage = null } = {}) {
    const latency = typeof latencyMs === 'number' && Number.isFinite(latencyMs) ? latencyMs : 0;
    const code = typeof statusCode === 'number' ? statusCode : null;
    // 失败类型归一：显式 errorType 优先；否则状态码 >= 400 记 http_error
    const type = errorType || (code !== null && code >= 400 ? 'http_error' : null);

    // 被停止压测中止的请求：既不是成功也不是目标失败，单独计数，不进入总数
    if (type === 'aborted') {
      this.aborted += 1;
      return;
    }

    const ok = !type && code !== null && code < 400;

    this.total += 1;
    this.latencySum += latency;
    if (this.minLatency === null || latency < this.minLatency) this.minLatency = latency;
    if (this.maxLatency === null || latency > this.maxLatency) this.maxLatency = latency;

    if (ok) {
      this.success += 1;
      this.successReservoir.push(latency);
    } else {
      this.failed += 1;
      if (type === 'network_error') this.networkErrors += 1;
      else this.httpErrors += 1;
    }
    this.latencyReservoir.push(latency);

    if (code !== null) {
      const key = String(code);
      let entry = this.statusCodes.get(key);
      if (!entry) {
        entry = { code: key, count: 0, success: 0, failed: 0 };
        this.statusCodes.set(key, entry);
      }
      entry.count += 1;
      if (ok) entry.success += 1;
      else entry.failed += 1;
    }

    if (type) {
      this.errorTypes.set(type, (this.errorTypes.get(type) || 0) + 1);
      this._recordErrorSample(type, code, errorMessage);
    }

    // 精确直方图计数
    this.histogramCounts[histogramIndex(latency)] += 1;

    const second = Math.max(0, Math.floor((Date.now() - this.startedAt) / 1000));
    let bucket = this.buckets.get(second);
    if (!bucket) {
      bucket = { second, count: 0, success: 0, failed: 0, reservoir: new Reservoir(this.maxBucketSamples) };
      this.buckets.set(second, bucket);
    }
    bucket.count += 1;
    if (ok) bucket.success += 1;
    else bucket.failed += 1;
    bucket.reservoir.push(latency);
  }

  /**
   * 错误明细摘要：按「类型 + 状态码 + 归一化消息」聚合（P2-4），
   * 保留出现次数与最近发生时间；展示文案取首次见到的原始消息。
   */
  _recordErrorSample(type, code, errorMessage) {
    const message = errorMessage || (type === 'http_error' ? `HTTP ${code}` : '请求失败');
    const key = `${type}|${code === null ? '-' : code}|${normalizeErrorMessage(message)}`;
    const existing = this.errorSamples.get(key);
    if (existing) {
      existing.count += 1;
      existing.lastAt = Date.now();
      return;
    }
    if (this.errorSamples.size >= MAX_ERROR_SAMPLE_KEYS) return; // 超过上限不再新增不同条目
    this.errorSamples.set(key, {
      type,
      message,
      normalized: normalizeErrorMessage(message),
      statusCode: code,
      count: 1,
      lastAt: Date.now(),
    });
  }

  /** 当前已用时（秒） */
  elapsedSec() {
    const end = this.endedAt || Date.now();
    return Math.max(0.001, (end - this.startedAt) / 1000);
  }

  /** 生成完整报告快照（可 JSON 序列化） */
  snapshot() {
    const elapsed = this.elapsedSec();
    const durationSec = round2(elapsed);

    const qps = round2(this.total / elapsed);
    const successQps = round2(this.success / elapsed);
    const errorRate = this.total > 0 ? round2((this.failed / this.total) * 100) : 0;

    // 复制一次后连续取多个分位数（quickselect 原地分区不丢元素）
    const latencies = this.latencyReservoir.size ? this.latencyReservoir.copy() : [];
    const successLatencies = this.successReservoir.size ? this.successReservoir.copy() : [];
    const approximate = this.latencyReservoir.sampled || this.successReservoir.sampled;

    const latency = {
      avg: this.total > 0 ? round2(this.latencySum / this.total) : null,
      min: this.minLatency === null ? null : round2(this.minLatency),
      max: this.maxLatency === null ? null : round2(this.maxLatency),
      p50: latencies.length ? round2(selectKth(latencies, nearestRankIndex(50, latencies.length))) : null,
      p90: latencies.length ? round2(selectKth(latencies, nearestRankIndex(90, latencies.length))) : null,
      p95: latencies.length ? round2(selectKth(latencies, nearestRankIndex(95, latencies.length))) : null,
      p99: latencies.length ? round2(selectKth(latencies, nearestRankIndex(99, latencies.length))) : null,
      successP95: successLatencies.length
        ? round2(selectKth(successLatencies, nearestRankIndex(95, successLatencies.length)))
        : null,
      samples: this.total,
      sampleSize: latencies.length,
      approximate,
    };

    return {
      startedAt: this.startedAt,
      endedAt: this.endedAt,
      durationSec,
      total: this.total,
      success: this.success,
      failed: this.failed,
      httpErrors: this.httpErrors,
      networkErrors: this.networkErrors,
      aborted: this.aborted,
      qps,
      successQps,
      tps: qps,
      errorRate,
      latency,
      percentilesApproximate: approximate,
      percentileSampleSize: latencies.length,
      errorTypes: Object.fromEntries(this.errorTypes),
      errorSamples: [...this.errorSamples.values()]
        .sort((a, b) => b.count - a.count || b.lastAt - a.lastAt)
        .slice(0, MAX_ERROR_SAMPLES),
      statusCodes: [...this.statusCodes.values()].sort((a, b) => Number(a.code) - Number(b.code)),
      histogram: this.histogram(),
      series: this.series(),
    };
  }

  /** 延迟直方图（固定分桶，增量计数，始终精确） */
  histogram() {
    const labels = histogramLabels();
    return labels.map((b, i) => ({ label: b.label, min: b.min, count: this.histogramCounts[i] || 0 }));
  }

  /** 每秒时间序列（QPS / 成功率 / 分位数） */
  series() {
    const keys = [...this.buckets.keys()].sort((a, b) => a - b);
    return keys.map((second) => {
      const bucket = this.buckets.get(second);
      const latencies = bucket.reservoir.size ? bucket.reservoir.copy() : [];
      const pick = (p) => (latencies.length ? round2(selectKth(latencies, nearestRankIndex(p, latencies.length))) : null);
      return {
        second,
        count: bucket.count,
        success: bucket.success,
        failed: bucket.failed,
        qps: round2(bucket.count),
        p50: pick(50),
        p95: pick(95),
        p99: pick(99),
        approximate: bucket.reservoir.sampled,
      };
    });
  }
}

module.exports = {
  HISTOGRAM_EDGES,
  MAX_ERROR_SAMPLES,
  MAX_SAMPLES,
  MAX_BUCKET_SAMPLES,
  MetricsAggregator,
  Reservoir,
  averageOf,
  histogramIndex,
  histogramLabels,
  nearestRankIndex,
  normalizeErrorMessage,
  percentileOf,
  selectKth,
};
