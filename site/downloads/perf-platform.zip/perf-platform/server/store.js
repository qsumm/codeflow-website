'use strict';
/**
 * store.js —— 任务 / 运行记录的内存存储 + JSON 快照持久化（不依赖任何外部数据库）。
 *
 * 内存为主：tasks / runs 常驻内存，结构化查询全部走内存；
 * 快照落盘：每次变更后异步写入 data/tasks.json、data/runs.json，
 *          进程重启后可回看历史任务与历史报告。
 */

const fs = require('node:fs');
const path = require('node:path');

const { HttpError, newId, nowMs, validateTaskInput } = require('./util');

const TASKS_FILE = 'tasks.json';
const RUNS_FILE = 'runs.json';

/**
 * 内存与落盘保留的运行记录上限（P2-5）。
 * 历史报告无限保留会让 data/runs.json 随时间线性膨胀、每次落盘都要全量重写；
 * 这里保留最近 MAX_RUNS 次（运行中的运行永不淘汰）。
 */
const MAX_RUNS = 300;

class Store {
  constructor(dataDir) {
    this.dataDir = dataDir;
    this.tasks = new Map();
    this.runs = new Map();
    this.metrics = new Map();   // runId -> MetricsAggregator（仅运行中的实时聚合器）
    this.engines = new Map();   // runId -> RunEngine
    this._writeTimer = null;
    this._writing = false;
  }

  // ---------------------------------------------------------------- 持久化

  ensureDataDir() {
    fs.mkdirSync(this.dataDir, { recursive: true });
  }

  load() {
    this.ensureDataDir();
    const tasks = this._readJson(TASKS_FILE);
    const runs = this._readJson(RUNS_FILE);
    if (Array.isArray(tasks)) {
      for (const task of tasks) {
        if (task && task.id) this.tasks.set(task.id, task);
      }
    }
    if (Array.isArray(runs)) {
      for (const run of runs) {
        if (run && run.id) {
          // 上次进程退出时仍处于 running 的运行，标记为 failed（进程已终止）
          if (run.status === 'running') {
            run.status = 'failed';
            run.error = '服务重启，运行被中断';
          }
          this.runs.set(run.id, run);
        }
      }
    }
    this.pruneRuns(); // 快照中超出上限的旧记录不再载入
    return { tasks: this.tasks.size, runs: this.runs.size };
  }

  _readJson(fileName) {
    const file = path.join(this.dataDir, fileName);
    try {
      if (!fs.existsSync(file)) return null;
      const raw = fs.readFileSync(file, 'utf8');
      if (!raw.trim()) return null;
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  /** 合并写入（防抖 200ms），避免高频变更时反复落盘 */
  schedulePersist() {
    if (this._writeTimer) return;
    this._writeTimer = setTimeout(() => {
      this._writeTimer = null;
      this.persist();
    }, 200);
    if (this._writeTimer.unref) this._writeTimer.unref();
  }

  persist() {
    if (this._writing) return;
    this._writing = true;
    try {
      this.ensureDataDir();
      const tasks = [...this.tasks.values()];
      const runs = [...this.runs.values()]
        .sort((a, b) => b.startedAt - a.startedAt)
        .slice(0, MAX_RUNS)
        .map((run) => this.serializeRun(run));
      this._writeFileSync(TASKS_FILE, tasks);
      this._writeFileSync(RUNS_FILE, runs);
    } catch {
      // 持久化失败不影响服务可用性（内存为主）
    } finally {
      this._writing = false;
    }
  }

  _writeFileSync(fileName, data) {
    const file = path.join(this.dataDir, fileName);
    const tmp = `${file}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
    fs.renameSync(tmp, file);
  }

  /** 持久化形态：剔除运行时对象（聚合器等） */
  serializeRun(run) {
    const { metrics, ...rest } = run; // eslint-disable-line no-unused-vars
    return rest;
  }

  // ---------------------------------------------------------------- 任务

  createTask(input) {
    const validated = validateTaskInput(input); // 校验失败抛出 HttpError(INVALID_PARAM)
    const task = {
      id: newId('task'),
      name: validated.name || '',
      url: validated.url,
      method: validated.method,
      concurrency: validated.concurrency,
      durationSec: validated.durationSec,
      timeoutMs: validated.timeoutMs,
      headers: validated.headers || [],
      body: validated.body || '',
      createdAt: nowMs(),
    };
    this.tasks.set(task.id, task);
    this.schedulePersist();
    return task;
  }

  listTasks() {
    return [...this.tasks.values()].sort((a, b) => b.createdAt - a.createdAt);
  }

  getTask(id) {
    return this.tasks.get(id) || null;
  }

  /** 删除任务并级联删除其历史运行记录 */
  deleteTask(id) {
    const task = this.tasks.get(id);
    if (!task) throw new HttpError('NOT_FOUND', '任务不存在', 404);
    this.tasks.delete(id);
    let removedRuns = 0;
    for (const [runId, run] of [...this.runs.entries()]) {
      if (run.taskId === id) {
        const engine = this.engines.get(runId);
        if (engine) engine.stop('任务被删除');
        this.runs.delete(runId);
        this.metrics.delete(runId);
        this.engines.delete(runId);
        removedRuns += 1;
      }
    }
    this.schedulePersist();
    return { deleted: true, removedRuns };
  }

  // ---------------------------------------------------------------- 运行

  createRun(task) {
    const run = {
      id: newId('run'),
      taskId: task.id,
      task: {
        name: task.name,
        url: task.url,
        method: task.method,
        concurrency: task.concurrency,
        durationSec: task.durationSec,
        timeoutMs: task.timeoutMs,
      },
      status: 'running',
      startedAt: nowMs(),
      endedAt: null,
      durationSec: 0,
      report: null,
      error: null,
      stopReason: null,
    };
    this.runs.set(run.id, run);
    this.schedulePersist();
    return run;
  }

  getRun(id) {
    return this.runs.get(id) || null;
  }

  listRuns() {
    return [...this.runs.values()].sort((a, b) => b.startedAt - a.startedAt);
  }

  attachMetrics(runId, aggregator) {
    this.metrics.set(runId, aggregator);
  }

  getMetrics(runId) {
    return this.metrics.get(runId) || null;
  }

  attachEngine(runId, engine) {
    this.engines.set(runId, engine);
  }

  getEngine(runId) {
    return this.engines.get(runId) || null;
  }

  /** 结束运行：写入报告并落盘 */
  finishRun(runId, report) {
    const run = this.runs.get(runId);
    if (!run) return null;
    run.report = report;
    this.metrics.delete(runId);
    this.engines.delete(runId);
    this.pruneRuns();
    this.schedulePersist();
    return run;
  }

  /** 淘汰过老的已结束运行记录（运行中的永不淘汰）；返回淘汰条数 */
  pruneRuns() {
    if (this.runs.size <= MAX_RUNS) return 0;
    const candidates = [...this.runs.values()]
      .filter((run) => run.status !== 'running')
      .sort((a, b) => a.startedAt - b.startedAt);
    let removed = 0;
    for (const run of candidates) {
      if (this.runs.size <= MAX_RUNS) break;
      this.runs.delete(run.id);
      this.metrics.delete(run.id);
      this.engines.delete(run.id);
      removed += 1;
    }
    return removed;
  }

  /** 运行中实时快照：优先使用实时聚合器 */
  liveReport(runId) {
    const run = this.runs.get(runId);
    if (!run) return null;
    const aggregator = this.metrics.get(runId);
    if (aggregator) return aggregator.snapshot();
    return run.report;
  }

  stats() {
    let running = 0;
    for (const run of this.runs.values()) if (run.status === 'running') running += 1;
    return { tasks: this.tasks.size, runs: this.runs.size, running };
  }
}

module.exports = { Store };
