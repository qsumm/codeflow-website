'use strict';
/**
 * index.js —— HTTP 服务入口：REST API + 静态页面 + 内置压测样例页，同一进程监听 8801。
 *
 * 零第三方依赖：仅 Node 标准库。
 */

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const { HttpError } = require('./util');
const { Store } = require('./store');
const { MetricsAggregator } = require('./metrics');
const { RunEngine } = require('./engine');
const { createApi, sendJson, sendError } = require('./api');

const VERSION = '1.0.0';
const DEFAULT_PORT = 8801;
const ROOT_DIR = path.resolve(__dirname, '..');
const WEB_DIR = path.join(ROOT_DIR, 'web');
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT_DIR, 'data');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

/** 内置压测样例目标：内容极小，降低自压测时的服务端干扰 */
const SAMPLE_HTML = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>压测样例目标 / Sample Target</title>
</head>
<body>
<h1>压测样例目标</h1>
<p>perf-platform sample target</p>
</body>
</html>
`;

function sendHtml(res, status, html) {
  res.writeHead(status, {
    'Content-Type': 'text/html; charset=utf-8',
    'Content-Length': Buffer.byteLength(html),
    'Cache-Control': 'no-store',
  });
  res.end(html);
}

function serveStatic(res, filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const type = MIME[ext] || 'application/octet-stream';
  fs.readFile(filePath, (err, data) => {
    if (err) {
      sendJson(res, 404, { error: { code: 'NOT_FOUND', message: '资源不存在' } });
      return;
    }
    res.writeHead(200, {
      'Content-Type': type,
      'Content-Length': data.length,
      'Cache-Control': 'no-cache',
    });
    res.end(data);
  });
}

function createServer(options = {}) {
  const store = new Store(DATA_DIR);
  store.load();

  /** 发起一次压测运行：创建 run → 装配聚合器与引擎 → 启动 worker */
  function startRun(task) {
    const run = store.createRun(task);
    const metrics = new MetricsAggregator(run.startedAt);
    store.attachMetrics(run.id, metrics);

    const engine = new RunEngine({
      task,
      run,
      metrics,
      onFinish: (finishedRun) => {
        const report = metrics.snapshot();
        store.finishRun(finishedRun.id, report);
      },
    });
    store.attachEngine(run.id, engine);

    engine.start().catch((err) => {
      run.status = 'failed';
      run.error = err && err.message ? err.message : '引擎异常';
      run.endedAt = Date.now();
      store.finishRun(run.id, metrics.snapshot());
    });

    return run;
  }

  const api = createApi({ store, startRun, version: VERSION, token: options.token });

  const server = http.createServer(async (req, res) => {
    let url;
    try {
      url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    } catch {
      sendJson(res, 400, { error: { code: 'INVALID_PARAM', message: '非法请求 URL' } });
      return;
    }

    const pathname = decodeURIComponent(url.pathname);

    try {
      // ---------------------------------------------------------- API
      if (pathname.startsWith('/api/')) {
        const handled = await api.handle(req, res, url);
        if (!handled) {
          throw new HttpError('NOT_FOUND', `接口不存在：${req.method} ${pathname}`, 404);
        }
        return;
      }

      // ------------------------------------------------------ 样例目标页
      if (pathname === '/sample') {
        sendHtml(res, 200, SAMPLE_HTML);
        return;
      }

      if (pathname === '/favicon.ico') {
        res.writeHead(204);
        res.end();
        return;
      }

      // ---------------------------------------------------------- 静态页
      const relative = pathname === '/' ? 'index.html' : pathname.replace(/^\/+/, '');
      const target = path.resolve(WEB_DIR, relative);
      if (!target.startsWith(WEB_DIR + path.sep) && target !== WEB_DIR) {
        throw new HttpError('FORBIDDEN', '非法路径', 403);
      }
      if (!fs.existsSync(target) || !fs.statSync(target).isFile()) {
        sendHtml(res, 404, `<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8"><title>404</title></head><body><h1>404 页面不存在</h1><p><a href="/">返回首页</a></p></body></html>`);
        return;
      }
      serveStatic(res, target);
    } catch (err) {
      if (res.headersSent) {
        res.end();
        return;
      }
      sendError(res, err);
    }
  });

  server.keepAliveTimeout = 5000;
  server.headersTimeout = 10000;

  const shutdown = (signal) => {
    process.stdout.write(`[perf-platform] 收到 ${signal}，正在关闭...\n`);
    store.persist();
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 3000).unref();
  };
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

  return { server, store };
}

function main() {
  const port = Number(process.env.PORT || DEFAULT_PORT);
  const host = process.env.HOST || '0.0.0.0';
  // 可选访问令牌（P2-2）：设置后除 /api/health 外所有接口都需携带令牌
  const token = (process.env.PERF_TOKEN || '').trim();
  const { server } = createServer({ token });
  server.on('error', (err) => {
    if (err && err.code === 'EADDRINUSE') {
      process.stderr.write(`[perf-platform] 端口 ${port} 已被占用，服务启动失败（不擅自终止他人进程）。\n`);
    } else {
      process.stderr.write(`[perf-platform] 启动失败：${err && err.message ? err.message : err}\n`);
    }
    process.exit(1);
  });
  server.listen(port, host, () => {
    process.stdout.write(`[perf-platform] 服务已启动： http://localhost:${port}\n`);
    process.stdout.write(`[perf-platform] 压测样例目标： http://localhost:${port}/sample\n`);
    process.stdout.write(`[perf-platform] 监听地址： ${host}:${port}（默认 0.0.0.0 可被同网段访问；建议 HOST=127.0.0.1 或配置 PERF_TOKEN 收敛访问范围）\n`);
    if (token) process.stdout.write('[perf-platform] 已启用访问令牌（PERF_TOKEN），除 /api/health 外均需携带令牌\n');
  });
}

if (require.main === module) {
  main();
}

module.exports = { createServer, main, VERSION, DEFAULT_PORT };
