#!/usr/bin/env bash
#
# test.sh —— 运行单元 / 集成测试（Node 内置 test runner，零第三方依赖）。
#
# 等价于：node --test tests/*.test.js
# 集成测试会在独立端口（默认 18901）与临时数据目录中拉起服务进程，不影响 8801 常驻实例。
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NODE_BIN="${NODE_BIN:-node}"

cd "$DIR"
exec "$NODE_BIN" --test "$DIR"/tests/*.test.js
