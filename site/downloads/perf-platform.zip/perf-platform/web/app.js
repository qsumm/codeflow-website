/**
 * app.js —— 仪表盘页面逻辑：REST 调用 + SSE 实时订阅 + 指标与图表渲染。
 * 原生 ES Module，无构建步骤、无第三方依赖。
 */

import { renderLineChart, renderBarChart, CHART_COLORS } from './charts.js';
import {
  formatNumber,
  escapeHtml,
  statusText,
  fullBuckets,
  shouldCloseStream,
  resolveStreamError,
  resolveStreamDone,
} from './lib/core.js';

const state = {
  tasks: [],
  runs: [],
  selectedTaskId: null,
  currentRunId: null,   // 当前展示的运行（可能是历史报告）
  liveRunId: null,      // 正在实时订阅的运行
  liveReport: null,     // 最近一帧实时报告
  liveRunStatus: null,  // 被订阅运行自身的状态（与 currentRunStatus 区分，见 subscribe）
  currentRunStatus: null,
  report: null,
  source: null,
};

// ------------------------------------------------------------------ 工具

const $ = (id) => document.getElementById(id);

/**
 * 可选访问令牌（P2-2）：服务端配置 PERF_TOKEN 后，页面用 `?token=xxx` 打开，
 * 前端会把令牌带到所有 API 请求与 SSE 订阅上（EventSource 不能自定义请求头，
 * 因此同时支持查询参数）。
 */
const ACCESS_TOKEN = new URLSearchParams(window.location.search).get('token') || '';

function authHeaders(extra = {}) {
  const headers = { ...extra };
  if (ACCESS_TOKEN) headers['X-Perf-Token'] = ACCESS_TOKEN;
  return headers;
}

function withToken(path) {
  if (!ACCESS_TOKEN) return path;
  return path + (path.includes('?') ? '&' : '?') + `token=${encodeURIComponent(ACCESS_TOKEN)}`;
}

function fmtTime(ts) {
  if (!ts) return '-';
  const d = new Date(ts);
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

async function api(path, options = {}) {
  const res = await fetch(path, {
    ...options,
    headers: authHeaders({ 'Content-Type': 'application/json', ...(options.headers || {}) }),
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  let payload = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }
  if (!res.ok) {
    const err = new Error((payload && payload.error && payload.error.message) || `请求失败（HTTP ${res.status}）`);
    err.fields = payload && payload.error ? payload.error.fields : null;
    err.code = payload && payload.error ? payload.error.code : null;
    throw err;
  }
  return payload;
}

// ------------------------------------------------------------- 顶部状态

async function refreshHealth() {
  const badge = $('service-status');
  try {
    const data = await api('/api/health');
    badge.textContent = `服务状态：正常（v${data.version}）`;
    badge.className = 'badge badge-ok';
  } catch (err) {
    badge.textContent = '服务状态：不可用';
    badge.className = 'badge badge-bad';
  }
}

// ---------------------------------------------------------------- 任务

function headerRowTemplate(name = '', value = '') {
  const row = document.createElement('div');
  row.className = 'header-row';
  // 用 createElement + .value 赋值，避免任何 HTML 字符串拼接（B8）
  const nameInput = document.createElement('input');
  nameInput.type = 'text';
  nameInput.className = 'h-name';
  nameInput.placeholder = 'Header 名';
  nameInput.value = name;

  const valueInput = document.createElement('input');
  valueInput.type = 'text';
  valueInput.className = 'h-value';
  valueInput.placeholder = '值';
  valueInput.value = value;

  const del = document.createElement('button');
  del.type = 'button';
  del.className = 'btn btn-ghost btn-sm h-del';
  del.textContent = '删除';
  del.addEventListener('click', () => row.remove());

  row.appendChild(nameInput);
  row.appendChild(valueInput);
  row.appendChild(del);
  return row;
}

function addHeaderRow(name = '', value = '') {
  const rows = $('header-rows');
  rows.appendChild(headerRowTemplate(name, value));
}

async function loadTasks() {
  const data = await api('/api/tasks');
  state.tasks = data.tasks || [];
  renderTasks();
}

function renderTasks() {
  const tbody = $('task-body');
  $('task-count').textContent = `${state.tasks.length} 个任务`;
  tbody.innerHTML = '';

  if (!state.tasks.length) {
    tbody.innerHTML = '<tr class="empty-row"><td colspan="4">暂无任务，请先在左侧创建</td></tr>';
    return;
  }

  for (const task of state.tasks) {
    const tr = document.createElement('tr');
    if (task.id === state.selectedTaskId) tr.className = 'selected';
    tr.innerHTML = `
      <td>
        <div class="strong">${escapeHtml(task.name || '（未命名）')}<span class="tag ${task.status === 'running' ? 'tag-run' : 'tag-idle'}">${statusText(task.status)}</span></div>
        <div class="muted url" title="${escapeHtml(task.url)}">${escapeHtml(task.url)}</div>
      </td>
      <td class="mono muted">${escapeHtml(task.id)}<div class="muted">创建于 ${fmtTime(task.createdAt)}</div></td>
      <td class="muted nowrap">${escapeHtml(task.method)} · ${task.concurrency} 并发 · ${task.durationSec}s</td>
      <td class="actions-cell">
        <button class="btn btn-ghost btn-sm" data-action="run" data-id="${escapeHtml(task.id)}">压测</button>
        <button class="btn btn-danger btn-sm" data-action="del" data-id="${escapeHtml(task.id)}">删除</button>
      </td>
    `;
    tbody.appendChild(tr);
  }

  tbody.querySelectorAll('button[data-action="run"]').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.selectedTaskId = btn.dataset.id;
      $('btn-start').disabled = false;
      renderTasks();
    });
  });
  tbody.querySelectorAll('button[data-action="del"]').forEach((btn) => {
    btn.addEventListener('click', () => deleteTask(btn.dataset.id));
  });
}

async function createTask(event) {
  event.preventDefault();
  const errorBox = $('form-error');
  errorBox.hidden = true;

  const headers = [...document.querySelectorAll('#header-rows .header-row')]
    .map((row) => ({
      name: row.querySelector('.h-name').value.trim(),
      value: row.querySelector('.h-value').value,
    }))
    .filter((h) => h.name);

  const method = $('f-method').value;
  const payload = {
    name: $('f-name').value.trim(),
    url: $('f-url').value.trim(),
    method,
    concurrency: Number($('f-concurrency').value),
    durationSec: Number($('f-duration').value),
    timeoutMs: Number($('f-timeout').value),
    headers,
    // 请求体仅在非 GET / HEAD 时生效（G5）
    body: method === 'GET' || method === 'HEAD' ? '' : $('f-body').value,
  };

  try {
    const data = await api('/api/tasks', { method: 'POST', body: payload });
    state.selectedTaskId = data.task.id;
    $('btn-start').disabled = false;
    await loadTasks();
    $('f-name').value = '';
  } catch (err) {
    let message = err.message;
    if (err.fields) {
      const details = Object.entries(err.fields).map(([k, v]) => `${k}：${v}`).join('；');
      message = `${message}（${details}）`;
    }
    errorBox.textContent = message;
    errorBox.hidden = false;
  }
}

async function deleteTask(taskId) {
  const task = state.tasks.find((t) => t.id === taskId);
  const label = task ? task.name || task.url : taskId;
  // P2-5：明确提示删除会一并清除历史报告，并中断正在进行的压测
  if (!window.confirm(`确认删除任务「${label}」？\n其历史压测报告将一并删除，正在运行的压测会被中断。`)) return;
  try {
    const data = await api(`/api/tasks/${encodeURIComponent(taskId)}`, { method: 'DELETE' });
    if (state.selectedTaskId === taskId) {
      state.selectedTaskId = null;
      $('btn-start').disabled = true;
    }
    await loadTasks();
    await loadRuns();
    window.alert(`任务已删除（同时删除 ${data.removedRuns} 条历史报告）`);
  } catch (err) {
    window.alert(`删除失败：${err.message}`);
  }
}

// ---------------------------------------------------------------- 运行

async function loadRuns() {
  const data = await api('/api/runs');
  state.runs = data.runs || [];
  renderRuns();
}

function renderRuns() {
  const tbody = $('run-body');
  tbody.innerHTML = '';
  if (!state.runs.length) {
    tbody.innerHTML = '<tr class="empty-row"><td colspan="11">暂无运行记录</td></tr>';
    return;
  }
  for (const run of state.runs) {
    const tr = document.createElement('tr');
    if (run.id === state.currentRunId) tr.className = 'selected';
    tr.innerHTML = `
      <td class="mono">${escapeHtml(run.id)}</td>
      <td>${escapeHtml(run.url || '')}</td>
      <td>${run.concurrency || '-'} 并发 / ${run.durationSec || '-'}s / ${escapeHtml(run.method || '')}</td>
      <td><span class="tag ${run.status === 'running' ? 'tag-run' : (run.status === 'completed' ? 'tag-ok' : 'tag-warn')}">${statusText(run.status)}</span></td>
      <td>${formatNumber(run.total, 0)}</td>
      <td>${formatNumber(run.qps)}</td>
      <td>${formatNumber(run.p95)}</td>
      <td>${formatNumber(run.p99)}</td>
      <td>${formatNumber(run.errorRate)}%</td>
      <td>${fmtTime(run.startedAt)}</td>
      <td class="actions-cell">
        <button class="btn btn-ghost btn-sm" data-action="view" data-id="${run.id}">查看报告</button>
      </td>
    `;
    tbody.appendChild(tr);
  }
  tbody.querySelectorAll('button[data-action="view"]').forEach((btn) => {
    btn.addEventListener('click', () => viewRun(btn.dataset.id));
  });
}

async function startRun() {
  const taskId = state.selectedTaskId;
  if (!taskId) {
    window.alert('请先选择一个任务');
    return;
  }
  $('btn-start').disabled = true;
  try {
    const data = await api('/api/runs', { method: 'POST', body: { taskId } });
    state.currentRunId = data.run.id;
    state.liveRunId = data.run.id;
    state.liveReport = null;
    state.currentRunStatus = 'running';
    $('run-id').textContent = data.run.id;
    $('run-target').textContent = data.run.url;
    $('run-params').textContent = `${data.run.concurrency} 并发 / ${data.run.durationSec}s / ${data.run.method}`;
    setRunStatus('running');
    $('btn-stop').disabled = false;
    updateLiveButton();
    subscribe(data.run.id);
    await loadRuns();
  } catch (err) {
    $('btn-start').disabled = false;
    window.alert(`发起压测失败：${err.message}`);
  }
}

async function stopRun() {
  // 停止的是「正在运行的那次压测」；查看历史报告时不应误停历史记录
  const targetId = state.liveRunId || state.currentRunId;
  if (!targetId) return;
  try {
    await api(`/api/runs/${encodeURIComponent(targetId)}/stop`, { method: 'POST' });
    $('btn-stop').disabled = true;
  } catch (err) {
    window.alert(`停止失败：${err.message}`);
  }
}

async function viewRun(runId) {
  try {
    const data = await api(`/api/runs/${encodeURIComponent(runId)}`);
    state.currentRunId = runId;
    state.currentRunStatus = data.run.status;
    $('run-id').textContent = data.run.id;
    $('run-target').textContent = data.run.url;
    $('run-params').textContent = `${data.run.concurrency} 并发 / ${data.run.durationSec}s / ${data.run.method}`;
    setRunStatus(data.run.status);
    $('btn-stop').disabled = !(state.liveRunId && state.liveRunId === data.run.id);
    $('btn-start').disabled = !state.selectedTaskId;
    updateLiveButton();
    renderReport(data.run.report || {});
    renderRuns();
  } catch (err) {
    window.alert(`读取报告失败：${err.message}`);
  }
}

/** 有实时运行且当前查看的不是它时，显示「回到实时」按钮 */
function updateLiveButton() {
  const btn = $('btn-live');
  btn.hidden = !(state.liveRunId && state.liveRunId !== state.currentRunId);
}

/** 切回实时视图：展示最近一帧实时报告并继续跟随推送 */
function backToLive() {
  if (!state.liveRunId) return;
  state.currentRunId = state.liveRunId;
  updateLiveButton();
  // 尚未收到任何实时帧时清空历史报告视图，避免图表仍显示历史数据（B6）
  renderReport(state.liveReport || {});
  renderRuns();
}

function setRunStatus(status) {
  const badge = $('run-status');
  badge.textContent = statusText(status);
  // P2-3：为「已停止」提供独立样式，避免与「空闲」混淆
  const badgeClass = {
    running: 'badge-run',
    completed: 'badge-ok',
    failed: 'badge-bad',
    stopped: 'badge-stopped',
  }[status] || 'badge-idle';
  badge.className = `badge ${badgeClass}`;
}

function closeStream() {
  if (state.source) {
    state.source.close();
    state.source = null;
  }
}

/** 实时连接状态提示（重连中 / 已断开） */
function setStreamHint(text) {
  const hint = $('stream-hint');
  if (!hint) return;
  hint.textContent = text || '';
  hint.hidden = !text;
}

/**
 * 订阅某次运行的 SSE 实时推送。
 *
 * 关键点（B1/B2/B3）：
 *  - 用 `state.liveRunStatus` 记录「被订阅运行自身」的状态，不再复用
 *    `state.currentRunStatus`（那是"当前查看"的运行，查看历史报告会把它改掉，
 *    导致实时流被误判为"已结束"而关闭，实时刷新静默失效）。
 *  - 每个事件处理器只操作自己那条 source：旧运行的 done 帧不会拆掉新运行的订阅（B3）。
 *  - onerror 先向服务端确认该运行是否仍然存在：运行已结束就收尾并补拉最终报告；
 *    运行不存在（404）则明确告知用户，而不是让浏览器无限重连且界面一直显示"运行中"（B2）。
 */
function subscribe(runId) {
  closeStream();
  const source = new EventSource(withToken(`/api/runs/${encodeURIComponent(runId)}/stream`));
  state.source = source;
  state.liveRunId = runId;
  state.liveRunStatus = 'running';
  setStreamHint('');

  /** 该 source 是否仍是当前生效的订阅 */
  const isCurrent = () => state.source === source;

  source.addEventListener('stats', (event) => {
    let payload;
    try {
      payload = JSON.parse(event.data);
    } catch {
      return; // 忽略畸形帧，不打断整条流（B5）
    }
    state.liveReport = payload.report || null;
    // 正在查看历史报告时不覆盖视图（P2-3）
    if (state.currentRunId === payload.runId) renderReport(payload.report || {});
  });

  source.addEventListener('done', (event) => {
    let payload;
    try {
      payload = JSON.parse(event.data);
    } catch {
      return;
    }
    if (payload.report) state.liveReport = payload.report;
    state.liveRunStatus = payload.status || 'completed';
    if (state.currentRunId === payload.runId) {
      state.currentRunStatus = payload.status;
      setRunStatus(payload.status);
      $('btn-stop').disabled = true;
      $('btn-start').disabled = !state.selectedTaskId;
      if (payload.report) renderReport(payload.report);
    }
    // 只拆自己这条流，避免误关掉后来发起的订阅（B3）
    const done = resolveStreamDone({ isCurrent: isCurrent() });
    if (done.teardown) {
      closeStream();
      state.liveRunId = null;
    }
    setStreamHint('');
    updateLiveButton();
    loadRuns();
    loadTasks();
  });

  source.onerror = async () => {
    // 运行已结束：服务端主动关闭连接后浏览器会重连，此时主动关闭即可。
    // 判定只看被订阅运行自身的状态（B1）。
    if (shouldCloseStream({
      isCurrent: isCurrent(),
      readyState: source.readyState,
      liveRunStatus: state.liveRunStatus,
    })) {
      closeStream();
      return;
    }
    if (!isCurrent()) return;                       // 已被新的订阅取代，忽略
    if (source.readyState === EventSource.CLOSED) return;

    // 连接异常：先确认该运行是否仍然存在，再决定"重连"还是"收尾"（B2）
    let outcome;
    let report = null;
    try {
      const data = await api(`/api/runs/${encodeURIComponent(runId)}`);
      const status = (data.run && data.run.status) || 'running';
      outcome = resolveStreamError({ runStatus: status, fetchFailed: false });
      report = (data.run && data.run.report) || null;
    } catch {
      // 运行记录不存在（服务重启或运行已被清理）：明确告知，不再无限重连
      outcome = resolveStreamError({ runStatus: null, fetchFailed: true });
    }

    state.liveRunStatus = outcome.status;
    if (outcome.action === 'finalize') {
      // 运行已结束但未收到 done 帧（连接在最后一帧前断开）：补拉最终报告后收尾
      closeStream();
      state.liveRunId = null;
      if (state.currentRunId === runId) {
        state.currentRunStatus = outcome.status;
        setRunStatus(outcome.status);
        if (report) renderReport(report);
      }
      setStreamHint('');
      updateLiveButton();
      loadRuns();
      return;
    }
    if (outcome.action === 'abort') {
      closeStream();
      state.liveRunId = null;
      state.liveRunStatus = null;
      setStreamHint(outcome.hint);
      if (state.currentRunId === runId) setRunStatus('failed');
      updateLiveButton();
      loadRuns();
      return;
    }
    // reconnect：运行仍在进行，交由 EventSource 自身的重连机制，仅提示用户
    setStreamHint(outcome.hint);
  };
}

// ---------------------------------------------------------------- 报告

function renderReport(report) {
  state.report = report || {};
  const latency = report.latency || {};
  // P2-1：样本超过上限时分位数为抽样估计，界面用「≈」标注，避免被误读为精确值
  const approx = !!(report.percentilesApproximate || latency.approximate);
  const mark = (value) => (approx && value !== null && value !== undefined ? `≈${formatNumber(value)}` : formatNumber(value));

  $('m-total').textContent = formatNumber(report.total, 0);
  $('m-total-sub').textContent = `压测时长 ${formatNumber(report.durationSec)}s`;
  $('m-success').textContent = formatNumber(report.success, 0);
  $('m-success-sub').textContent = `成功 QPS ${formatNumber(report.successQps)}`;
  $('m-failed').textContent = formatNumber(report.failed, 0);
  $('m-failed-sub').textContent = `HTTP ${formatNumber(report.httpErrors, 0)} / 网络 ${formatNumber(report.networkErrors, 0)}`;
  $('m-qps').textContent = formatNumber(report.qps);
  $('m-qps-sub').textContent = `成功 QPS：${formatNumber(report.successQps)}（TPS 同义）`;
  $('m-avg').textContent = formatNumber(latency.avg);
  $('m-p95').textContent = mark(latency.p95);
  $('m-p95-sub').textContent = approx
    ? `抽样估计（样本 ${formatNumber(report.percentileSampleSize, 0)}）· 成功请求 P95 ${formatNumber(latency.successP95)}`
    : `成功请求 P95 ${formatNumber(latency.successP95)}`;
  $('m-p99').textContent = mark(latency.p99);
  $('m-error-rate').textContent = `${formatNumber(report.errorRate)}%`;
  $('m-error-sub').textContent = `失败 ${formatNumber(report.failed, 0)} / 总 ${formatNumber(report.total, 0)}`;

  renderMetricTable(report, latency, mark);
  renderErrorSamples(report);
  renderCharts(report);
}

/** 错误明细摘要：错误类型 / 状态码 / 错误信息 / 次数 / 最近发生时间 */
function renderErrorSamples(report) {
  const tbody = $('error-body');
  const samples = report.errorSamples || [];
  const types = report.errorTypes || {};

  const typeText = Object.entries(types)
    .map(([type, count]) => `${type === 'http_error' ? 'HTTP 错误' : type === 'network_error' ? '网络错误' : type} ${count} 次`)
    .join('，');
  $('error-summary').textContent = report.failed > 0
    ? `失败 ${formatNumber(report.failed, 0)} 次（${typeText || '未知类型'}）`
    : '无错误';

  tbody.innerHTML = '';
  if (!samples.length) {
    tbody.innerHTML = `<tr class="empty-row"><td colspan="5">${report.failed > 0 ? '无错误明细（失败请求未记录原因）' : '暂无错误明细'}</td></tr>`;
    return;
  }
  for (const s of samples) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td><span class="tag tag-warn">${s.type === 'http_error' ? 'HTTP 错误' : (s.type === 'network_error' ? '网络错误' : escapeHtml(s.type))}</span></td>
      <td>${s.statusCode === null || s.statusCode === undefined ? '-' : s.statusCode}</td>
      <td class="mono err-msg" title="${escapeHtml(s.message)}">${escapeHtml(s.message)}</td>
      <td>${formatNumber(s.count, 0)}</td>
      <td>${fmtTime(s.lastAt)}</td>
    `;
    tbody.appendChild(tr);
  }
}

function renderMetricTable(report, latency, mark) {
  const m = typeof mark === 'function' ? mark : (v) => formatNumber(v);
  const rows = [
    ['总请求数', formatNumber(report.total, 0), '成功数 + 失败数'],
    ['成功数', formatNumber(report.success, 0), 'HTTP 2xx / 3xx（3xx 不跟随）'],
    ['失败数', formatNumber(report.failed, 0), 'HTTP ≥ 400 或连接失败 / 超时'],
    ['HTTP 错误数', formatNumber(report.httpErrors, 0), '状态码 ≥ 400'],
    ['网络错误数', formatNumber(report.networkErrors, 0), '连接失败或超时'],
    ['QPS（总）', formatNumber(report.qps), '总请求数 ÷ 实际压测时长'],
    ['TPS', formatNumber(report.tps), '与总 QPS 同义'],
    ['成功 QPS', formatNumber(report.successQps), '成功数 ÷ 实际压测时长'],
    ['错误率', `${formatNumber(report.errorRate)}%`, '失败数 ÷ 总请求数'],
    ['平均延迟', `${formatNumber(latency.avg)} ms`, '全部已完成请求'],
    ['最小 / 最大延迟', `${formatNumber(latency.min)} / ${formatNumber(latency.max)} ms`, '全部已完成请求'],
    ['P50 / P90 延迟', `${m(latency.p50)} / ${m(latency.p90)} ms`, '最近秩法'],
    ['P95 延迟', `${m(latency.p95)} ms`, '最近秩法（含失败请求）'],
    ['P99 延迟', `${m(latency.p99)} ms`, '最近秩法（含失败请求）'],
    ['成功请求 P95', `${formatNumber(latency.successP95)} ms`, '仅 2xx / 3xx 请求'],
    ['压测时长', `${formatNumber(report.durationSec)} s`, '实际运行时长'],
  ];
  if (report.aborted) {
    rows.push(['中止请求数', formatNumber(report.aborted, 0), '停止压测时被主动中止，不计入总数与失败数']);
  }
  if (report.percentilesApproximate) {
    rows.push(['分位数口径', '抽样估计 ≈', `样本上限触发，实际参与计算的样本 ${formatNumber(report.percentileSampleSize, 0)} 个`]);
  }

  const tbody = $('metric-body');
  tbody.innerHTML = '';
  if (!report.total && !report.durationSec) {
    tbody.innerHTML = '<tr class="empty-row"><td colspan="3">暂无报告</td></tr>';
    return;
  }
  for (const [name, value, note] of rows) {
    const tr = document.createElement('tr');
    tr.innerHTML = `<td>${name}</td><td class="strong">${value}</td><td class="muted">${note}</td>`;
    tbody.appendChild(tr);
  }
}

/**
 * 取「完整秒」的桶用于绘制趋势图 —— 实现在 `web/lib/core.js`（与测试共用）。
 */
function renderCharts(report) {
  const series = fullBuckets(report);

  renderLineChart($('chart-qps'), {
    series: [{
      name: '每秒 QPS',
      color: CHART_COLORS.qps,
      fill: true,
      points: series.map((p) => ({ x: p.second, y: p.qps })),
    }],
    xLabel: '压测时间（秒）',
    yLabel: 'QPS',
    emptyText: '运行后显示 QPS 趋势',
  });

  renderLineChart($('chart-percentile'), {
    series: [
      { name: 'P50', color: CHART_COLORS.p50, points: series.map((p) => ({ x: p.second, y: p.p50 })) },
      { name: 'P95', color: CHART_COLORS.p95, points: series.map((p) => ({ x: p.second, y: p.p95 })) },
      { name: 'P99', color: CHART_COLORS.p99, points: series.map((p) => ({ x: p.second, y: p.p99 })) },
    ],
    xLabel: '压测时间（秒）',
    yLabel: '延迟（毫秒）',
    emptyText: '运行后显示延迟分位趋势',
  });

  renderBarChart($('chart-histogram'), {
    bars: (report.histogram || []).map((b) => ({
      label: b.label,
      value: b.count,
      color: CHART_COLORS.bar,
      tooltip: `延迟 ${b.label} ms：${formatNumber(b.count, 0)} 次`,
    })),
    legend: [{ label: '请求数', color: CHART_COLORS.bar }],
    xLabel: '延迟区间（毫秒）',
    yLabel: '请求数',
    emptyText: '运行后显示延迟分布',
  });

  // 状态码分布：成功 / 失败按段堆叠，颜色含义由图例说明（G2 / G7）
  renderBarChart($('chart-status'), {
    bars: (report.statusCodes || []).map((c) => ({
      label: c.code,
      value: c.count,
      stack: [
        { label: '成功', value: c.success || 0, color: CHART_COLORS.success },
        { label: '失败', value: c.failed || 0, color: CHART_COLORS.failed },
      ],
      tooltip: `状态码 ${c.code}：共 ${formatNumber(c.count, 0)} 次（成功 ${formatNumber(c.success, 0)} / 失败 ${formatNumber(c.failed, 0)}）`,
    })),
    legend: [
      { label: '成功', color: CHART_COLORS.success },
      { label: '失败', color: CHART_COLORS.failed },
    ],
    xLabel: 'HTTP 状态码',
    yLabel: '请求数',
    emptyText: '运行后显示状态码分布',
  });
}

// ---------------------------------------------------------------- 初始化

function bindEvents() {
  $('task-form').addEventListener('submit', createTask);
  $('add-header').addEventListener('click', () => addHeaderRow());
  $('btn-start').addEventListener('click', startRun);
  $('btn-stop').addEventListener('click', stopRun);
  $('btn-live').addEventListener('click', backToLive);
  $('refresh-runs').addEventListener('click', () => loadRuns());
  $('fill-sample').addEventListener('click', () => {
    $('f-name').value = '示例页 20 并发 10 秒';
    $('f-url').value = `${window.location.origin}/sample`;
    $('f-method').value = 'GET';
    $('f-concurrency').value = '20';
    $('f-duration').value = '10';
    $('f-timeout').value = '10000';
    syncBodyField();
  });

  // 请求体仅在非 GET / HEAD 时可填（G5）
  $('f-method').addEventListener('change', syncBodyField);
  syncBodyField();
}

/** GET / HEAD 时禁用请求体输入框，避免界面与实际生效规则不一致（G5） */
function syncBodyField() {
  const method = $('f-method').value;
  const body = $('f-body');
  const disabled = method === 'GET' || method === 'HEAD';
  body.disabled = disabled;
  body.placeholder = disabled ? 'GET / HEAD 请求不发送请求体' : '可选，文本内容';
  if (disabled) body.value = '';
}

async function init() {
  bindEvents();
  addHeaderRow();
  await refreshHealth();
  await loadTasks();
  await loadRuns();
  // 页面刷新后若服务端仍有正在进行的压测，自动接回实时订阅（G6）
  const running = state.runs.find((r) => r.status === 'running');
  if (running) {
    state.currentRunId = running.id;
    state.currentRunStatus = 'running';
    $('run-id').textContent = running.id;
    $('run-target').textContent = running.url || '';
    $('run-params').textContent = `${running.concurrency || '-'} 并发 / ${running.durationSec || '-'}s / ${running.method || ''}`;
    setRunStatus('running');
    $('btn-stop').disabled = false;
    subscribe(running.id);
    updateLiveButton();
  }
  setInterval(refreshHealth, 15000);
}

init();
