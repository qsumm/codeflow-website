/**
 * charts.js —— 纯前端 SVG 图表渲染（无任何第三方图表库、无构建步骤）。
 *
 * 提供的图表：
 *  1. renderLineChart  —— 折线（QPS-时间、P50/P95/P99 对比），含面积填充、坐标轴、刻度、图例、悬浮 tooltip
 *  2. renderBarChart   —— 柱状（延迟直方图、状态码分布），含坐标轴、刻度、图例、悬浮 tooltip
 *
 * 刻度口径：Y 轴不再把小数硬抹成整数（低 QPS 时会出现 0.75 → "1" 的错标与重复刻度），
 * 改用「步长取 1/2/2.5/5 × 10^k」的漂亮刻度，刻度线的位置与标签数值严格一致。
 * 具体刻度算法与空态判定等纯函数放在 `web/lib/core.js`，与测试共用同一份实现。
 */

import { formatNumber, niceScale, tickDigits, isValidY } from './lib/core.js';

const SVG_NS = 'http://www.w3.org/2000/svg';

export const CHART_COLORS = {
  qps: '#4f8cff',
  p50: '#3ecf8e',
  p95: '#ffb020',
  p99: '#ff5f6d',
  success: '#3ecf8e',
  failed: '#ff5f6d',
  bar: '#6f8cff',
};

function el(name, attrs = {}) {
  const node = document.createElementNS(SVG_NS, name);
  for (const [key, value] of Object.entries(attrs)) {
    if (value === undefined || value === null) continue;
    node.setAttribute(key, String(value));
  }
  return node;
}

function text(content, attrs = {}) {
  const node = el('text', attrs);
  node.textContent = content;
  return node;
}

/**
 * 计算「漂亮」的刻度轴 —— 实现在 `web/lib/core.js`（与测试共用）。
 */

function ensureTooltip(container) {
  let tip = container.querySelector(':scope > .chart-tooltip');
  if (!tip) {
    tip = document.createElement('div');
    tip.className = 'chart-tooltip';
    tip.style.display = 'none';
    container.appendChild(tip);
  }
  return tip;
}

function clearSvg(svg) {
  while (svg.firstChild) svg.removeChild(svg.firstChild);
}

/** 图例：色块 + 名称，横向排列在图表顶部 */
function renderLegend(svg, items, margin) {
  if (!Array.isArray(items) || !items.length) return;
  const legend = el('g');
  let legendX = margin.left;
  const legendY = 12;
  for (const item of items) {
    legend.appendChild(el('rect', {
      x: legendX, y: legendY - 8, width: 10, height: 10, rx: 2, fill: item.color,
    }));
    legend.appendChild(text(item.label, {
      x: legendX + 15, y: legendY + 1, fill: '#5b647a', 'font-size': 11,
    }));
    legendX += 15 + item.label.length * 12 + 18;
  }
  svg.appendChild(legend);
}

/**
 * 折线图
 * @param {SVGElement} svg
 * @param {object} options
 *  - series: [{ name, color, points: [{x, y}], fill?: boolean, dashed?: boolean }]
 *  - xLabel, yLabel: 轴标题
 *  - xFormat(x), yFormat(y): 刻度格式化
 *  - tooltipFormat(point): tooltip 文本
 */
export function renderLineChart(svg, options) {
  const {
    series = [],
    width = 760,
    height = 260,
    margin = { top: 26, right: 18, bottom: 38, left: 58 },
    xLabel = '',
    yLabel = '',
    emptyText = '暂无数据',
  } = options;

  clearSvg(svg);
  svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
  svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');

  const container = svg.parentElement;
  const tooltip = container ? ensureTooltip(container) : null;

  const innerW = width - margin.left - margin.right;
  const innerH = height - margin.top - margin.bottom;

  const allPoints = series.flatMap((s) => s.points || []);
  // 空态判定只看「有可绘制数值」的点：所有 Y 均为 null（如某秒无样本）时走空态而非画出空坐标系（B7）
  const validPoints = allPoints.filter((p) => isValidY(p.y));
  if (!validPoints.length) {
    svg.appendChild(text(emptyText, {
      x: width / 2, y: height / 2, fill: '#8a93a6', 'font-size': 13, 'text-anchor': 'middle',
    }));
    return;
  }

  const xs = allPoints.map((p) => Number(p.x)).filter((x) => Number.isFinite(x));
  const xList = xs.length ? xs : [0, 1];
  const ys = validPoints.map((p) => Number(p.y));
  const xMin = Math.min(...xList);
  const xMax = Math.max(...xList, xMin + 1);
  const yScale = niceScale(Math.max(...ys, 0));
  const yMax = yScale.max;

  const sx = (x) => margin.left + ((x - xMin) / (xMax - xMin || 1)) * innerW;
  const sy = (y) => margin.top + innerH - ((Number.isFinite(Number(y)) ? Number(y) : 0) / yMax) * innerH;

  // 网格与坐标轴（G3：刻度线位置与标签数值一一对应）
  const grid = el('g');
  yScale.ticks.forEach((tickValue, i) => {
    const y = margin.top + (innerH / yScale.intervals) * i;
    grid.appendChild(el('line', {
      x1: margin.left, x2: margin.left + innerW, y1: y, y2: y,
      stroke: '#e6eaf2', 'stroke-width': 1,
    }));
    grid.appendChild(text(formatNumber(tickValue, tickDigits(yScale.step)), {
      x: margin.left - 8, y: y + 4, fill: '#8a93a6', 'font-size': 11, 'text-anchor': 'end',
    }));
  });
  // X 轴取整步长（G4）：刻度线落在整数秒上，标签不再出现 1.5 → "2" 这类错位
  const xSpan = xMax - xMin;
  const xStep = Math.max(1, Math.ceil(xSpan / 10));
  const xTickCount = Math.max(1, Math.floor(xSpan / xStep));
  for (let i = 0; i <= xTickCount; i += 1) {
    const value = xMin + xStep * i;
    const x = sx(value);
    grid.appendChild(el('line', {
      x1: x, x2: x, y1: margin.top, y2: margin.top + innerH, stroke: '#f1f4f9', 'stroke-width': 1,
    }));
    grid.appendChild(text(formatNumber(value, 0), {
      x, y: margin.top + innerH + 18, fill: '#8a93a6', 'font-size': 11, 'text-anchor': 'middle',
    }));
  }
  grid.appendChild(el('line', {
    x1: margin.left, x2: margin.left + innerW, y1: margin.top + innerH, y2: margin.top + innerH,
    stroke: '#c9d2e3', 'stroke-width': 1,
  }));
  svg.appendChild(grid);

  if (xLabel) {
    svg.appendChild(text(xLabel, {
      x: margin.left + innerW / 2, y: height - 4, fill: '#8a93a6', 'font-size': 11, 'text-anchor': 'middle',
    }));
  }
  if (yLabel) {
    svg.appendChild(text(yLabel, {
      x: 12, y: margin.top + innerH / 2, fill: '#8a93a6', 'font-size': 11, 'text-anchor': 'middle',
      transform: `rotate(-90 12 ${margin.top + innerH / 2})`,
    }));
  }

  // 图例
  renderLegend(svg, series.map((s) => ({ label: s.name, color: s.color })), margin);

  // 数据系列
  for (const s of series) {
    const points = (s.points || []).filter((p) => isValidY(p.y));
    if (!points.length) continue;

    if (s.fill) {
      const areaPath = points
        .map((p, i) => `${i === 0 ? 'M' : 'L'}${sx(p.x).toFixed(2)},${sy(p.y).toFixed(2)}`)
        .join(' ');
      svg.appendChild(el('path', {
        d: `${areaPath} L${sx(points[points.length - 1].x).toFixed(2)},${sy(0).toFixed(2)} L${sx(points[0].x).toFixed(2)},${sy(0).toFixed(2)} Z`,
        fill: s.color, 'fill-opacity': 0.12, stroke: 'none',
      }));
    }

    const linePath = points
      .map((p, i) => `${i === 0 ? 'M' : 'L'}${sx(p.x).toFixed(2)},${sy(p.y).toFixed(2)}`)
      .join(' ');
    svg.appendChild(el('path', {
      d: linePath, fill: 'none', stroke: s.color, 'stroke-width': 2,
      'stroke-linejoin': 'round', 'stroke-linecap': 'round',
      ...(s.dashed ? { 'stroke-dasharray': '6 4' } : {}),
    }));

    for (const p of points) {
      svg.appendChild(el('circle', { cx: sx(p.x), cy: sy(p.y), r: 2.4, fill: s.color }));
    }
  }

  // 悬浮 tooltip
  if (container && tooltip) {
    const overlay = el('rect', {
      x: margin.left, y: margin.top, width: innerW, height: innerH, fill: 'transparent',
    });
    svg.appendChild(overlay);
    overlay.addEventListener('mousemove', (event) => {
      const rect = svg.getBoundingClientRect();
      const scale = width / rect.width;
      const px = (event.clientX - rect.left) * scale;
      const value = xMin + ((px - margin.left) / innerW) * (xMax - xMin);
      const lines = [];
      for (const s of series) {
        let best = null;
        let bestDist = Infinity;
        for (const p of s.points || []) {
          const dist = Math.abs(Number(p.x) - value);
          if (dist < bestDist) {
            bestDist = dist;
            best = p;
          }
        }
        if (best && Number.isFinite(Number(best.y))) {
          lines.push(`<span class="tt-dot" style="background:${s.color}"></span>${s.name}：${formatNumber(best.y)}`);
        }
      }
      if (!lines.length) return;
      tooltip.innerHTML = `<div class="tt-title">第 ${formatNumber(value, 0)} 秒</div>${lines.map((l) => `<div>${l}</div>`).join('')}`;
      tooltip.style.display = 'block';
      const left = (event.clientX - container.getBoundingClientRect().left) + 12;
      const top = (event.clientY - container.getBoundingClientRect().top) + 12;
      tooltip.style.left = `${Math.min(left, container.clientWidth - 150)}px`;
      tooltip.style.top = `${top}px`;
    });
    overlay.addEventListener('mouseleave', () => {
      tooltip.style.display = 'none';
    });
  }
}

/**
 * 柱状图
 * @param {SVGElement} svg
 * @param {object} options
 *  - bars: [{ label, value, color?, tooltip?, stack?: [{ label, value, color }] }]
 *          传 stack 时按堆叠渲染（自下而上），value 视为各段之和
 *  - legend: [{ label, color }] 图例项
 *  - xLabel, yLabel, emptyText
 */
export function renderBarChart(svg, options) {
  const {
    bars = [],
    legend = [],
    width = 760,
    height = 260,
    margin = { top: 26, right: 18, bottom: 44, left: 58 },
    xLabel = '',
    yLabel = '',
    emptyText = '暂无数据',
  } = options;

  clearSvg(svg);
  svg.setAttribute('viewBox', `0 0 ${width} ${height}`);
  svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');

  const container = svg.parentElement;
  const tooltip = container ? ensureTooltip(container) : null;
  const innerW = width - margin.left - margin.right;
  const innerH = height - margin.top - margin.bottom;

  if (!bars.length) {
    svg.appendChild(text(emptyText, {
      x: width / 2, y: height / 2, fill: '#8a93a6', 'font-size': 13, 'text-anchor': 'middle',
    }));
    return;
  }

  /** 单根柱子的总量：堆叠柱为各段之和 */
  const totalOf = (bar) => (Array.isArray(bar.stack)
    ? bar.stack.reduce((sum, seg) => sum + (seg.value || 0), 0)
    : (bar.value || 0));

  const yScale = niceScale(Math.max(...bars.map(totalOf), 0));
  const maxValue = yScale.max;
  const slot = innerW / bars.length;
  const barW = Math.max(4, Math.min(46, slot * 0.62));

  yScale.ticks.forEach((tickValue, i) => {
    const y = margin.top + (innerH / yScale.intervals) * i;
    svg.appendChild(el('line', {
      x1: margin.left, x2: margin.left + innerW, y1: y, y2: y, stroke: '#e6eaf2', 'stroke-width': 1,
    }));
    svg.appendChild(text(formatNumber(tickValue, tickDigits(yScale.step)), {
      x: margin.left - 8, y: y + 4, fill: '#8a93a6', 'font-size': 11, 'text-anchor': 'end',
    }));
  });

  const showTooltip = (node, bar, extraLabel) => {
    if (!tooltip) return;
    node.addEventListener('mouseenter', () => {
      const title = extraLabel ? `${bar.label} · ${extraLabel}` : bar.label;
      tooltip.innerHTML = `<div class="tt-title">${title}</div><div>${bar.tooltip || `数量：${formatNumber(totalOf(bar), 0)}`}</div>`;
      tooltip.style.display = 'block';
      const cx = margin.left + slot * bars.indexOf(bar) + slot / 2;
      const scale = container.clientWidth / width;
      tooltip.style.left = `${Math.min(cx * scale + 10, container.clientWidth - 150)}px`;
      tooltip.style.top = `${(margin.top / height) * container.clientHeight + 10}px`;
    });
    node.addEventListener('mouseleave', () => {
      tooltip.style.display = 'none';
    });
  };

  bars.forEach((bar, index) => {
    const x = margin.left + slot * index + (slot - barW) / 2;

    if (Array.isArray(bar.stack) && bar.stack.length) {
      // 堆叠柱：成功 / 失败分段自下而上（G7：成功失败比例直接可见，不只藏在悬浮提示里）
      let acc = 0;
      for (const seg of bar.stack) {
        const segValue = seg.value || 0;
        if (segValue <= 0) continue;
        const h = (segValue / maxValue) * innerH;
        const y = margin.top + innerH - ((acc + segValue) / maxValue) * innerH;
        const rect = el('rect', {
          x, y, width: barW, height: Math.max(h, 1), fill: seg.color || bar.color || CHART_COLORS.bar,
          'fill-opacity': 0.9,
        });
        svg.appendChild(rect);
        showTooltip(rect, bar, seg.label);
        acc += segValue;
      }
    } else {
      const value = bar.value || 0;
      const h = Math.max(value > 0 ? 1.5 : 0, (value / maxValue) * innerH);
      const y = margin.top + innerH - h;
      const rect = el('rect', {
        x, y, width: barW, height: h, rx: 3, fill: bar.color || CHART_COLORS.bar, 'fill-opacity': 0.85,
      });
      svg.appendChild(rect);
      showTooltip(rect, bar);
    }

    if (bars.length <= 16 || index % 2 === 0) {
      svg.appendChild(text(bar.label, {
        x: x + barW / 2, y: margin.top + innerH + 16, fill: '#8a93a6', 'font-size': 10, 'text-anchor': 'middle',
      }));
    }
  });

  svg.appendChild(el('line', {
    x1: margin.left, x2: margin.left + innerW, y1: margin.top + innerH, y2: margin.top + innerH,
    stroke: '#c9d2e3', 'stroke-width': 1,
  }));

  // 图例（G2）
  renderLegend(svg, legend, margin);

  if (xLabel) {
    svg.appendChild(text(xLabel, {
      x: margin.left + innerW / 2, y: height - 4, fill: '#8a93a6', 'font-size': 11, 'text-anchor': 'middle',
    }));
  }
  if (yLabel) {
    svg.appendChild(text(yLabel, {
      x: 12, y: margin.top + innerH / 2, fill: '#8a93a6', 'font-size': 11, 'text-anchor': 'middle',
      transform: `rotate(-90 12 ${margin.top + innerH / 2})`,
    }));
  }
}
