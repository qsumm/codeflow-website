#!/usr/bin/env bash
#
# start.sh —— 启动性能测试平台服务。
#
#   ./start.sh        后台常驻启动（默认），写 PID 文件与日志
#   ./start.sh -f     前台运行（Ctrl+C 退出）
#
# 环境变量：
#   PORT=8801     监听端口（默认 8801）
#   HOST=0.0.0.0  监听地址
#   RUN_DIR       PID 文件目录（默认 <脚本目录>/run）
#   LOG_DIR       日志目录（默认 <脚本目录>/logs）
#   DATA_DIR      数据快照目录（默认 <脚本目录>/data）
#
# 端口被占用时报错退出，不擅自终止他人进程。
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PORT="${PORT:-8801}"
HOST="${HOST:-0.0.0.0}"
NODE_BIN="${NODE_BIN:-node}"

LOG_DIR="${LOG_DIR:-$DIR/logs}"
RUN_DIR="${RUN_DIR:-$DIR/run}"
DATA_DIR="${DATA_DIR:-$DIR/data}"
PID_FILE="$RUN_DIR/server.pid"
LOG_FILE="$LOG_DIR/server.log"

mkdir -p "$LOG_DIR" "$RUN_DIR" "$DATA_DIR"

log()  { printf '[start.sh] %s\n' "$*"; }
fail() { printf '[start.sh] 错误：%s\n' "$*" >&2; exit 1; }

# ------------------------------------------------------------ 依赖检查
command -v "$NODE_BIN" >/dev/null 2>&1 || fail "未找到 node 可执行文件（请安装 Node.js >= 18，或用 NODE_BIN 指定路径）"
NODE_VERSION="$("$NODE_BIN" -v 2>/dev/null || echo unknown)"
log "Node 版本：$NODE_VERSION"

# ------------------------------------------------------------ 已有进程检测
# 必须先于端口占用检测：本实例已运行时端口当然被占用，
# 此时应提示「服务已在运行」而不是误报「端口被他人占用」（P1-1）。
if [ -f "$PID_FILE" ]; then
  OLD_PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
    log "服务已在运行（PID ${OLD_PID}），如需重启请先执行 ./stop.sh"
    exit 0
  fi
  rm -f "$PID_FILE"
fi

# ------------------------------------------------------------ 端口占用检测
port_pids() {
  if command -v lsof >/dev/null 2>&1; then
    lsof -nP -iTCP:"$PORT" -sTCP:LISTEN -t 2>/dev/null || true
  else
    "$NODE_BIN" -e "
      const net=require('net');
      const s=net.connect({host:'127.0.0.1',port:$PORT});
      s.on('connect',()=>{console.log('busy');s.end();});
      s.on('error',()=>{});
      setTimeout(()=>process.exit(0),600);
    " 2>/dev/null || true
  fi
}

OCCUPIED="$(port_pids)"
if [ -n "$OCCUPIED" ]; then
  fail "端口 $PORT 已被占用（PID: $(echo "$OCCUPIED" | tr '\n' ' ')）。请先释放该端口；本脚本不会终止其他进程。"
fi

health_check() {
  "$NODE_BIN" -e "
    fetch('http://127.0.0.1:${PORT}/api/health')
      .then(r => r.ok ? process.exit(0) : process.exit(1))
      .catch(() => process.exit(1));
  " >/dev/null 2>&1
}

# ------------------------------------------------------------ 前台模式
if [ "${1:-}" = "-f" ] || [ "${1:-}" = "--foreground" ]; then
  log "前台启动：http://localhost:${PORT}"
  exec env PORT="$PORT" HOST="$HOST" "$NODE_BIN" "$DIR/server/index.js"
fi

# ------------------------------------------------------------ 后台常驻模式
log "后台启动 http://localhost:${PORT}（日志：${LOG_FILE}）"
cd "$DIR"
PORT="$PORT" HOST="$HOST" nohup "$NODE_BIN" "$DIR/server/index.js" >>"$LOG_FILE" 2>&1 &
SERVER_PID=$!
echo "$SERVER_PID" > "$PID_FILE"

for _ in $(seq 1 40); do
  if ! kill -0 "$SERVER_PID" 2>/dev/null; then
    rm -f "$PID_FILE"
    fail "服务启动失败，请查看日志：$LOG_FILE"
  fi
  if health_check; then
    log "服务已就绪（PID ${SERVER_PID}）"
    log "访问地址：http://localhost:${PORT}"
    log "压测样例目标：http://localhost:${PORT}/sample"
    exit 0
  fi
  sleep 0.25
done

kill "$SERVER_PID" 2>/dev/null || true
rm -f "$PID_FILE"
fail "等待服务就绪超时，请查看日志：$LOG_FILE"
