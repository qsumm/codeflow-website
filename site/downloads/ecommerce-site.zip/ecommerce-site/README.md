# 云选商城 · 电商网站（商店前台 + 管理端）

一个可浏览、可下单的小型电商网站：**商店前台**（商品列表 / 商品详情 / 加入购物车 / 购物车管理 / 结算下单 / 订单查询）+ **管理端**（商品上下架、库存与价格编辑、订单列表与发货流转）。

- 单服务实现（Node.js ≥ 18，**零第三方运行时依赖**），监听端口 **8802**
- 服务端渲染 HTML（模板字符串），无前端构建步骤；管理端独立路径 `/admin`
- 数据持久化：优先使用 Node 内置 `node:sqlite`（`data/shop.db`），不可用时自动降级为 JSON 文件（`data/shop.json`），**不依赖任何外部数据库服务**
- 购物车存放于服务端会话，通过 HttpOnly `sid` Cookie 标识

## 快速开始

```bash
cd /Users/summer/delivery-verification/products/ecommerce-site
./start.sh                 # 后台常驻启动，PID -> data/app.pid，日志 -> logs/app.log
open http://localhost:8802/ # 商店前台
open http://localhost:8802/admin  # 管理端
```

其他命令：

```bash
./stop.sh      # 停止服务
./restart.sh   # 重启服务
npm start      # 前台直接运行（Ctrl+C 退出）
```

## 功能清单

### 商店前台（`/`）

| 路由 | 说明 |
| --- | --- |
| `GET /` | 商品列表：卡片网格、分类筛选、关键词搜索 |
| `GET /product/:id` | 商品详情：图片 / 名称 / 价格 / 库存 / 描述，可选数量加购 |
| `POST /cart/add` | 加入购物车（`product_id`、`qty`） |
| `GET /cart` | 购物车：改数量、删除、合计、跳转结算 |
| `POST /cart/update` / `POST /cart/remove` | 购物车行操作 |
| `GET /checkout` / `POST /checkout` | 结算下单：收货人 / 电话 / 地址校验并生成订单 |
| `GET /order/success/:orderNo` | 下单成功页（订单号、商品、金额、收货信息） |
| `GET /order/query` | 按订单号查询订单状态与明细 |
| `POST /order/cancel` | 取消待发货订单，库存回滚 |
| `GET /healthz` | 健康检查（JSON） |

### 管理端（`/admin`）

| 路由 | 说明 |
| --- | --- |
| `GET /admin` | 概览：商品数、在售数、订单数、待发货 / 已发货 |
| `GET /admin/products` | 商品管理：改价格 / 改库存、上架 / 下架 |
| `POST /admin/products/:id/update` / `POST /admin/products/:id/toggle` | 商品维护动作 |
| `GET /admin/orders` | 订单列表，可按状态筛选 |
| `POST /admin/orders/:orderNo/ship` | 发货：`待发货 → 已发货` |

管理端默认免登录（演示态）。设置环境变量 `ADMIN_PASSWORD` 后，管理端会要求口令登录：

```bash
ADMIN_PASSWORD=your-password ./start.sh
```

## 订单状态机

```
                 ┌──────────────┐
   下单成功 ───▶ │  pending 待发货 │ ──发货──▶ shipped 已发货
                 └──────┬───────┘
                        │ 取消（库存回滚）
                        ▼
                 cancelled 已取消
```

- 订单号格式：`NO` + `YYYYMMDDHHmmss` + 4 位随机数（如 `NO202611120530001234`）
- 下单在同一事务内完成「校验 → 扣库存 → 建订单 + 明细」，失败整体回滚

## 目录结构

```
ecommerce-site/
├── src/
│   ├── server.js            # HTTP 入口：路由分发、静态资源、Cookie 会话、优雅退出
│   ├── router.js            # 极简路由（支持 :param）
│   ├── config.js            # 端口 / 路径 / 状态常量
│   ├── seed.js              # 种子数据（10 商品 / 4 分类）与 SVG 占位图生成
│   ├── storage/             # 存储层：sqlite.js（首选）/ json.js（降级）/ index.js（工厂）
│   ├── services/            # 业务层：products / cart / orders
│   ├── views/               # 服务端渲染视图：layout / store / cart / checkout / order / admin
│   └── static/              # 静态资源：style.css / app.js / favicon.svg / img/*.svg
├── scripts/
│   ├── bench.js             # 零依赖压测脚本
│   └── gen-charts.js        # 生成 3 张 SVG 图表
├── test/
│   ├── unit.test.js         # 单元 + HTTP 集成测试（node --test）
│   └── e2e.js               # 端到端全链路自测
├── data/                    # 运行时数据：shop.db / shop.json / app.pid
├── logs/                    # 运行日志：app.log
├── report/                  # 压测结果与图表
├── start.sh / stop.sh / restart.sh
└── package.json
```

## 测试与压测

```bash
npm test          # 单元 + 集成测试（node --test test/unit.test.js）
npm run e2e       # 端到端全链路自测（浏览→加购→改数量→删除→下单→查询→发货→持久化）
npm run bench     # 性能压测，输出 report/bench-results.json
npm run charts    # 依据压测结果生成 3 张 SVG 图表
```

压测参数（需求澄清 §4）：读场景并发 50 / 60 秒 / 读取混合 6:3:1；写场景并发 10 / 30 秒 / 隔离数据目录。
验收阈值：读 QPS ≥ 300、P95 ≤ 50ms、P99 ≤ 200ms、错误率 0%；写 QPS ≥ 150、P95 ≤ 100ms、P99 ≤ 500ms、错误率 0%。

## 环境变量

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `PORT` | `8802` | 监听端口 |
| `HOST` | `127.0.0.1` | 监听地址 |
| `DATA_DIR` | `./data` | 数据目录 |
| `ADMIN_PASSWORD` | 空（免登录） | 管理端口令 |

## 数据与种子

首次启动自动写入种子数据（幂等，不覆盖已有数据）：10 个商品、4 个分类（数码配件 / 家居生活 / 食品饮料 / 图书文具），
价格 9.9 ~ 299.0，库存 5 ~ 100；其中 `p10 硬壳笔记本 A5` 预置为已下架，便于验证「下架商品前台不可见」。

如需重置数据，停止服务后删除 `data/` 目录下的 `shop.db*` / `shop.json` 再重新启动即可。
