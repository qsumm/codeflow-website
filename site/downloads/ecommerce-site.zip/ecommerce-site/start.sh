#!/usr/bin/env bash
# 启动电商网站服务（单服务、端口 8802、零外部依赖、零三方依赖）
# 用法：./start.sh
#   后台常驻启动，PID 写入 data/app.pid，日志写入 logs/app.log，
#   启动后轮询 /healthz（最多 30 秒）确认可用。
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

PORT="${PORT:-8802}"
HOST="${HOST:-127.0.0.1}"
NODE_BIN="${NODE_BIN:-node}"
DATA_DIR="${DATA_DIR:-$ROOT_DIR/data}"
LOG_DIR="$ROOT_DIR/logs"
LOG_FILE="$LOG_DIR/app.log"
PID_FILE="$DATA_DIR/app.pid"

# ---------------------------------------------------------------- 环境检查
if ! command -v "$NODE_BIN" >/dev/null 2>&1; then
  echo "[start] 错误：未找到 node，请先安装 Node.js >= 18" >&2
  exit 1
fi

NODE_MAJOR="$("$NODE_BIN" -p 'process.versions.node.split(".")[0]')"
if [ "$NODE_MAJOR" -lt 18 ]; then
  echo "[start] 错误：Node.js 版本过低（当前 $("$NODE_BIN" -v)），要求 >= 18" >&2
  exit 1
fi

mkdir -p "$LOG_DIR" "$DATA_DIR" "$ROOT_DIR/report"

# ---------------------------------------------------------------- 已在运行
if [ -f "$PID_FILE" ]; then
  OLD_PID="$(cat "$PID_FILE" 2>/dev/null || true)"
  if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
    echo "[start] 服务已在运行（PID ${OLD_PID}），访问 http://localhost:${PORT}/"
    exit 0
  fi
  rm -f "$PID_FILE"
fi

# ---------------------------------------------------------------- 端口占用
port_busy() {
  if command -v lsof >/dev/null 2>&1; then
    lsof -nP -iTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1 && return 0
  fi
  if command -v nc >/dev/null 2>&1; then
    nc -z 127.0.0.1 "$PORT" >/dev/null 2>&1 && return 0
  fi
  return 1
}

if port_busy; then
  echo "[start] 错误：端口 ${PORT} 已被其他进程占用，请先执行 ./stop.sh 或更换 PORT" >&2
  lsof -nP -iTCP:"$PORT" -sTCP:LISTEN >&2 2>/dev/null || true
  exit 1
fi

# ---------------------------------------------------------------- 启动
echo "[start] 正在启动 ecommerce-site ..."
PORT="$PORT" HOST="$HOST" DATA_DIR="$DATA_DIR" nohup "$NODE_BIN" "$ROOT_DIR/src/server.js" >>"$LOG_FILE" 2>&1 &
SERVER_PID=$!
echo "$SERVER_PID" >"$PID_FILE"

healthy() {
  if command -v curl >/dev/null 2>&1; then
    curl -fsS "http://${HOST}:${PORT}/healthz" >/dev/null 2>&1
  else
    "$NODE_BIN" -e "require('http').get('http://${HOST}:${PORT}/healthz',r=>process.exit(r.statusCode===200?0:1)).on('error',()=>process.exit(1))" >/dev/null 2>&1
  fi
}

for _ in $(seq 1 30); do
  if ! kill -0 "$SERVER_PID" 2>/dev/null; then
    echo "[start] 启动失败，进程已退出，日志尾部：" >&2
    tail -n 20 "$LOG_FILE" >&2 || true
    rm -f "$PID_FILE"
    exit 1
  fi
  if healthy; then
    echo "[start] 启动成功： http://localhost:${PORT}/"
    echo "[start] 管理端：    http://localhost:${PORT}/admin"
    echo "[start] PID: $SERVER_PID   日志: $LOG_FILE"
    exit 0
  fi
  sleep 1
done

echo "[start] 启动超时（30 秒内 /healthz 未就绪），日志尾部：" >&2
tail -n 20 "$LOG_FILE" >&2 || true
exit 1
