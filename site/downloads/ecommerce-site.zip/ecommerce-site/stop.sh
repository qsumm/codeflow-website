#!/usr/bin/env bash
# 停止电商网站服务
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DATA_DIR="${DATA_DIR:-$ROOT_DIR/data}"
PID_FILE="$DATA_DIR/app.pid"

if [ ! -f "$PID_FILE" ]; then
  echo "[stop] 未找到 PID 文件，服务可能未运行"
  exit 0
fi

PID="$(cat "$PID_FILE" 2>/dev/null || true)"
if [ -z "$PID" ] || ! kill -0 "$PID" 2>/dev/null; then
  echo "[stop] 进程不存在，清理 PID 文件"
  rm -f "$PID_FILE"
  exit 0
fi

echo "[stop] 正在停止服务（PID ${PID}）..."
kill "$PID" 2>/dev/null || true
for _ in $(seq 1 15); do
  if ! kill -0 "$PID" 2>/dev/null; then
    rm -f "$PID_FILE"
    echo "[stop] 已停止"
    exit 0
  fi
  sleep 1
done

echo "[stop] 优雅退出超时，强制结束"
kill -9 "$PID" 2>/dev/null || true
rm -f "$PID_FILE"
echo "[stop] 已停止"
