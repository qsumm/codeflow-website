#!/usr/bin/env bash
# 重启电商网站服务
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT_DIR"

"$ROOT_DIR/stop.sh"
sleep 1
"$ROOT_DIR/start.sh"
