#!/usr/bin/env bash
# 针对「正在运行中的实例」做一遍真实 HTTP 全链路冒烟（验收标准 1~6）。
# 用法：./scripts/live-smoke.sh [base_url]     默认 http://localhost:8802
set -uo pipefail

BASE="${1:-http://localhost:8802}"
JAR="$(mktemp)"
PASS=0
FAIL=0

ok()  { PASS=$((PASS+1)); echo "  ✓ $1"; }
bad() { FAIL=$((FAIL+1)); echo "  ✗ $1${2:+ — $2}"; }

# has <文本> <模式>：匹配返回 1，不匹配返回 0
has() { printf '%s' "$1" | grep -q -- "$2" && echo 1 || echo 0; }
# check <0|1> <描述> [详情]
check() { if [ "$1" = "1" ]; then ok "$2"; else bad "$2" "${3:-}"; fi; }

echo "[live-smoke] 目标地址: $BASE"

# 1) 首页商品列表（图片 / 名称 / 价格）
HOME_HTML="$(curl -s -c "$JAR" "$BASE/")"
check "$(has "$HOME_HTML" 'product-grid')" "首页可访问并返回商品列表"
check "$(has "$HOME_HTML" '/static/img/p01.svg')" "首页含商品图片"
check "$(has "$HOME_HTML" '无线蓝牙耳机')" "首页含商品名称"
check "$(has "$HOME_HTML" '¥199.00')" "首页含商品价格"
check "$(has "$HOME_HTML" '数码配件')" "首页含商品分类"

# 2) 详情页 + 加购
DETAIL="$(curl -s -b "$JAR" "$BASE/product/p01")"
check "$(has "$DETAIL" '无线蓝牙耳机')" "商品详情可打开"
curl -s -o /dev/null -b "$JAR" -c "$JAR" -X POST -d 'product_id=p01&qty=2' "$BASE/cart/add"
CART="$(curl -s -b "$JAR" "$BASE/cart")"
check "$(has "$CART" '398.00')" "加购后购物车总价联动（2 件 = 398.00）"

# 3) 改数量
curl -s -o /dev/null -b "$JAR" -c "$JAR" -X POST -d 'product_id=p01&qty=3' "$BASE/cart/update"
CART="$(curl -s -b "$JAR" "$BASE/cart")"
check "$(has "$CART" '597.00')" "改数量后总价联动（3 件 = 597.00）"

# 4) 删除
curl -s -o /dev/null -b "$JAR" -c "$JAR" -X POST -d 'product_id=p01' "$BASE/cart/remove"
CART="$(curl -s -b "$JAR" "$BASE/cart")"
check "$(has "$CART" '购物车还是空的')" "删除后购物车为空"

# 5) 下单
curl -s -o /dev/null -b "$JAR" -c "$JAR" -X POST -d 'product_id=p01&qty=1' "$BASE/cart/add"
LOC="$(curl -s -o /dev/null -w '%{redirect_url}' -b "$JAR" -c "$JAR" -X POST \
  -d 'receiver=张三&phone=13800138000&address=北京市朝阳区建国路1号' "$BASE/checkout")"
ORDER_NO="$(basename "$LOC")"
check "$(has "$ORDER_NO" '^NO[0-9]\{18\}$')" "下单成功并生成订单号（${ORDER_NO}）"
SUCCESS="$(curl -s -b "$JAR" "$BASE/order/success/${ORDER_NO}")"
check "$(has "$SUCCESS" "$ORDER_NO")" "下单成功页展示订单号"

# 6) 订单查询 + 管理端发货
QUERY="$(curl -s -b "$JAR" "$BASE/order/query?order_no=${ORDER_NO}")"
check "$(has "$QUERY" '待发货')" "订单查询显示待发货"
ADMIN="$(curl -s "$BASE/admin/orders")"
check "$(has "$ADMIN" "$ORDER_NO")" "管理端订单列表可见新订单"
curl -s -o /dev/null -X POST "$BASE/admin/orders/${ORDER_NO}/ship"
QUERY2="$(curl -s -b "$JAR" "$BASE/order/query?order_no=${ORDER_NO}")"
check "$(has "$QUERY2" '已发货')" "发货后前台查询显示已发货"

# 7) 管理端上下架 → 前台同步
curl -s -o /dev/null -X POST -d 'on_sale=1' "$BASE/admin/products/p10/toggle"
HOME2="$(curl -s "$BASE/")"
check "$(has "$HOME2" '硬壳笔记本')" "上架后前台出现该商品"
curl -s -o /dev/null -X POST -d 'on_sale=0' "$BASE/admin/products/p10/toggle"
HOME3="$(curl -s "$BASE/")"
check "$( [ "$(has "$HOME3" '硬壳笔记本')" = "0" ] && echo 1 || echo 0)" "下架后前台不再展示该商品"

# 8) 种子数据规模
check "$( [ "$(has "$HOME3" '¥')" = "1" ] && echo 1 || echo 0)" "种子商品开箱可浏览"

echo "  订单号留档: ${ORDER_NO}"
rm -f "$JAR"
echo "[live-smoke] 通过 ${PASS} 项，失败 ${FAIL} 项"
[ "$FAIL" -eq 0 ] || exit 1
