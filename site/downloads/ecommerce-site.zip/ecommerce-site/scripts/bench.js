'use strict';

/**
 * 性能压测脚本（零三方依赖，仅用 node:http / node:child_process）。
 *
 * 用法：
 *   node scripts/bench.js                    # 按需求澄清 §4 的标准参数跑完整压测
 *   BENCH_READ_SECONDS=10 BENCH_WRITE_SECONDS=5 node scripts/bench.js   # 冒烟
 *
 * 指标口径：
 *   QPS      = 成功请求数 / 实际压测窗口秒数
 *   P50/P95/P99 = 端到端响应耗时分位数（毫秒，保留 2 位小数）
 *   错误率   = 非 2xx/3xx 响应占比（并区分 4xx / 5xx 与网络异常）
 *
 * 读压测：并发 50，60 秒，读取混合 6:3:1（首页列表 : 商品详情 : 订单查询）。
 * 写压测：并发 10，30 秒（加购 → 下单 → 取消回滚库存），使用独立数据目录，不污染交付数据。
 */

const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const REPORT_DIR = path.join(ROOT, 'report');

const READ_SECONDS = Number(process.env.BENCH_READ_SECONDS || 60);
const WRITE_SECONDS = Number(process.env.BENCH_WRITE_SECONDS || 30);
const READ_CONCURRENCY = Number(process.env.BENCH_READ_CONCURRENCY || 50);
const WRITE_CONCURRENCY = Number(process.env.BENCH_WRITE_CONCURRENCY || 10);
const BENCH_PORT = Number(process.env.BENCH_PORT || 8899);
const BASE = `http://127.0.0.1:${BENCH_PORT}`;

const THRESHOLDS = {
  read: { qps: 300, p95: 50, p99: 200, errorRate: 0 },
  write: { qps: 150, p95: 100, p99: 500, errorRate: 0 },
};

// ---------------------------------------------------------------- HTTP 客户端

function request(method, urlPath, { body, cookie, headers } = {}) {
  return new Promise((resolve) => {
    const payload = body === undefined ? null : new URLSearchParams(body).toString();
    const options = {
      method,
      path: urlPath,
      host: '127.0.0.1',
      port: BENCH_PORT,
      headers: {
        Host: `127.0.0.1:${BENCH_PORT}`,
        Accept: 'text/html,application/json',
        ...(payload ? { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(payload) } : {}),
        ...(cookie ? { Cookie: cookie } : {}),
        ...(headers || {}),
      },
    };
    const started = process.hrtime.bigint();
    const req = http.request(options, (res) => {
      let length = 0;
      res.on('data', (chunk) => { length += chunk.length; });
      res.on('end', () => {
        const elapsed = Number(process.hrtime.bigint() - started) / 1e6;
        resolve({ status: res.statusCode, headers: res.headers, bodyLength: length, ms: elapsed });
      });
    });
    req.on('error', (err) => {
      const elapsed = Number(process.hrtime.bigint() - started) / 1e6;
      resolve({ status: 0, error: err.message, ms: elapsed });
    });
    if (payload) req.write(payload);
    req.end();
  });
}

/** 极简 cookie 罐：只关心 sid */
function cookieJar() {
  let sid = '';
  return {
    header: () => (sid ? `sid=${sid}` : ''),
    absorb(res) {
      const raw = res.headers['set-cookie'];
      if (!raw) return;
      for (const line of raw) {
        const [pair] = line.split(';');
        const [key, value] = pair.split('=');
        if (key.trim() === 'sid') sid = value.trim();
      }
    },
  };
}

// ---------------------------------------------------------------- 服务进程

function startServer(dataDir, logFile) {
  fs.mkdirSync(dataDir, { recursive: true });
  const out = fs.openSync(logFile, 'a');
  const child = spawn(process.execPath, [path.join(ROOT, 'src', 'server.js')], {
    env: { ...process.env, PORT: String(BENCH_PORT), HOST: '127.0.0.1', DATA_DIR: dataDir },
    stdio: ['ignore', out, out],
  });
  return child;
}

async function waitHealthy(timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const res = await request('GET', '/healthz');
    if (res.status === 200) return true;
    await new Promise((r) => setTimeout(r, 200));
  }
  throw new Error('压测服务启动超时');
}

// ---------------------------------------------------------------- 统计

function percentile(sorted, p) {
  if (!sorted.length) return 0;
  const index = Math.min(sorted.length - 1, Math.max(0, Math.ceil((p / 100) * sorted.length) - 1));
  return Math.round(sorted[index] * 100) / 100;
}

function summarize({ name, latencies, statusCounts, networkErrors, elapsedSec }) {
  const sorted = latencies.slice().sort((a, b) => a - b);
  const total = sorted.length;
  const success = sorted.length - statusCounts['4xx'] - statusCounts['5xx'] - networkErrors;
  const error = total - success;
  const qps = Math.round((success / elapsedSec) * 100) / 100;
  const errorRate = total ? Math.round((error / total) * 1000000) / 10000 : 0;
  const result = {
    name,
    requests: total,
    success,
    error,
    errorRate,
    networkErrors,
    statusCounts,
    windowSeconds: Math.round(elapsedSec * 100) / 100,
    qps,
    p50: percentile(sorted, 50),
    p95: percentile(sorted, 95),
    p99: percentile(sorted, 99),
    max: sorted.length ? Math.round(sorted[sorted.length - 1] * 100) / 100 : 0,
    min: sorted.length ? Math.round(sorted[0] * 100) / 100 : 0,
    avg: sorted.length ? Math.round((sorted.reduce((a, b) => a + b, 0) / sorted.length) * 100) / 100 : 0,
  };
  const t = THRESHOLDS[name];
  result.thresholds = t;
  result.pass =
    result.qps >= t.qps &&
    result.p95 <= t.p95 &&
    result.p99 <= t.p99 &&
    result.errorRate <= t.errorRate;
  return result;
}

function collector() {
  return { latencies: [], statusCounts: { '2xx': 0, '3xx': 0, '4xx': 0, '5xx': 0 }, networkErrors: 0 };
}

function record(acc, res) {
  acc.latencies.push(res.ms);
  if (res.status === 0) { acc.networkErrors += 1; return; }
  const family = Math.floor(res.status / 100);
  const key = `${family}xx`;
  if (acc.statusCounts[key] === undefined) acc.statusCounts[key] = 0;
  acc.statusCounts[key] += 1;
}

// ---------------------------------------------------------------- 读压测

async function readPhase(durationSec, concurrency) {
  const acc = collector();

  // 预置一个订单，供「订单查询」读取（保证 200 而非 404）
  const setup = cookieJar();
  let orderNo = '';
  const addRes = await request('POST', '/cart/add', { body: { product_id: 'p01', qty: 1 }, cookie: setup.header() });
  setup.absorb(addRes);
  const checkoutRes = await request('POST', '/checkout', {
    body: { receiver: '压测用户', phone: '13800000000', address: '压测隔离地址' },
    cookie: setup.header(),
  });
  setup.absorb(checkoutRes);
  const location = checkoutRes.headers.location || '';
  orderNo = decodeURIComponent(location.split('/order/success/')[1] || '');

  const products = ['p01', 'p02', 'p03', 'p05', 'p06', 'p08', 'p09'];
  const deadline = Date.now() + durationSec * 1000;
  const startedAt = Date.now();

  async function worker(index) {
    const jar = cookieJar();
    while (Date.now() < deadline) {
      const roll = Math.random();
      let urlPath;
      if (roll < 0.6) urlPath = '/';
      else if (roll < 0.9) urlPath = `/product/${products[(index + Math.floor(Math.random() * products.length)) % products.length]}`;
      else urlPath = `/order/query?order_no=${encodeURIComponent(orderNo)}`;
      const res = await request('GET', urlPath, { cookie: jar.header() });
      jar.absorb(res);
      record(acc, res);
    }
  }

  await Promise.all(Array.from({ length: concurrency }, (_, i) => worker(i)));
  const elapsed = (Date.now() - startedAt) / 1000;
  return summarize({ name: 'read', latencies: acc.latencies, statusCounts: acc.statusCounts, networkErrors: acc.networkErrors, elapsedSec: elapsed });
}

// ---------------------------------------------------------------- 写压测

async function writePhase(durationSec, concurrency) {
  const acc = collector();
  const products = ['p01', 'p02', 'p03', 'p05', 'p06', 'p08', 'p09'];
  const deadline = Date.now() + durationSec * 1000;
  const startedAt = Date.now();

  async function worker(index) {
    const jar = cookieJar();
    let seq = 0;
    while (Date.now() < deadline) {
      seq += 1;
      const productId = products[(index + seq) % products.length];

      // 1) 加购
      const addRes = await request('POST', '/cart/add', { body: { product_id: productId, qty: 1 }, cookie: jar.header() });
      jar.absorb(addRes);
      record(acc, addRes);

      // 2) 下单
      const checkoutRes = await request('POST', '/checkout', {
        body: { receiver: '压测用户', phone: '13800000000', address: '压测隔离地址' },
        cookie: jar.header(),
      });
      jar.absorb(checkoutRes);
      record(acc, checkoutRes);

      // 3) 取消订单（回滚库存，保证长压测不出现 409 库存不足导致的伪错误）
      const location = checkoutRes.headers.location || '';
      const orderNo = decodeURIComponent(location.split('/order/success/')[1] || '');
      if (orderNo) {
        const cancelRes = await request('POST', '/order/cancel', { body: { order_no: orderNo }, cookie: jar.header() });
        jar.absorb(cancelRes);
        record(acc, cancelRes);
      }
    }
  }

  await Promise.all(Array.from({ length: concurrency }, (_, i) => worker(i)));
  const elapsed = (Date.now() - startedAt) / 1000;
  return summarize({ name: 'write', latencies: acc.latencies, statusCounts: acc.statusCounts, networkErrors: acc.networkErrors, elapsedSec: elapsed });
}

// ---------------------------------------------------------------- 主流程

async function main() {
  fs.mkdirSync(REPORT_DIR, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const readDir = path.join(os.tmpdir(), `ecommerce-bench-read-${stamp}`);
  const writeDir = path.join(os.tmpdir(), `ecommerce-bench-write-${stamp}`);
  const logFile = path.join(ROOT, 'logs', 'bench.log');
  fs.mkdirSync(path.join(ROOT, 'logs'), { recursive: true });

  console.log('[bench] 启动压测服务（隔离数据目录）...');
  const readChild = startServer(readDir, logFile);
  let writeChild = null;
  try {
    await waitHealthy();
    console.log(`[bench] 读压测：并发 ${READ_CONCURRENCY}，${READ_SECONDS}s，混合 6:3:1 ...`);
    const read = await readPhase(READ_SECONDS, READ_CONCURRENCY);

    readChild.kill('SIGTERM');
    await new Promise((r) => setTimeout(r, 800));

    writeChild = startServer(writeDir, logFile);
    await waitHealthy();
    console.log(`[bench] 写压测：并发 ${WRITE_CONCURRENCY}，${WRITE_SECONDS}s ...`);
    const write = await writePhase(WRITE_SECONDS, WRITE_CONCURRENCY);

    const result = {
      meta: {
        generatedAt: new Date().toISOString(),
        node: process.version,
        platform: `${os.platform()} ${os.arch()}`,
        port: BENCH_PORT,
        readConfig: { concurrency: READ_CONCURRENCY, seconds: READ_SECONDS, mix: '首页列表 6 : 商品详情 3 : 订单查询 1' },
        writeConfig: { concurrency: WRITE_CONCURRENCY, seconds: WRITE_SECONDS, mix: '加购 → 下单 → 取消（隔离数据目录）' },
      },
      read,
      write,
      pass: read.pass && write.pass,
    };

    fs.writeFileSync(path.join(REPORT_DIR, 'bench-results.json'), `${JSON.stringify(result, null, 2)}\n`);
    console.log('\n===== 压测结果 =====');
    console.log(`读: QPS=${read.qps} (≥${read.thresholds.qps}) P95=${read.p95}ms P99=${read.p99}ms 错误率=${read.errorRate}% -> ${read.pass ? 'PASS' : 'FAIL'}`);
    console.log(`写: QPS=${write.qps} (≥${write.thresholds.qps}) P95=${write.p95}ms P99=${write.p99}ms 错误率=${write.errorRate}% -> ${write.pass ? 'PASS' : 'FAIL'}`);
    console.log(`总体: ${result.pass ? 'PASS' : 'FAIL'}  报告: report/bench-results.json`);
    process.exitCode = result.pass ? 0 : 1;
  } finally {
    try { readChild.kill('SIGTERM'); } catch (_) { /* ignore */ }
    try { if (writeChild) writeChild.kill('SIGTERM'); } catch (_) { /* ignore */ }
  }
}

main().catch((err) => {
  console.error('[bench] 失败:', err);
  process.exit(1);
});
