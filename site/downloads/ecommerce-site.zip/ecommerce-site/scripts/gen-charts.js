'use strict';

/**
 * 依据 report/bench-results.json 生成 3 张 SVG 图表（零三方依赖）：
 *   report/qps.svg                   —— 读/写 QPS 与阈值对比
 *   report/latency-percentiles.svg   —— P50/P95/P99 分位延迟与阈值线
 *   report/error-rate.svg            —— 错误率（4xx / 5xx / 网络异常）
 *
 * 用法：node scripts/gen-charts.js
 */

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const REPORT_DIR = path.join(ROOT, 'report');
const INPUT = path.join(REPORT_DIR, 'bench-results.json');

const PALETTE = {
  read: '#2f6df6',
  write: '#f08c00',
  line: '#dc2626',
  grid: '#e6e9ef',
  ink: '#1f2933',
  muted: '#6b7785',
};

function esc(text) {
  return String(text).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
}

/** 生成一张带坐标轴的柱状图 */
function barChart({ title, subtitle, width, height, groups, series, yMax, yLabel, thresholdLines = [], valueFormat }) {
  const pad = { top: 72, right: 28, bottom: 68, left: 64 };
  const plotW = width - pad.left - pad.right;
  const plotH = height - pad.top - pad.bottom;
  const groupW = plotW / groups.length;
  const barGap = 10;
  const barW = Math.min(58, (groupW - barGap * (series.length + 1)) / series.length);

  const y = (value) => pad.top + plotH - (Math.min(value, yMax) / yMax) * plotH;

  const parts = [];
  parts.push(`<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(title)}">`);
  parts.push(`<rect width="${width}" height="${height}" fill="#ffffff"/>`);
  parts.push(`<text x="${pad.left}" y="34" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="19" font-weight="600" fill="${PALETTE.ink}">${esc(title)}</text>`);
  parts.push(`<text x="${pad.left}" y="55" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="13" fill="${PALETTE.muted}">${esc(subtitle)}</text>`);

  // 网格与 Y 轴刻度
  const ticks = 5;
  for (let i = 0; i <= ticks; i += 1) {
    const value = (yMax / ticks) * i;
    const yy = y(value);
    parts.push(`<line x1="${pad.left}" y1="${yy.toFixed(1)}" x2="${width - pad.right}" y2="${yy.toFixed(1)}" stroke="${PALETTE.grid}" stroke-width="1"/>`);
    parts.push(`<text x="${pad.left - 10}" y="${(yy + 4).toFixed(1)}" text-anchor="end" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="12" fill="${PALETTE.muted}">${valueFormat(value)}</text>`);
  }
  parts.push(`<line x1="${pad.left}" y1="${pad.top + plotH}" x2="${width - pad.right}" y2="${pad.top + plotH}" stroke="#cbd2dd" stroke-width="1"/>`);
  parts.push(`<text x="16" y="${pad.top + plotH / 2}" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="12" fill="${PALETTE.muted}" transform="rotate(-90 16 ${pad.top + plotH / 2})" text-anchor="middle">${esc(yLabel)}</text>`);

  // 柱体
  groups.forEach((group, gi) => {
    const groupStart = pad.left + gi * groupW + barGap;
    series.forEach((s, si) => {
      const value = s.values[gi];
      const x = groupStart + si * (barW + 6);
      const yy = y(value);
      const h = Math.max(1, pad.top + plotH - yy);
      parts.push(`<rect x="${x.toFixed(1)}" y="${yy.toFixed(1)}" width="${barW.toFixed(1)}" height="${h.toFixed(1)}" fill="${s.color}" rx="4"/>`);
      parts.push(`<text x="${(x + barW / 2).toFixed(1)}" y="${(yy - 7).toFixed(1)}" text-anchor="middle" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="12" font-weight="600" fill="${PALETTE.ink}">${valueFormat(value)}</text>`);
    });
    parts.push(`<text x="${(pad.left + gi * groupW + groupW / 2).toFixed(1)}" y="${pad.top + plotH + 24}" text-anchor="middle" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="13" fill="${PALETTE.ink}">${esc(group)}</text>`);
  });

  // 阈值线
  thresholdLines.forEach((line) => {
    const yy = y(line.value);
    parts.push(`<line x1="${pad.left}" y1="${yy.toFixed(1)}" x2="${width - pad.right}" y2="${yy.toFixed(1)}" stroke="${PALETTE.line}" stroke-width="1.5" stroke-dasharray="6 4"/>`);
    parts.push(`<text x="${width - pad.right - 4}" y="${(yy - 6).toFixed(1)}" text-anchor="end" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="11" fill="${PALETTE.line}">${esc(line.label)}</text>`);
  });

  // 图例
  let lx = pad.left;
  series.forEach((s) => {
    parts.push(`<rect x="${lx}" y="${height - 30}" width="12" height="12" rx="3" fill="${s.color}"/>`);
    parts.push(`<text x="${lx + 18}" y="${height - 20}" font-family="-apple-system,Helvetica,Arial,sans-serif" font-size="12" fill="${PALETTE.ink}">${esc(s.name)}</text>`);
    lx += 22 + s.name.length * 13;
  });

  parts.push('</svg>');
  return parts.join('\n');
}

function main() {
  if (!fs.existsSync(INPUT)) {
    console.error(`[charts] 缺少 ${INPUT}，请先运行 node scripts/bench.js`);
    process.exit(1);
  }
  const data = JSON.parse(fs.readFileSync(INPUT, 'utf8'));
  fs.mkdirSync(REPORT_DIR, { recursive: true });

  const qpsMax = Math.max(
    data.read.qps, data.write.qps,
    data.read.thresholds.qps, data.write.thresholds.qps
  ) * 1.25;

  const qpsSvg = barChart({
    title: '吞吐量 QPS（读 / 写场景）',
    subtitle: `生成时间 ${data.meta.generatedAt} · ${data.meta.platform} · Node ${data.meta.node}`,
    width: 760,
    height: 440,
    groups: ['读场景（并发 50 / 60s）', '写场景（并发 10 / 30s）'],
    series: [
      { name: '实测 QPS', color: PALETTE.read, values: [data.read.qps, data.write.qps] },
    ],
    yMax: qpsMax,
    yLabel: 'QPS (requests/s)',
    thresholdLines: [
      { value: data.read.thresholds.qps, label: `读阈值 ${data.read.thresholds.qps}` },
      { value: data.write.thresholds.qps, label: `写阈值 ${data.write.thresholds.qps}` },
    ],
    valueFormat: (v) => String(Math.round(v * 100) / 100),
  });
  fs.writeFileSync(path.join(REPORT_DIR, 'qps.svg'), `${qpsSvg}\n`);

  const latMax = Math.max(
    data.read.p99, data.write.p99,
    data.read.thresholds.p99, data.write.thresholds.p99
  ) * 1.2;

  const latencySvg = barChart({
    title: '端到端延迟分位数 P50 / P95 / P99',
    subtitle: `读：${data.read.requests} 请求 · 写：${data.write.requests} 请求（毫秒）`,
    width: 860,
    height: 460,
    groups: ['读场景', '写场景'],
    series: [
      { name: 'P50', color: '#7aa8ff', values: [data.read.p50, data.write.p50] },
      { name: 'P95', color: PALETTE.read, values: [data.read.p95, data.write.p95] },
      { name: 'P99', color: '#1e4fbd', values: [data.read.p99, data.write.p99] },
    ],
    yMax: latMax,
    yLabel: '延迟 (ms)',
    thresholdLines: [
      { value: data.read.thresholds.p95, label: `读 P95 阈值 ${data.read.thresholds.p95}ms` },
      { value: data.write.thresholds.p95, label: `写 P95 阈值 ${data.write.thresholds.p95}ms` },
    ],
    valueFormat: (v) => String(Math.round(v * 100) / 100),
  });
  fs.writeFileSync(path.join(REPORT_DIR, 'latency-percentiles.svg'), `${latencySvg}\n`);

  const errMax = Math.max(
    data.read.errorRate, data.write.errorRate, 0.1
  ) * 1.6;

  const errorSvg = barChart({
    title: '错误率（4xx / 5xx / 网络异常）',
    subtitle: '验收要求：读、写场景错误率均为 0%',
    width: 760,
    height: 440,
    groups: ['读场景', '写场景'],
    series: [
      { name: '4xx 占比', color: '#f59e0b', values: [ratio(data.read), ratio(data.write)] },
      { name: '5xx 占比', color: PALETTE.line, values: [ratio5xx(data.read), ratio5xx(data.write)] },
      { name: '网络异常占比', color: '#64748b', values: [ratioNet(data.read), ratioNet(data.write)] },
    ],
    yMax: errMax,
    yLabel: '错误率 (%)',
    thresholdLines: [{ value: 0, label: '阈值 0%' }],
    valueFormat: (v) => `${Math.round(v * 10000) / 100}%`,
  });
  fs.writeFileSync(path.join(REPORT_DIR, 'error-rate.svg'), `${errorSvg}\n`);

  console.log('[charts] 已生成 report/qps.svg, report/latency-percentiles.svg, report/error-rate.svg');
}

function ratio(result) {
  return result.requests ? ((result.statusCounts['4xx'] || 0) / result.requests) * 100 : 0;
}
function ratio5xx(result) {
  return result.requests ? ((result.statusCounts['5xx'] || 0) / result.requests) * 100 : 0;
}
function ratioNet(result) {
  return result.requests ? (result.networkErrors / result.requests) * 100 : 0;
}

main();
