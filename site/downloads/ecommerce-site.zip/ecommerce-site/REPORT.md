# 云选商城 · 电商网站 交付报告

> 工单：电商网站 — 商店 + 管理端（商品 / 购物车 / 订单 / 发货）｜工作项 #10049
> 交付形态：单服务、零第三方运行时依赖、端口 8802、数据本地持久化

---

## 一、概述

本交付物是一个可直接运行的电商网站，包含**商店前台**与**管理端**两大部分：

- **商店前台**：商品列表（卡片网格 / 分类筛选 / 关键词搜索）、商品详情、加入购物车、购物车管理（改数量 / 删除 / 合计联动）、结算下单（收货人 / 电话 / 地址校验）、下单成功页、按订单号查询订单状态与明细、取消待发货订单（库存回滚）。
- **管理端**（独立路径 `/admin`）：概览统计、商品上架 / 下架、价格与库存编辑、订单列表（按状态筛选）与「发货」状态流转。

技术特征：

| 维度 | 方案 |
| --- | --- |
| 运行时 | Node.js ≥ 18，单进程 `node:http` 服务，**零第三方运行时依赖**（`package.json` 无 dependencies） |
| 渲染 | 服务端渲染 HTML（模板字符串）+ 原生 CSS，无构建步骤、无外部 CDN，断网可用 |
| 存储 | 优先 Node 内置 `node:sqlite`（`data/shop.db`，WAL + `synchronous=NORMAL`）；Node < 22.5 时自动降级为 JSON 文件（`data/shop.json`，临时文件 + rename 原子写），**不依赖任何外部数据库服务** |
| 会话 | 购物车存服务端，HttpOnly `sid` Cookie 标识（7 天），跨浏览器互不串号 |
| 事务 | 下单在单个事务内完成「校验 → 扣库存 → 建订单 + 明细」，失败整体回滚；取消订单回滚库存 |
| 幂等 | 首次启动写入种子数据（10 商品 / 4 分类），已存在数据不被覆盖 |

---

## 二、部署路径与启动命令

- **部署路径**：`/Users/summer/delivery-verification/products/ecommerce-site/`
- **运行环境**：macOS（darwin arm64），Node.js `v25.8.1`

```bash
cd /Users/summer/delivery-verification/products/ecommerce-site

./start.sh        # 后台常驻启动：PID -> data/app.pid，日志 -> logs/app.log
./stop.sh         # 优雅停止（SIGTERM，15s 后强制 SIGKILL）
./restart.sh      # 重启
```

`start.sh` 行为：校验 Node ≥ 18 → 检查端口占用 → `nohup node src/server.js` → 轮询 `http://127.0.0.1:8802/healthz`（最多 30 秒）→ 打印访问地址。

实际启动输出（本次交付）：

```
[start] 正在启动 ecommerce-site ...
[start] 启动成功： http://localhost:8802/
[start] 管理端：    http://localhost:8802/admin
[start] PID: 58532   日志: /Users/summer/delivery-verification/products/ecommerce-site/logs/app.log
```

环境变量：`PORT`（默认 8802）、`HOST`（默认 127.0.0.1）、`DATA_DIR`（默认 `./data`）、`ADMIN_PASSWORD`（默认空 = 管理端免登录）。

---

## 三、访问地址

| 入口 | 地址 |
| --- | --- |
| 商店前台 | **http://localhost:8802/** |
| 管理端 | **http://localhost:8802/admin** |
| 健康检查 | http://localhost:8802/healthz |

当前常驻实例返回：

```json
{"ok":true,"service":"ecommerce-site","storage":"sqlite","uptime":2,"products":10,"onSale":9,"orders":2,"pending":1,"shipped":1}
```

---

## 四、目录结构

```
ecommerce-site/
├── src/
│   ├── server.js            # HTTP 入口：路由分发、静态资源、Cookie 会话、优雅退出
│   ├── router.js            # 极简路由（支持 :param，区分 404 / 405）
│   ├── config.js            # 端口 / 路径 / 订单状态常量
│   ├── seed.js              # 种子数据（10 商品 / 4 分类）+ SVG 占位图生成
│   ├── storage/
│   │   ├── sqlite.js        # node:sqlite 存储（首选）
│   │   ├── json.js          # JSON 文件存储（降级）
│   │   └── index.js         # 存储工厂（按运行时能力选择）
│   ├── services/
│   │   ├── products.js      # 商品列表 / 详情 / 分类 / 上下架 / 改价改库存
│   │   ├── cart.js          # 加购 / 改数量 / 删除 / 合计（含数量与库存校验）
│   │   └── orders.js        # 下单 / 查询 / 发货 / 取消（收货信息校验）
│   ├── views/               # 服务端渲染视图
│   │   ├── layout.js  store.js  cart.js  checkout.js  order.js  admin.js
│   └── static/              # style.css / app.js / favicon.svg / img/p01..p10.svg
├── scripts/
│   ├── bench.js             # 零依赖压测器
│   ├── gen-charts.js        # 生成 3 张 SVG 图表
│   └── live-smoke.sh        # 针对运行中实例的全链路 HTTP 冒烟
├── test/
│   ├── unit.test.js         # 单元 + HTTP 集成测试（node --test）
│   └── e2e.js               # 端到端全链路自测（含重启持久化）
├── data/                    # shop.db / shop.json / app.pid（运行时数据）
├── logs/                    # app.log / unit-test.log / e2e.log / live-smoke.log
├── report/                  # bench-results.json + 3 张 SVG 图表
├── start.sh / stop.sh / restart.sh
├── README.md / REPORT.md / package.json
```

---

## 五、功能自测结果

### 5.1 三套自测的执行方式与结论

| 套件 | 命令 | 结论 |
| --- | --- | --- |
| 单元 + 集成测试 | `npm test`（`node --test test/unit.test.js`） | **24 / 24 通过**，0 失败 |
| 端到端全链路自测 | `npm run e2e`（`node test/e2e.js`） | **57 / 57 通过**，0 失败 |
| 运行实例真实 HTTP 冒烟 | `./scripts/live-smoke.sh`（打常驻 8802） | **17 / 17 通过**，0 失败 |

`node --test test/unit.test.js` 摘要（`logs/unit-test.log`）：

```
✔ 种子数据满足需求：10 个商品 / 4 个分类 / 价格 9.9~299 / 库存 5~100
✔ SQLite 存储：初始化与商品查询 / 幂等初始化不覆盖已有数据 / 购物车增删改
✔ SQLite 存储：下单扣库存 + 订单状态机 / 库存不足下单失败且库存不变 / 取消订单回滚库存 / 订单号唯一（连续 8 单不重复） / 统计信息
✔ JSON 存储（降级路径）：（同上 8 项）
✔ createStorage 工厂：可用时返回 SQLite，不可用时降级 JSON
✔ 商品服务：上下架与改价改库存
✔ 购物车服务：数量 / 库存 / 下架校验
✔ 收货信息校验
✔ 订单服务：空购物车不可下单 / 下单后清空购物车
✔ 路由：路径参数、404 与 405 区分
✔ HTTP 集成：session cookie + 302 + 页面渲染
ℹ tests 24   ℹ pass 24   ℹ fail 0
```

`node test/e2e.js` 摘要（`logs/e2e.log`）：

```
[1] 商店前台浏览        —— 首页 200 / 商品卡片网格 / 图片 / 名称 / 价格 / 已下架商品不可见 / 详情页 200
[2] 加入购物车        —— 加购 302、购物车数量 2、合计 398.00
[3] 修改购物车数量    —— 改数量 302、数量变 3、合计 597.00
[4] 删除购物车商品    —— 删除 302、购物车清空
[5] 结算下单          —— 结算页字段齐备、非法手机号 400 且有提示、下单 302、成功页含订单号、
                          订单号格式 NO+时间戳+4 位随机、初始状态待发货、下单后购物车清空
[6] 订单查询          —— 命中 200 且待发货、不存在订单 404
[7] 管理端            —— 概览 200、商品列表含已下架商品、订单列表含新订单、发货 302、前台查询显示已发货、
                          重复发货被状态机拒绝、下架商品前台不可见（列表 + 详情 404）、
                          改价改库存后前台同步（88.80 / 77）
[8] 取消订单回滚库存  —— 取消 302、状态已取消、库存回滚 +2
[9] 重启持久化        —— 重启后订单仍可查询、状态保持已发货、管理端订单列表完整
[e2e] 通过 57 项，失败 0 项
```

`./scripts/live-smoke.sh`（打常驻实例）实际输出（`logs/live-smoke.log`）：

```
[live-smoke] 目标地址: http://localhost:8802
  ✓ 首页可访问并返回商品列表        ✓ 首页含商品图片        ✓ 首页含商品名称
  ✓ 首页含商品价格                  ✓ 首页含商品分类        ✓ 商品详情可打开
  ✓ 加购后购物车总价联动（2 件 = 398.00）                   ✓ 改数量后总价联动（3 件 = 597.00）
  ✓ 删除后购物车为空                ✓ 下单成功并生成订单号（NO202611120544249021）
  ✓ 下单成功页展示订单号            ✓ 订单查询显示待发货    ✓ 管理端订单列表可见新订单
  ✓ 发货后前台查询显示已发货        ✓ 上架后前台出现该商品  ✓ 下架后前台不再展示该商品
  ✓ 种子商品开箱可浏览
[live-smoke] 通过 17 项，失败 0 项
```

### 5.2 验收标准逐条核对

| # | 验收标准 | 结论 | 证据 |
| --- | --- | --- | --- |
| 1 | `start.sh` 后 `http://localhost:8802/` 返回商品列表（含图片/名称/价格） | ✅ 通过 | live-smoke 前 5 项；`curl /` 返回含 `/static/img/p01.svg`、`无线蓝牙耳机`、`¥199.00`、`数码配件` 的卡片网格 |
| 2 | 详情可加购；购物车可改数量、删除，总价随数量联动 | ✅ 通过 | e2e [2][3][4]；live-smoke 合计 398.00 → 597.00 → 清空 |
| 3 | 结算表单提交后跳转成功页并展示订单号 | ✅ 通过 | e2e [5]；live-smoke 订单号 `NO202611120544249021`，格式 `NO`+14 位时间戳+4 位随机 |
| 4 | 重启服务后按订单号仍可查到订单及明细 | ✅ 通过 | e2e [9]（隔离实例重启）；**常驻实例实测**：`./restart.sh` 后再查 `NO202611120544249021` 仍返回 `badge badge-shipped` |
| 5 | 管理端上下架 / 改价改库存后前台同步变化 | ✅ 通过 | e2e [7]；live-smoke 上架后前台出现「硬壳笔记本」、下架后消失；改价 88.80 / 改库存 77 前台详情同步 |
| 6 | 管理端订单列表可见新订单，「发货」后待发货 → 已发货，前台按单号可见 | ✅ 通过 | e2e [6][7]、live-smoke 发货后查询显示「已发货」；重复发货被状态机拒绝 |
| 7 | 种子商品 ≥ 8 且含分类，启动后无需额外准备即可浏览 | ✅ 通过 | 种子 10 个商品 / 4 个分类（数码配件、家居生活、食品饮料、图书文具）；`/healthz` 返回 `products:10, onSale:9` |
| 8 | `scripts/bench.js` 可复跑，报告含 QPS/P95/P99/错误率 + 3 张 SVG 图表 | ✅ 通过 | `npm run bench` → `report/bench-results.json`；`npm run charts` → `report/qps.svg`、`report/latency-percentiles.svg`、`report/error-rate.svg` |
| 9 | 交付报告写明部署路径、启动命令、访问地址、自测结果与性能指标 | ✅ 通过 | 本文件第一 ~ 六节 |

### 5.3 订单状态机实测

```
待发货(pending) --管理端发货--> 已发货(shipped)
      |
      |--用户取消（库存回滚 +2 实测一致）--> 已取消(cancelled)
```

- 重复发货被拒绝（`INVALID_STATUS`，状态机保护）
- 取消他人订单被拒绝（`FORBIDDEN`，按 `sid` 校验归属）

---

## 六、性能测试

### 6.1 方法

- 压测器：`scripts/bench.js`，**零第三方依赖**（`node:http` + `node:child_process`），可复跑
- 被测服务：压测脚本自行拉起独立实例（`PORT=8899`，**独立数据目录**），不污染交付数据
- 指标口径：
  - `QPS = 成功请求数 ÷ 实际压测窗口秒数`
  - `P50 / P95 / P99 = 端到端响应耗时分位数（ms）`
  - `错误率 = 非 2xx/3xx 响应占比`，区分 4xx / 5xx 与网络异常
- 读场景：并发 **50**、窗口 **60 秒**、读取混合 **6 : 3 : 1**（首页列表 : 商品详情 : 订单查询）
- 写场景：并发 **10**、窗口 **30 秒**、混合「加购 → 下单 → 取消回滚库存」，数据目录隔离

### 6.2 结果

| 场景 | 请求数 | 成功 | 错误 | 错误率 | 窗口 | QPS | P50 | P95 | P99 | 最大 | 阈值 | 结论 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 读（并发 50 / 60s） | 887,016 | 887,016 | 0 | **0%** | 60.00s | **14,782.86** | 3.21ms | **4.45ms** | **6.42ms** | 92.95ms | QPS≥300 / P95≤50 / P99≤200 / 错误率 0% | ✅ PASS |
| 写（并发 10 / 30s） | 85,068 | 85,068 | 0 | **0%** | 30.02s | **2,834.18** | 3.23ms | **7.07ms** | **10.10ms** | 18.03ms | QPS≥150 / P95≤100 / P99≤500 / 错误率 0% | ✅ PASS |

- 读场景：4xx 0 / 5xx 0 / 网络异常 0
- 写场景：3xx 85,068（表单提交后 302 重定向，属预期）、4xx 0 / 5xx 0 / 网络异常 0
- 原始数据：`report/bench-results.json`（含阈值判定 `pass: true`）

### 6.3 图表（3 张，随报告交付）

| 图表 | 文件 | 内容 |
| --- | --- | --- |
| 吞吐量 | `report/qps.svg` | 读 / 写场景 QPS 柱状图，附读阈值 300、写阈值 150 虚线 |
| 延迟分位 | `report/latency-percentiles.svg` | 读 / 写场景 P50、P95、P99 分组柱状图，附 P95 阈值线（读 50ms / 写 100ms） |
| 错误率 | `report/error-rate.svg` | 按 4xx / 5xx / 网络异常拆分的错误率柱状图，附 0% 阈值线 |

复跑方式：

```bash
npm run bench      # 输出 report/bench-results.json
npm run charts     # 依据上述结果重新生成 3 张 SVG
```

---

## 七、已知限制与风险

1. **Node 版本**：SQLite 存储需 Node ≥ 22.5（内置 `node:sqlite`）；本机为 v25.8.1，走 SQLite 路径。Node 18 ~ 22.4 会自动降级为 JSON 文件存储，**功能完全一致**，仅并发写入性能低于 SQLite（实测数据以 v25.8.1 为准）。
2. **管理端鉴权**：默认免登录（演示态）。设置 `ADMIN_PASSWORD` 后，管理端需口令登录（口令存于 Cookie，未做加密与过期吊销）。
3. **无支付 / 无用户体系**：按需求澄清约定，真实支付、注册登录、多规格 SKU、优惠券运费、前后端分离 SPA 均不在范围内；订单状态仅 `待发货 / 已发货 / 已取消`。
4. **购物车会话**：购物车按 `sid` 绑定浏览器，清除 Cookie 或换浏览器即为新会话（数据不会丢失，但购物车不可见）。
5. **管理端改动即时生效**：价格与库存修改、下架操作无缓存，下一次请求即反映；无操作审计日志。
6. **压测口径**：压测在同机回环（127.0.0.1）上进行，未包含真实网络与浏览器渲染开销，绝对数值仅作同环境对比；写场景为「加购 + 下单 + 取消」三段组合流量，并非纯下单。
7. **并发写入**：SQLite 单写者模型下写场景已达 2,834 QPS（阈值 150），更高并发需迁移至独立数据库服务（超出本次「不依赖外部数据库服务」的约束）。
8. **数据重置**：停服后删除 `data/` 下的 `shop.db*` / `shop.json` 再启动即恢复为种子数据。

---

## 八、版本与提交状态

- 工作分支：`feat/ecommerce-site-20261112052843`（基线 `origin/master` @ `4c556a1`）
- **实际提交范围：无提交（0 commits）**。本产品代码位于独立交付目录 `/Users/summer/delivery-verification/products/ecommerce-site/`，不进入上游 nvm 仓库；工作区分支与 `origin/master` 指向同一 commit。
- 推送与 MR：受平台侧策略阻塞（`allowPush=false`、目标仓库清单为空、代码平台占位符未解析），详见工作项交付说明 `deliverables/10002-verification-and-delivery.md`。
