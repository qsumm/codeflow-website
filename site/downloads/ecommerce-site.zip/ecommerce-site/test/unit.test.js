'use strict';

/**
 * 单元 / 集成测试：node --test test/unit.test.js
 * 覆盖：种子数据、SQLite 存储、JSON 降级存储、商品/购物车/订单服务、路由、HTTP 集成。
 */

const test = require('node:test');
const assert = require('node:assert');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');

const { buildSeedRows, PRODUCTS, CATEGORIES } = require('../src/seed');
const { SqliteStorage } = require('../src/storage/sqlite');
const { JsonStorage } = require('../src/storage/json');
const { createStorage } = require('../src/storage');
const { ProductService } = require('../src/services/products');
const { CartService, CartError } = require('../src/services/cart');
const { OrderService, OrderError, validateReceiver } = require('../src/services/orders');
const { Router } = require('../src/router');

function tmpDir(prefix) {
  return fs.mkdtempSync(path.join(os.tmpdir(), `${prefix}-`));
}

// ---------------------------------------------------------------- 种子数据

test('种子数据满足需求：10 个商品 / 4 个分类 / 价格 9.9~299 / 库存 5~100', () => {
  const rows = buildSeedRows();
  assert.strictEqual(rows.length, 10);
  assert.deepStrictEqual([...new Set(rows.map((r) => r.category))].sort(), [...CATEGORIES].sort());
  for (const row of rows) {
    assert.ok(row.price >= 9.9 && row.price <= 299, `价格越界 ${row.name}`);
    assert.ok(row.stock >= 5 && row.stock <= 100, `库存越界 ${row.name}`);
    assert.ok(row.image.startsWith('/static/img/'), '图片路径错误');
    assert.ok(row.description.length > 0, '缺少描述');
  }
  assert.strictEqual(PRODUCTS.length, 10);
});

// ---------------------------------------------------------------- 存储（两种实现共用一套断言）

function storageSuite(name, factory) {
  test(`${name}：初始化与商品查询`, () => {
    const storage = factory();
    const all = storage.listProducts({ onSaleOnly: false });
    assert.strictEqual(all.length, 10);
    assert.strictEqual(storage.listProducts({ onSaleOnly: true }).length, 9);
    assert.ok(storage.listCategories().length >= 4);
    assert.strictEqual(storage.getProduct('p01').name, '无线蓝牙耳机');
    assert.strictEqual(storage.getProduct('nope'), null);
    assert.ok(storage.listProducts({ keyword: '耳机' }).length >= 1);
    assert.ok(storage.listProducts({ category: '数码配件' }).length >= 1);
    storage.close();
  });

  test(`${name}：幂等初始化不覆盖已有数据`, () => {
    const dir = tmpDir('seed-idem');
    const storage = factory(dir);
    storage.updateProduct('p01', { price: 1.5 });
    storage.close();
    const again = factory(dir);
    assert.strictEqual(again.getProduct('p01').price, 1.5);
    again.close();
  });

  test(`${name}：购物车增删改`, () => {
    const storage = factory();
    storage.addToCart('sid1', 'p01', 2);
    storage.addToCart('sid1', 'p01', 1);
    let cart = storage.getCart('sid1');
    assert.strictEqual(cart.length, 1);
    assert.strictEqual(cart[0].qty, 3);
    storage.updateCartQty('sid1', 'p01', 5);
    assert.strictEqual(storage.getCart('sid1')[0].qty, 5);
    storage.updateCartQty('sid1', 'p01', 0);
    assert.strictEqual(storage.getCart('sid1').length, 0);
    storage.addToCart('sid1', 'p02', 1);
    storage.removeFromCart('sid1', 'p02');
    assert.strictEqual(storage.getCart('sid1').length, 0);
    storage.close();
  });

  test(`${name}：下单扣库存 + 订单状态机`, () => {
    const storage = factory();
    const before = storage.getProduct('p01').stock;
    const order = storage.createOrder({
      sessionId: 'sid1',
      items: [{ productId: 'p01', qty: 2 }],
      receiver: '张三',
      phone: '13800138000',
      address: '北京市朝阳区',
    });
    assert.ok(/^NO\d{18}$/.test(order.orderNo), `订单号格式异常 ${order.orderNo}`);
    assert.strictEqual(order.status, 'pending');
    assert.strictEqual(order.total, 398);
    assert.strictEqual(storage.getProduct('p01').stock, before - 2);
    assert.strictEqual(storage.getOrderByNo(order.orderNo).items.length, 1);

    const shipped = storage.shipOrder(order.orderNo);
    assert.strictEqual(shipped.error, undefined);
    assert.strictEqual(storage.getOrderByNo(order.orderNo).status, 'shipped');
    assert.ok(storage.getOrderByNo(order.orderNo).shippedAt);
    assert.strictEqual(storage.shipOrder(order.orderNo).error.code, 'INVALID_STATUS');
    storage.close();
  });

  test(`${name}：库存不足下单失败且库存不变`, () => {
    const storage = factory();
    const before = storage.getProduct('p01').stock;
    assert.throws(
      () => storage.createOrder({
        sessionId: 'sid1',
        items: [{ productId: 'p01', qty: before + 5 }],
        receiver: '张三',
        phone: '13800138000',
        address: '北京市朝阳区',
      }),
      (err) => err.code === 'OUT_OF_STOCK'
    );
    assert.strictEqual(storage.getProduct('p01').stock, before);
    storage.close();
  });

  test(`${name}：取消订单回滚库存`, () => {
    const storage = factory();
    const before = storage.getProduct('p01').stock;
    const order = storage.createOrder({
      sessionId: 'sid1',
      items: [{ productId: 'p01', qty: 3 }],
      receiver: '张三',
      phone: '13800138000',
      address: '北京市朝阳区',
    });
    assert.strictEqual(storage.getProduct('p01').stock, before - 3);
    const cancelled = storage.cancelOrder(order.orderNo, 'sid1');
    assert.strictEqual(cancelled.error, undefined);
    assert.strictEqual(storage.getOrderByNo(order.orderNo).status, 'cancelled');
    assert.strictEqual(storage.getProduct('p01').stock, before);
    const forbidden = storage.cancelOrder(order.orderNo, 'other-sid');
    assert.strictEqual(forbidden.error.code, 'FORBIDDEN');
    storage.close();
  });

  test(`${name}：订单号唯一（连续 8 单不重复）`, () => {
    const storage = factory();
    const seen = new Set();
    for (let i = 0; i < 8; i += 1) {
      const order = storage.createOrder({
        sessionId: `sid${i}`,
        items: [{ productId: 'p01', qty: 1 }],
        receiver: '张三',
        phone: '13800138000',
        address: '北京市朝阳区',
      });
      assert.ok(!seen.has(order.orderNo), `订单号重复 ${order.orderNo}`);
      seen.add(order.orderNo);
    }
    storage.close();
  });

  test(`${name}：统计信息`, () => {
    const storage = factory();
    const stats = storage.stats();
    assert.strictEqual(stats.products, 10);
    assert.strictEqual(stats.onSale, 9);
    assert.strictEqual(stats.orders, 0);
    storage.close();
  });
}

storageSuite('SQLite 存储', (dir) => new SqliteStorage(dir || tmpDir('sqlite-')).init(buildSeedRows()));
storageSuite('JSON 存储（降级路径）', (dir) => new JsonStorage(dir || tmpDir('json-')).init(buildSeedRows()));

test('createStorage 工厂：可用时返回 SQLite，不可用时降级 JSON', () => {
  const storage = createStorage(tmpDir('factory-'));
  assert.ok(['sqlite', 'json'].includes(storage.kind));
  assert.strictEqual(storage.listProducts({ onSaleOnly: false }).length, 10);
  storage.close();
});

// ---------------------------------------------------------------- 服务层

function makeServices(storage) {
  const products = new ProductService(storage);
  const cart = new CartService(storage, products);
  const orders = new OrderService(storage, cart);
  return { products, cart, orders };
}

test('商品服务：上下架与改价改库存', () => {
  const storage = new SqliteStorage(tmpDir('svc-')).init(buildSeedRows());
  const { products } = makeServices(storage);
  assert.strictEqual(products.list().length, 9);
  assert.strictEqual(products.list({ onSaleOnly: false }).length, 10);
  products.toggle('p10', true);
  assert.strictEqual(products.get('p10').onSale, true);
  products.toggle('p10', false);
  assert.strictEqual(products.get('p10').onSale, false);
  products.update('p01', { price: 88.5, stock: 12 });
  assert.strictEqual(products.get('p01').price, 88.5);
  assert.strictEqual(products.get('p01').stock, 12);
  storage.close();
});

test('购物车服务：数量 / 库存 / 下架校验', () => {
  const storage = new SqliteStorage(tmpDir('cart-')).init(buildSeedRows());
  const { cart } = makeServices(storage);
  cart.add('sid1', 'p01', 2);
  assert.strictEqual(cart.list('sid1').count, 2);
  assert.strictEqual(cart.list('sid1').total, 398);
  assert.throws(() => cart.add('sid1', 'nope', 1), CartError);
  assert.throws(() => cart.add('sid1', 'p10', 1), (e) => e.code === 'PRODUCT_UNLISTED');
  assert.throws(() => cart.add('sid1', 'p01', 0), (e) => e.code === 'INVALID_QTY');
  assert.throws(() => cart.add('sid1', 'p01', 100), (e) => e.code === 'INVALID_QTY');
  assert.throws(() => cart.add('sid1', 'p01', 50), (e) => e.code === 'OUT_OF_STOCK');
  cart.update('sid1', 'p01', 3);
  assert.strictEqual(cart.list('sid1').count, 3);
  cart.remove('sid1', 'p01');
  assert.strictEqual(cart.list('sid1').count, 0);
  storage.close();
});

test('收货信息校验', () => {
  assert.throws(() => validateReceiver({ receiver: '', phone: '13800138000', address: 'x' }), OrderError);
  assert.throws(() => validateReceiver({ receiver: '张三', phone: '123', address: 'x' }), OrderError);
  assert.throws(() => validateReceiver({ receiver: '张三', phone: '13800138000', address: '' }), OrderError);
  const ok = validateReceiver({ receiver: ' 张三 ', phone: '13800138000', address: '北京市' });
  assert.strictEqual(ok.receiver, '张三');
});

test('订单服务：空购物车不可下单 / 下单后清空购物车', () => {
  const storage = new SqliteStorage(tmpDir('order-')).init(buildSeedRows());
  const { cart, orders } = makeServices(storage);
  assert.throws(() => orders.create({ sid: 'sid1', receiver: '张三', phone: '13800138000', address: '北京' }), (e) => e.code === 'EMPTY_CART');
  cart.add('sid1', 'p01', 1);
  const order = orders.create({ sid: 'sid1', receiver: '张三', phone: '13800138000', address: '北京' });
  assert.strictEqual(order.status, 'pending');
  assert.strictEqual(cart.list('sid1').count, 0);
  assert.strictEqual(orders.list('pending').length, 1);
  orders.ship(order.orderNo);
  assert.throws(() => orders.ship(order.orderNo), OrderError);
  storage.close();
});

// ---------------------------------------------------------------- 路由

test('路由：路径参数、404 与 405 区分', () => {
  const router = new Router();
  router.get('/product/:id', () => {});
  router.post('/cart/add', () => {});
  const hit = router.match('GET', '/product/p01');
  assert.strictEqual(hit.params.id, 'p01');
  assert.strictEqual(router.match('GET', '/nope'), null);
  assert.strictEqual(router.match('POST', '/product/p01').methodNotAllowed, true);
});

// ---------------------------------------------------------------- HTTP 集成

test('HTTP 集成：session cookie + 302 + 页面渲染', async () => {
  const { createServer } = require('../src/server');
  const dataDir = tmpDir('http-');
  const server = createServer({ dataDir });
  await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
  const port = server.address().port;

  const call = (method, urlPath, { body, cookie } = {}) => new Promise((resolve, reject) => {
    const payload = body === undefined ? null : new URLSearchParams(body).toString();
    const req = http.request(
      { method, path: urlPath, port, host: '127.0.0.1', headers: { ...(payload ? { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(payload) } : {}), ...(cookie ? { Cookie: cookie } : {}) } },
      (res) => {
        let text = '';
        res.setEncoding('utf8');
        res.on('data', (c) => { text += c; });
        res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: text }));
      }
    );
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });

  try {
    const home = await call('GET', '/');
    assert.strictEqual(home.status, 200);
    const setCookie = home.headers['set-cookie'][0];
    assert.ok(setCookie.includes('HttpOnly'), 'sid 应为 HttpOnly');
    const cookie = setCookie.split(';')[0];

    const detail = await call('GET', '/product/p01');
    assert.strictEqual(detail.status, 200);
    assert.ok(detail.body.includes('无线蓝牙耳机'));

    const add = await call('POST', '/cart/add', { body: { product_id: 'p01', qty: 2 }, cookie });
    assert.strictEqual(add.status, 302);

    const cart = await call('GET', '/cart', { cookie });
    assert.ok(cart.body.includes('398.00'));

    const checkout = await call('POST', '/checkout', { body: { receiver: '张三', phone: '13800138000', address: '北京市朝阳区' }, cookie });
    assert.strictEqual(checkout.status, 302);
    const orderNo = decodeURIComponent(checkout.headers.location.split('/order/success/')[1]);
    const success = await call('GET', `/order/success/${orderNo}`, { cookie });
    assert.strictEqual(success.status, 200);
    assert.ok(success.body.includes(orderNo));

    const query = await call('GET', `/order/query?order_no=${orderNo}`);
    assert.strictEqual(query.status, 200);
    assert.ok(query.body.includes('待发货'));

    const admin = await call('GET', '/admin');
    assert.strictEqual(admin.status, 200);

    const ship = await call('POST', `/admin/orders/${orderNo}/ship`);
    assert.strictEqual(ship.status, 302);
    const query2 = await call('GET', `/order/query?order_no=${orderNo}`);
    assert.ok(query2.body.includes('已发货'));

    const health = await call('GET', '/healthz');
    assert.strictEqual(health.status, 200);
    assert.strictEqual(JSON.parse(health.body).ok, true);

    const notFound = await call('GET', '/not-exist');
    assert.strictEqual(notFound.status, 404);
  } finally {
    server.close();
    server.app.storage.close();
  }
});
