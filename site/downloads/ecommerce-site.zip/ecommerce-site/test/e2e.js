'use strict';

/**
 * 端到端自测（零三方依赖，仅 node:http / node:child_process）。
 * 覆盖需求验收全链路：浏览 → 加购 → 改数量 → 删除 → 结算 → 下单 → 订单查询
 * → 管理端发货 → 查询显示已发货，并校验下架 / 改价改库存 / 取消回滚库存 / 重启持久化。
 *
 * 用法：node test/e2e.js
 */

const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const PORT = Number(process.env.E2E_PORT || 8898);
const BASE = `http://127.0.0.1:${PORT}`;
const DATA_DIR = path.join(os.tmpdir(), `ecommerce-e2e-${Date.now()}`);

let passed = 0;
let failed = 0;
const failures = [];

function check(name, condition, detail = '') {
  if (condition) {
    passed += 1;
    console.log(`  ✓ ${name}`);
  } else {
    failed += 1;
    failures.push(`${name}${detail ? ` — ${detail}` : ''}`);
    console.log(`  ✗ ${name}${detail ? ` — ${detail}` : ''}`);
  }
}

function request(method, urlPath, { body, cookie, redirect = 'manual' } = {}) {
  return new Promise((resolve, reject) => {
    const payload = body === undefined ? null : new URLSearchParams(body).toString();
    const req = http.request(
      {
        method,
        path: urlPath,
        host: '127.0.0.1',
        port: PORT,
        headers: {
          Host: `127.0.0.1:${PORT}`,
          ...(payload ? { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': Buffer.byteLength(payload) } : {}),
          ...(cookie ? { Cookie: cookie } : {}),
        },
      },
      (res) => {
        let text = '';
        res.setEncoding('utf8');
        res.on('data', (chunk) => { text += chunk; });
        res.on('end', () => {
          const result = { status: res.statusCode, headers: res.headers, body: text };
          if (redirect === 'follow' && res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            resolve(result);
            return;
          }
          resolve(result);
        });
      }
    );
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

function jar() {
  let sid = '';
  return {
    header: () => (sid ? `sid=${sid}` : ''),
    absorb(res) {
      const raw = res.headers['set-cookie'];
      if (!raw) return;
      for (const line of raw) {
        const [pair] = line.split(';');
        const [key, value] = pair.split('=');
        if (key.trim() === 'sid') sid = value.trim();
      }
    },
  };
}

let child = null;

function startServer() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const out = fs.openSync(path.join(DATA_DIR, 'server.log'), 'a');
  child = spawn(process.execPath, [path.join(ROOT, 'src', 'server.js')], {
    env: { ...process.env, PORT: String(PORT), HOST: '127.0.0.1', DATA_DIR },
    stdio: ['ignore', out, out],
  });
  return child;
}

async function waitHealthy(timeoutMs = 15000) {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    try {
      const res = await request('GET', '/healthz');
      if (res.status === 200) return true;
    } catch (_) { /* retry */ }
    await new Promise((r) => setTimeout(r, 150));
  }
  throw new Error('E2E 服务启动超时');
}

async function stopServer() {
  if (!child) return;
  const current = child;
  child = null;
  current.kill('SIGTERM');
  await new Promise((r) => setTimeout(r, 900));
}

async function main() {
  console.log(`[e2e] 数据目录（隔离）: ${DATA_DIR}`);
  startServer();
  await waitHealthy();

  const shop = jar();
  const admin = jar();

  // ---------------------------------------------------------------- 浏览
  console.log('\n[1] 商店前台浏览');
  const home = await request('GET', '/', { cookie: shop.header() });
  shop.absorb(home);
  check('首页返回 200', home.status === 200, `status=${home.status}`);
  check('首页含商品卡片网格', home.body.includes('product-grid'));
  check('首页含种子商品「无线蓝牙耳机」', home.body.includes('无线蓝牙耳机'));
  check('首页含价格显示', home.body.includes('¥'));
  check('首页展示商品图片', home.body.includes('/static/img/p01.svg'));
  check('已下架商品 p10 不出现在首页', !home.body.includes('硬壳笔记本'));

  const detail = await request('GET', '/product/p01', { cookie: shop.header() });
  check('商品详情页返回 200', detail.status === 200, `status=${detail.status}`);
  check('详情页含商品名', detail.body.includes('无线蓝牙耳机'));
  check('详情页含库存信息', detail.body.includes('库存'));

  // ---------------------------------------------------------------- 加购
  console.log('\n[2] 加入购物车');
  const add = await request('POST', '/cart/add', { body: { product_id: 'p01', qty: 2 }, cookie: shop.header() });
  shop.absorb(add);
  check('加购返回 302 重定向', add.status === 302, `status=${add.status}`);
  const cart1 = await request('GET', '/cart', { cookie: shop.header() });
  check('购物车页返回 200', cart1.status === 200);
  check('购物车含 p01 × 2', cart1.body.includes('value="2"'), '未看到数量 2');
  check('购物车合计为 398.00', cart1.body.includes('398.00'), '合计不符');

  // ---------------------------------------------------------------- 改数量
  console.log('\n[3] 修改购物车数量');
  const update = await request('POST', '/cart/update', { body: { product_id: 'p01', qty: 3 }, cookie: shop.header() });
  check('改数量返回 302', update.status === 302);
  const cart2 = await request('GET', '/cart', { cookie: shop.header() });
  check('数量已变为 3', cart2.body.includes('value="3"'), '未看到 qty=3');
  check('合计变为 597.00', cart2.body.includes('597.00'), '合计不符');

  // ---------------------------------------------------------------- 删除
  console.log('\n[4] 删除购物车商品');
  const remove = await request('POST', '/cart/remove', { body: { product_id: 'p01' }, cookie: shop.header() });
  check('删除返回 302', remove.status === 302);
  const cart3 = await request('GET', '/cart', { cookie: shop.header() });
  check('购物车已清空', cart3.body.includes('购物车还是空的'), '购物车仍有商品');

  // ---------------------------------------------------------------- 结算
  console.log('\n[5] 结算下单');
  await request('POST', '/cart/add', { body: { product_id: 'p01', qty: 1 }, cookie: shop.header() });
  const checkoutPage = await request('GET', '/checkout', { cookie: shop.header() });
  check('结算页返回 200', checkoutPage.status === 200);
  check('结算页含收货人字段', checkoutPage.body.includes('name="receiver"'));
  check('结算页含电话字段', checkoutPage.body.includes('name="phone"'));
  check('结算页含地址字段', checkoutPage.body.includes('name="address"'));

  const bad = await request('POST', '/checkout', {
    body: { receiver: '张三', phone: '123', address: '北京市朝阳区' },
    cookie: shop.header(),
  });
  check('手机号非法时返回 400', bad.status === 400, `status=${bad.status}`);
  check('非法手机号给出错误提示', bad.body.includes('手机号') || bad.body.includes('电话'));

  await request('POST', '/cart/add', { body: { product_id: 'p01', qty: 2 }, cookie: shop.header() });
  const placed = await request('POST', '/checkout', {
    body: { receiver: '张三', phone: '13800138000', address: '北京市朝阳区建国路 1 号' },
    cookie: shop.header(),
  });
  check('下单返回 302', placed.status === 302, `status=${placed.status}`);
  const location = placed.headers.location || '';
  const orderNo = decodeURIComponent(location.split('/order/success/')[1] || '');
  check('跳转至订单成功页', location.includes('/order/success/'), location);
  check('订单号格式 NO+时间戳+4 位随机', /^NO\d{14}\d{4}$/.test(orderNo), orderNo);

  const success = await request('GET', `/order/success/${encodeURIComponent(orderNo)}`, { cookie: shop.header() });
  check('订单成功页返回 200', success.status === 200);
  check('成功页展示订单号', success.body.includes(orderNo));
  check('成功页展示收货信息', success.body.includes('张三') && success.body.includes('13800138000'));
  check('成功页初始状态为待发货', success.body.includes('待发货'));

  const afterOrder = await request('GET', '/cart', { cookie: shop.header() });
  check('下单后购物车被清空', afterOrder.body.includes('购物车还是空的'));

  // ---------------------------------------------------------------- 订单查询
  console.log('\n[6] 订单查询');
  const query = await request('GET', `/order/query?order_no=${encodeURIComponent(orderNo)}`, { cookie: shop.header() });
  check('订单查询返回 200', query.status === 200);
  check('查询结果显示待发货', query.body.includes('待发货'));
  const missing = await request('GET', '/order/query?order_no=NO0000000000000000', { cookie: shop.header() });
  check('查询不存在订单返回 404', missing.status === 404, `status=${missing.status}`);

  // ---------------------------------------------------------------- 管理端
  console.log('\n[7] 管理端商品 / 订单');
  const adminHome = await request('GET', '/admin', { cookie: admin.header() });
  admin.absorb(adminHome);
  check('管理端首页返回 200', adminHome.status === 200);
  check('管理端含商品数统计', adminHome.body.includes('商品总数'));

  const adminProducts = await request('GET', '/admin/products', { cookie: admin.header() });
  check('管理端商品列表返回 200', adminProducts.status === 200);
  check('管理端商品列表含全部商品（含已下架）', adminProducts.body.includes('硬壳笔记本'));

  const adminOrders = await request('GET', '/admin/orders', { cookie: admin.header() });
  check('管理端订单列表返回 200', adminOrders.status === 200);
  check('管理端订单列表含本次订单', adminOrders.body.includes(orderNo));

  const ship = await request('POST', `/admin/orders/${encodeURIComponent(orderNo)}/ship`, { cookie: admin.header() });
  check('发货操作返回 302', ship.status === 302, `status=${ship.status}`);
  const query2 = await request('GET', `/order/query?order_no=${encodeURIComponent(orderNo)}`, { cookie: shop.header() });
  check('前台查询显示已发货', query2.body.includes('已发货'));
  const shipAgain = await request('POST', `/admin/orders/${encodeURIComponent(orderNo)}/ship`, { cookie: admin.header() });
  const query3 = await request('GET', `/order/query?order_no=${encodeURIComponent(orderNo)}`, { cookie: shop.header() });
  check('重复发货被拒绝（状态机保护）', query3.body.includes('badge badge-shipped') && !query3.body.includes('badge badge-pending'));

  // 下架 / 上架
  const unlist = await request('POST', '/admin/products/p09/toggle', { body: { on_sale: '0' }, cookie: admin.header() });
  check('下架返回 302', unlist.status === 302);
  const home2 = await request('GET', '/', { cookie: shop.header() });
  check('下架商品不再出现在首页', !home2.body.includes('每日坚果'));
  const detail404 = await request('GET', '/product/p09', { cookie: shop.header() });
  check('下架商品详情返回 404', detail404.status === 404, `status=${detail404.status}`);
  await request('POST', '/admin/products/p09/toggle', { body: { on_sale: '1' }, cookie: admin.header() });

  // 改价改库存
  const updateProduct = await request('POST', '/admin/products/p08/update', {
    body: { price: '88.80', stock: '77' },
    cookie: admin.header(),
  });
  check('改价改库存返回 302', updateProduct.status === 302);
  const detail2 = await request('GET', '/product/p08', { cookie: shop.header() });
  check('前台商品详情反映新价格', detail2.body.includes('88.80'), '价格未更新');
  check('前台商品详情反映新库存', detail2.body.includes('77'), '库存未更新');

  // ---------------------------------------------------------------- 取消订单回滚库存
  console.log('\n[8] 取消订单与库存回滚');
  await request('POST', '/cart/add', { body: { product_id: 'p02', qty: 2 }, cookie: shop.header() });
  const placed2 = await request('POST', '/checkout', {
    body: { receiver: '李四', phone: '13900139000', address: '上海市浦东新区' },
    cookie: shop.header(),
  });
  const orderNo2 = decodeURIComponent((placed2.headers.location || '').split('/order/success/')[1] || '');
  check('第二笔订单创建成功', /^NO\d{18}$/.test(orderNo2), orderNo2);
  const stockBefore = await request('GET', '/product/p02', { cookie: shop.header() });
  const cancel = await request('POST', '/order/cancel', { body: { order_no: orderNo2 }, cookie: shop.header() });
  check('取消订单返回 302', cancel.status === 302);
  const query4 = await request('GET', `/order/query?order_no=${encodeURIComponent(orderNo2)}`, { cookie: shop.header() });
  check('取消后状态为已取消', query4.body.includes('已取消'));
  const stockAfter = await request('GET', '/product/p02', { cookie: shop.header() });
  const before = Number((stockBefore.body.match(/库存[^0-9]*(\d+)/) || [])[1]);
  const after = Number((stockAfter.body.match(/库存[^0-9]*(\d+)/) || [])[1]);
  check('取消订单后库存回滚', Number.isFinite(before) && after === before + 2, `before=${before} after=${after}`);

  // ---------------------------------------------------------------- 重启持久化
  console.log('\n[9] 重启后数据持久化');
  await stopServer();
  startServer();
  await waitHealthy();
  const query5 = await request('GET', `/order/query?order_no=${encodeURIComponent(orderNo)}`, { cookie: shop.header() });
  check('重启后订单仍可查询到', query5.status === 200 && query5.body.includes(orderNo), `status=${query5.status}`);
  check('重启后订单状态保持已发货', query5.body.includes('已发货'));
  const adminOrders2 = await request('GET', '/admin/orders', { cookie: admin.header() });
  check('重启后管理端订单列表完整', adminOrders2.body.includes(orderNo) && adminOrders2.body.includes(orderNo2));

  // ---------------------------------------------------------------- 结果
  await stopServer();
  console.log(`\n[e2e] 通过 ${passed} 项，失败 ${failed} 项`);
  if (failed) {
    console.log('[e2e] 失败项：');
    failures.forEach((f) => console.log(`  - ${f}`));
  }
  process.exit(failed ? 1 : 0);
}

main().catch(async (err) => {
  console.error('[e2e] 运行失败:', err);
  await stopServer();
  process.exit(1);
});
