'use strict';

/** 商品服务：列表 / 详情 / 分类 / 上下架 / 价格库存编辑 */

const { buildSeedRows } = require('../seed');

class ProductService {
  constructor(storage) {
    this.storage = storage;
  }

  /** 前台列表：默认只返回上架商品 */
  list({ category = '', keyword = '', onSaleOnly = true } = {}) {
    return this.storage.listProducts({ onSaleOnly, category, keyword });
  }

  get(id) {
    return this.storage.getProduct(id);
  }

  categories() {
    return this.storage.listCategories();
  }

  /** 管理端：改库存与价格 */
  update(id, { name, price, stock }) {
    const patch = {};
    if (name !== undefined) patch.name = name;
    if (price !== undefined) patch.price = price;
    if (stock !== undefined) patch.stock = stock;
    return this.storage.updateProduct(id, patch);
  }

  /** 管理端：上架 / 下架 */
  toggle(id, onSale) {
    return this.storage.updateProduct(id, { onSale: onSale === undefined ? undefined : Boolean(onSale) });
  }

  /** 供测试与种子重置使用 */
  seedRows() {
    return buildSeedRows();
  }
}

module.exports = { ProductService };
