'use strict';

/** 订单服务：下单（校验 + 扣库存 + 建单）、查询、发货、取消 */

const MOBILE_RE = /^1[3-9]\d{9}$/;
const LANDLINE_RE = /^\d{7,12}$/;

class OrderError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

function validateReceiver({ receiver = '', phone = '', address = '' } = {}) {
  const name = String(receiver).trim();
  const tel = String(phone).trim();
  const addr = String(address).trim();
  if (!name) throw new OrderError('INVALID_RECEIVER', '请填写收货人姓名');
  if (name.length > 20) throw new OrderError('INVALID_RECEIVER', '收货人姓名过长（最多 20 字）');
  if (!tel) throw new OrderError('INVALID_RECEIVER', '请填写联系电话');
  if (!MOBILE_RE.test(tel) && !LANDLINE_RE.test(tel)) throw new OrderError('INVALID_RECEIVER', '联系电话格式不正确');
  if (!addr) throw new OrderError('INVALID_RECEIVER', '请填写收货地址');
  if (addr.length > 200) throw new OrderError('INVALID_RECEIVER', '收货地址过长（最多 200 字）');
  return { receiver: name, phone: tel, address: addr };
}

class OrderService {
  constructor(storage, cartService) {
    this.storage = storage;
    this.cart = cartService;
  }

  /** 下单：读取当前 session 的购物车 → 校验 → 原子建单（扣库存）→ 清空购物车 */
  create({ sid, receiver, phone, address }) {
    const info = validateReceiver({ receiver, phone, address });
    const cart = this.cart.list(sid);
    if (cart.items.length === 0) throw new OrderError('EMPTY_CART', '购物车为空，无法下单');
    const items = cart.items.map((item) => ({ productId: item.productId, qty: item.qty }));
    const order = this.storage.createOrder({ sessionId: sid, items, ...info });
    this.cart.clear(sid);
    return order;
  }

  query(orderNo) {
    return this.storage.getOrderByNo(orderNo);
  }

  list(status = '') {
    return this.storage.listOrders({ status });
  }

  ship(orderNo) {
    const result = this.storage.shipOrder(orderNo);
    if (result.error) throw new OrderError(result.error.code, result.error.message);
    return result.order;
  }

  cancel(orderNo, sid) {
    const result = this.storage.cancelOrder(orderNo, sid);
    if (result.error) throw new OrderError(result.error.code, result.error.message);
    return result.order;
  }
}

module.exports = { OrderService, OrderError, validateReceiver };
