'use strict';

/** 购物车服务：服务端 session 存储（HttpOnly sid cookie 标识） */

const MAX_QTY = 99;

class CartError extends Error {
  constructor(code, message) {
    super(message);
    this.code = code;
  }
}

class CartService {
  constructor(storage, productService) {
    this.storage = storage;
    this.products = productService;
  }

  list(sid) {
    const items = this.storage.getCart(sid).map((item) => ({
      ...item,
      subtotal: Math.round(item.price * item.qty * 100) / 100,
    }));
    const total = Math.round(items.reduce((sum, item) => sum + item.subtotal, 0) * 100) / 100;
    const count = items.reduce((sum, item) => sum + item.qty, 0);
    return { items, total, count };
  }

  add(sid, productId, qty) {
    const product = this.products.get(productId);
    if (!product) throw new CartError('PRODUCT_NOT_FOUND', '商品不存在');
    if (!product.onSale) throw new CartError('PRODUCT_UNLISTED', `商品「${product.name}」已下架`);
    const count = Math.floor(Number(qty));
    if (!Number.isInteger(count) || count < 1) throw new CartError('INVALID_QTY', '数量必须为正整数');
    if (count > MAX_QTY) throw new CartError('INVALID_QTY', `单件商品最多购买 ${MAX_QTY} 件`);
    const cart = this.list(sid);
    const inCart = cart.items.find((item) => item.productId === product.id);
    const already = inCart ? inCart.qty : 0;
    if (already + count > product.stock) {
      throw new CartError('OUT_OF_STOCK', `库存不足，剩余 ${product.stock} 件`);
    }
    this.storage.addToCart(sid, product.id, count);
    return this.list(sid);
  }

  update(sid, productId, qty) {
    const count = Math.floor(Number(qty));
    if (!Number.isInteger(count) || count < 0) throw new CartError('INVALID_QTY', '数量不合法');
    const product = this.products.get(productId);
    if (product && count > product.stock) {
      throw new CartError('OUT_OF_STOCK', `库存不足，剩余 ${product.stock} 件`);
    }
    this.storage.updateCartQty(sid, productId, count);
    return this.list(sid);
  }

  remove(sid, productId) {
    this.storage.removeFromCart(sid, productId);
    return this.list(sid);
  }

  clear(sid) {
    this.storage.clearCart(sid);
  }
}

module.exports = { CartService, CartError, MAX_QTY };
