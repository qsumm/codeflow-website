'use strict';

/**
 * SQLite 存储实现（node:sqlite DatabaseSync，Node ≥ 22.5 内置，无需任何三方依赖）。
 * 表结构遵循需求澄清 §3.3；写入使用事务，保证「扣库存 + 建订单 + 建明细」原子完成。
 */

const fs = require('fs');
const path = require('path');

const SCHEMA = `
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  price REAL NOT NULL,
  stock INTEGER NOT NULL DEFAULT 0,
  category TEXT NOT NULL,
  image TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  on_sale INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS carts (
  session_id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS cart_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id TEXT NOT NULL,
  product_id TEXT NOT NULL,
  qty INTEGER NOT NULL,
  UNIQUE(session_id, product_id)
);
CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_no TEXT NOT NULL UNIQUE,
  receiver TEXT NOT NULL,
  phone TEXT NOT NULL,
  address TEXT NOT NULL,
  total REAL NOT NULL,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  shipped_at TEXT,
  session_id TEXT
);
CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL,
  product_id TEXT NOT NULL,
  name TEXT NOT NULL,
  price REAL NOT NULL,
  qty INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_cart_items_session ON cart_items(session_id);
CREATE INDEX IF NOT EXISTS idx_orders_created ON orders(created_at);
`;

class SqliteStorage {
  constructor(dataDir) {
    this.kind = 'sqlite';
    this.dataDir = dataDir;
    this.file = path.join(dataDir, 'shop.db');
    fs.mkdirSync(dataDir, { recursive: true });
    this.db = null;
  }

  init(seedRows) {
    const { DatabaseSync } = require('node:sqlite');
    this.db = new DatabaseSync(this.file);
    this.db.exec('PRAGMA journal_mode = WAL;');
    this.db.exec('PRAGMA synchronous = NORMAL;');
    this.db.exec(SCHEMA);
    const count = this.db.prepare('SELECT COUNT(*) AS c FROM products').get().c;
    if (count === 0) {
      const insert = this.db.prepare(
        'INSERT INTO products (id, name, price, stock, category, image, description, on_sale, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
      );
      for (const row of seedRows) {
        insert.run(row.id, row.name, row.price, row.stock, row.category, row.image, row.description, row.onSale ? 1 : 0, row.createdAt);
      }
    }
    return this;
  }

  // ------------------------------------------------------------ 商品
  listProducts({ onSaleOnly = true, category = '', keyword = '' } = {}) {
    const where = [];
    const params = [];
    if (onSaleOnly) where.push('on_sale = 1');
    if (category) { where.push('category = ?'); params.push(category); }
    if (keyword) { where.push('(name LIKE ? OR description LIKE ?)'); params.push(`%${keyword}%`, `%${keyword}%`); }
    const sql = `SELECT * FROM products ${where.length ? `WHERE ${where.join(' AND ')}` : ''} ORDER BY id`;
    return this.db.prepare(sql).all(...params).map(mapProduct);
  }

  getProduct(id) {
    const row = this.db.prepare('SELECT * FROM products WHERE id = ?').get(String(id));
    return row ? mapProduct(row) : null;
  }

  listCategories() {
    return this.db.prepare('SELECT DISTINCT category FROM products ORDER BY category').all().map((r) => r.category);
  }

  updateProduct(id, patch = {}) {
    const current = this.getProduct(id);
    if (!current) return null;
    const next = {
      name: patch.name !== undefined ? String(patch.name) : current.name,
      price: patch.price !== undefined ? Number(patch.price) : current.price,
      stock: patch.stock !== undefined ? Number(patch.stock) : current.stock,
      onSale: patch.onSale !== undefined ? (patch.onSale ? 1 : 0) : (current.onSale ? 1 : 0),
    };
    this.db.prepare('UPDATE products SET name = ?, price = ?, stock = ?, on_sale = ? WHERE id = ?')
      .run(next.name, next.price, next.stock, next.onSale, String(id));
    return this.getProduct(id);
  }

  // ------------------------------------------------------------ 购物车
  ensureSession(sid) {
    this.db.prepare('INSERT OR IGNORE INTO carts (session_id, created_at) VALUES (?, ?)').run(sid, new Date().toISOString());
  }

  getCart(sid) {
    this.ensureSession(sid);
    return this.db.prepare(
      `SELECT ci.product_id AS productId, ci.qty AS qty, p.name AS name, p.price AS price, p.image AS image,
              p.category AS category, p.stock AS stock, p.on_sale AS onSale
         FROM cart_items ci JOIN products p ON p.id = ci.product_id
        WHERE ci.session_id = ? ORDER BY ci.id`
    ).all(sid).map((r) => ({ ...r, onSale: Boolean(r.onSale) }));
  }

  addToCart(sid, productId, qty) {
    this.ensureSession(sid);
    const existing = this.db.prepare('SELECT id, qty FROM cart_items WHERE session_id = ? AND product_id = ?').get(sid, String(productId));
    if (existing) {
      this.db.prepare('UPDATE cart_items SET qty = ? WHERE id = ?').run(existing.qty + qty, existing.id);
    } else {
      this.db.prepare('INSERT INTO cart_items (session_id, product_id, qty) VALUES (?, ?, ?)').run(sid, String(productId), qty);
    }
    return this.getCart(sid);
  }

  updateCartQty(sid, productId, qty) {
    if (qty <= 0) return this.removeFromCart(sid, productId);
    this.db.prepare('UPDATE cart_items SET qty = ? WHERE session_id = ? AND product_id = ?').run(qty, sid, String(productId));
    return this.getCart(sid);
  }

  removeFromCart(sid, productId) {
    this.db.prepare('DELETE FROM cart_items WHERE session_id = ? AND product_id = ?').run(sid, String(productId));
    return this.getCart(sid);
  }

  clearCart(sid) {
    this.db.prepare('DELETE FROM cart_items WHERE session_id = ?').run(sid);
  }

  // ------------------------------------------------------------ 订单
  createOrder({ sessionId, items, receiver, phone, address }) {
    const createdAt = new Date().toISOString();
    const orderNo = this.#nextOrderNo();
    const insertOrder = this.db.prepare(
      'INSERT INTO orders (order_no, receiver, phone, address, total, status, created_at, session_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    );
    const insertItem = this.db.prepare(
      'INSERT INTO order_items (order_id, product_id, name, price, qty) VALUES (?, ?, ?, ?, ?)'
    );
    const decStock = this.db.prepare('UPDATE products SET stock = stock - ? WHERE id = ?');

    this.db.exec('BEGIN IMMEDIATE');
    try {
      let total = 0;
      for (const item of items) {
        const product = this.getProduct(item.productId);
        if (!product) throw Object.assign(new Error(`商品 ${item.productId} 不存在`), { code: 'PRODUCT_NOT_FOUND' });
        if (!product.onSale) throw Object.assign(new Error(`商品「${product.name}」已下架`), { code: 'PRODUCT_UNLISTED' });
        if (product.stock < item.qty) {
          throw Object.assign(new Error(`商品「${product.name}」库存不足（剩余 ${product.stock}）`), { code: 'OUT_OF_STOCK' });
        }
        total += product.price * item.qty;
      }
      const orderResult = insertOrder.run(orderNo, receiver, phone, address, round2(total), 'pending', createdAt, sessionId || null);
      const orderId = Number(orderResult.lastInsertRowid);
      for (const item of items) {
        const product = this.getProduct(item.productId);
        insertItem.run(orderId, product.id, product.name, product.price, item.qty);
        decStock.run(item.qty, product.id);
      }
      this.db.exec('COMMIT');
      return this.getOrderByNo(orderNo);
    } catch (err) {
      this.db.exec('ROLLBACK');
      throw err;
    }
  }

  #nextOrderNo() {
    const now = new Date();
    const pad = (n, len = 2) => String(n).padStart(len, '0');
    const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
    for (let i = 0; i < 50; i += 1) {
      const tail = String(Math.floor(Math.random() * 10000)).padStart(4, '0');
      const candidate = `NO${stamp}${tail}`;
      const exists = this.db.prepare('SELECT 1 FROM orders WHERE order_no = ?').get(candidate);
      if (!exists) return candidate;
    }
    return `NO${stamp}${Date.now() % 10000}`;
  }

  listOrders({ status = '' } = {}) {
    const sql = status
      ? 'SELECT * FROM orders WHERE status = ? ORDER BY id DESC'
      : 'SELECT * FROM orders ORDER BY id DESC';
    const rows = status ? this.db.prepare(sql).all(status) : this.db.prepare(sql).all();
    return rows.map((row) => this.#hydrateOrder(row));
  }

  getOrderByNo(orderNo) {
    const row = this.db.prepare('SELECT * FROM orders WHERE order_no = ?').get(String(orderNo));
    return row ? this.#hydrateOrder(row) : null;
  }

  #hydrateOrder(row) {
    const items = this.db.prepare('SELECT product_id AS productId, name, price, qty FROM order_items WHERE order_id = ?')
      .all(row.id);
    return {
      orderNo: row.order_no,
      items,
      total: row.total,
      receiver: row.receiver,
      phone: row.phone,
      address: row.address,
      status: row.status,
      createdAt: row.created_at,
      shippedAt: row.shipped_at,
      sessionId: row.session_id,
    };
  }

  shipOrder(orderNo) {
    const order = this.getOrderByNo(orderNo);
    if (!order) return { error: { code: 'ORDER_NOT_FOUND', message: '订单不存在' } };
    if (order.status !== 'pending') return { error: { code: 'INVALID_STATUS', message: `当前状态「${order.status}」不能发货` } };
    const shippedAt = new Date().toISOString();
    this.db.prepare('UPDATE orders SET status = ?, shipped_at = ? WHERE order_no = ?').run('shipped', shippedAt, String(orderNo));
    return { order: this.getOrderByNo(orderNo) };
  }

  cancelOrder(orderNo, sessionId) {
    const order = this.getOrderByNo(orderNo);
    if (!order) return { error: { code: 'ORDER_NOT_FOUND', message: '订单不存在' } };
    if (sessionId && order.sessionId && order.sessionId !== sessionId) {
      return { error: { code: 'FORBIDDEN', message: '只能取消本人的订单' } };
    }
    if (order.status !== 'pending') return { error: { code: 'INVALID_STATUS', message: '只有待发货订单可以取消' } };
    const items = this.db.prepare('SELECT product_id AS productId, qty FROM order_items WHERE order_id = (SELECT id FROM orders WHERE order_no = ?)').all(String(orderNo));
    this.db.exec('BEGIN IMMEDIATE');
    try {
      for (const item of items) {
        this.db.prepare('UPDATE products SET stock = stock + ? WHERE id = ?').run(item.qty, item.productId);
      }
      this.db.prepare('UPDATE orders SET status = ? WHERE order_no = ?').run('cancelled', String(orderNo));
      this.db.exec('COMMIT');
    } catch (err) {
      this.db.exec('ROLLBACK');
      throw err;
    }
    return { order: this.getOrderByNo(orderNo) };
  }

  stats() {
    const products = this.db.prepare('SELECT COUNT(*) AS c FROM products').get().c;
    const onSale = this.db.prepare('SELECT COUNT(*) AS c FROM products WHERE on_sale = 1').get().c;
    const orders = this.db.prepare('SELECT COUNT(*) AS c FROM orders').get().c;
    const pending = this.db.prepare('SELECT COUNT(*) AS c FROM orders WHERE status = ?').get('pending').c;
    const shipped = this.db.prepare('SELECT COUNT(*) AS c FROM orders WHERE status = ?').get('shipped').c;
    return { products, onSale, orders, pending, shipped };
  }

  close() {
    if (this.db) this.db.close();
  }
}

function mapProduct(row) {
  return {
    id: row.id,
    name: row.name,
    price: row.price,
    stock: row.stock,
    category: row.category,
    image: row.image,
    description: row.description,
    onSale: Boolean(row.on_sale),
    createdAt: row.created_at,
  };
}

function round2(value) {
  return Math.round(value * 100) / 100;
}

module.exports = { SqliteStorage };
