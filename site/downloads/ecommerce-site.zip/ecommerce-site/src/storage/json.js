'use strict';

/**
 * JSON 文件存储实现（node:sqlite 不可用时的降级路径，功能与 SQLite 版本一致）。
 * 单文件 shop.json，原子写（临时文件 + rename）。
 */

const fs = require('fs');
const path = require('path');

function round2(value) {
  return Math.round(value * 100) / 100;
}

class JsonStorage {
  constructor(dataDir) {
    this.kind = 'json';
    this.dataDir = dataDir;
    this.file = path.join(dataDir, 'shop.json');
    fs.mkdirSync(dataDir, { recursive: true });
    this.db = { products: [], carts: {}, orders: [], orderItems: [] };
    this.nextOrderId = 1;
    this.nextCartItemId = 1;
  }

  init(seedRows) {
    if (fs.existsSync(this.file)) {
      try {
        const parsed = JSON.parse(fs.readFileSync(this.file, 'utf8'));
        if (parsed && Array.isArray(parsed.products)) {
          this.db = {
            products: parsed.products,
            carts: parsed.carts || {},
            orders: parsed.orders || [],
            orderItems: parsed.orderItems || [],
          };
          this.nextOrderId = this.db.orders.reduce((max, o) => Math.max(max, o.id || 0), 0) + 1;
          this.nextCartItemId = this.db.orderItems.reduce((max, o) => Math.max(max, o.id || 0), 0) + 1;
          return this;
        }
      } catch (err) {
        try { fs.renameSync(this.file, `${this.file}.broken-${Date.now()}`); } catch (_) { /* ignore */ }
      }
    }
    this.db.products = seedRows.map((row) => ({ ...row }));
    this.#save();
    return this;
  }

  #save() {
    const tmp = `${this.file}.tmp-${process.pid}`;
    fs.writeFileSync(tmp, `${JSON.stringify(this.db, null, 2)}\n`, 'utf8');
    fs.renameSync(tmp, this.file);
  }

  // ------------------------------------------------------------ 商品
  listProducts({ onSaleOnly = true, category = '', keyword = '' } = {}) {
    const kw = String(keyword || '').trim().toLowerCase();
    return this.db.products
      .filter((p) => (onSaleOnly ? p.onSale : true))
      .filter((p) => (category ? p.category === category : true))
      .filter((p) => (kw ? `${p.name}${p.description}`.toLowerCase().includes(kw) : true))
      .map((p) => ({ ...p }));
  }

  getProduct(id) {
    const found = this.db.products.find((p) => p.id === String(id));
    return found ? { ...found } : null;
  }

  listCategories() {
    return [...new Set(this.db.products.map((p) => p.category))].sort();
  }

  updateProduct(id, patch = {}) {
    const product = this.db.products.find((p) => p.id === String(id));
    if (!product) return null;
    if (patch.name !== undefined) product.name = String(patch.name);
    if (patch.price !== undefined) product.price = Number(patch.price);
    if (patch.stock !== undefined) product.stock = Number(patch.stock);
    if (patch.onSale !== undefined) product.onSale = Boolean(patch.onSale);
    this.#save();
    return { ...product };
  }

  // ------------------------------------------------------------ 购物车
  ensureSession(sid) {
    if (!this.db.carts[sid]) this.db.carts[sid] = { createdAt: new Date().toISOString(), items: [] };
    return this.db.carts[sid];
  }

  getCart(sid) {
    const cart = this.ensureSession(sid);
    const rows = [];
    for (const item of cart.items) {
      const product = this.db.products.find((p) => p.id === item.productId);
      if (!product) continue;
      rows.push({
        productId: product.id,
        qty: item.qty,
        name: product.name,
        price: product.price,
        image: product.image,
        category: product.category,
        stock: product.stock,
        onSale: product.onSale,
      });
    }
    return rows;
  }

  addToCart(sid, productId, qty) {
    const cart = this.ensureSession(sid);
    const existing = cart.items.find((i) => i.productId === String(productId));
    if (existing) existing.qty += qty;
    else cart.items.push({ id: this.nextCartItemId++, productId: String(productId), qty });
    this.#save();
    return this.getCart(sid);
  }

  updateCartQty(sid, productId, qty) {
    const cart = this.ensureSession(sid);
    const item = cart.items.find((i) => i.productId === String(productId));
    if (!item) return this.getCart(sid);
    if (qty <= 0) return this.removeFromCart(sid, productId);
    item.qty = qty;
    this.#save();
    return this.getCart(sid);
  }

  removeFromCart(sid, productId) {
    const cart = this.ensureSession(sid);
    cart.items = cart.items.filter((i) => i.productId !== String(productId));
    this.#save();
    return this.getCart(sid);
  }

  clearCart(sid) {
    const cart = this.ensureSession(sid);
    cart.items = [];
    this.#save();
  }

  // ------------------------------------------------------------ 订单
  createOrder({ sessionId, items, receiver, phone, address }) {
    const createdAt = new Date().toISOString();
    const orderNo = this.#nextOrderNo();
    const detail = [];
    let total = 0;
    for (const item of items) {
      const product = this.db.products.find((p) => p.id === String(item.productId));
      if (!product) throw Object.assign(new Error(`商品 ${item.productId} 不存在`), { code: 'PRODUCT_NOT_FOUND' });
      if (!product.onSale) throw Object.assign(new Error(`商品「${product.name}」已下架`), { code: 'PRODUCT_UNLISTED' });
      if (product.stock < item.qty) {
        throw Object.assign(new Error(`商品「${product.name}」库存不足（剩余 ${product.stock}）`), { code: 'OUT_OF_STOCK' });
      }
      detail.push({ productId: product.id, name: product.name, price: product.price, qty: item.qty });
      total += product.price * item.qty;
    }
    const order = {
      id: this.nextOrderId++,
      orderNo,
      receiver,
      phone,
      address,
      total: round2(total),
      status: 'pending',
      createdAt,
      shippedAt: null,
      sessionId: sessionId || null,
    };
    for (const item of detail) {
      const product = this.db.products.find((p) => p.id === item.productId);
      product.stock -= item.qty;
      this.db.orderItems.push({ id: this.nextCartItemId++, orderId: order.id, productId: item.productId, name: item.name, price: item.price, qty: item.qty });
    }
    this.db.orders.push(order);
    this.#save();
    return this.getOrderByNo(orderNo);
  }

  #nextOrderNo() {
    const now = new Date();
    const pad = (n, len = 2) => String(n).padStart(len, '0');
    const stamp = `${now.getFullYear()}${pad(now.getMonth() + 1)}${pad(now.getDate())}${pad(now.getHours())}${pad(now.getMinutes())}${pad(now.getSeconds())}`;
    for (let i = 0; i < 50; i += 1) {
      const candidate = `NO${stamp}${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`;
      if (!this.db.orders.some((o) => o.orderNo === candidate)) return candidate;
    }
    return `NO${stamp}${Date.now() % 10000}`;
  }

  #hydrate(order) {
    return {
      orderNo: order.orderNo,
      items: this.db.orderItems.filter((i) => i.orderId === order.id).map((i) => ({ productId: i.productId, name: i.name, price: i.price, qty: i.qty })),
      total: order.total,
      receiver: order.receiver,
      phone: order.phone,
      address: order.address,
      status: order.status,
      createdAt: order.createdAt,
      shippedAt: order.shippedAt,
      sessionId: order.sessionId,
    };
  }

  listOrders({ status = '' } = {}) {
    return this.db.orders
      .filter((o) => (status ? o.status === status : true))
      .sort((a, b) => b.id - a.id)
      .map((o) => this.#hydrate(o));
  }

  getOrderByNo(orderNo) {
    const order = this.db.orders.find((o) => o.orderNo === String(orderNo));
    return order ? this.#hydrate(order) : null;
  }

  shipOrder(orderNo) {
    const order = this.db.orders.find((o) => o.orderNo === String(orderNo));
    if (!order) return { error: { code: 'ORDER_NOT_FOUND', message: '订单不存在' } };
    if (order.status !== 'pending') return { error: { code: 'INVALID_STATUS', message: `当前状态「${order.status}」不能发货` } };
    order.status = 'shipped';
    order.shippedAt = new Date().toISOString();
    this.#save();
    return { order: this.getOrderByNo(orderNo) };
  }

  cancelOrder(orderNo, sessionId) {
    const order = this.db.orders.find((o) => o.orderNo === String(orderNo));
    if (!order) return { error: { code: 'ORDER_NOT_FOUND', message: '订单不存在' } };
    if (sessionId && order.sessionId && order.sessionId !== sessionId) {
      return { error: { code: 'FORBIDDEN', message: '只能取消本人的订单' } };
    }
    if (order.status !== 'pending') return { error: { code: 'INVALID_STATUS', message: '只有待发货订单可以取消' } };
    for (const item of this.db.orderItems.filter((i) => i.orderId === order.id)) {
      const product = this.db.products.find((p) => p.id === item.productId);
      if (product) product.stock += item.qty;
    }
    order.status = 'cancelled';
    this.#save();
    return { order: this.getOrderByNo(orderNo) };
  }

  stats() {
    return {
      products: this.db.products.length,
      onSale: this.db.products.filter((p) => p.onSale).length,
      orders: this.db.orders.length,
      pending: this.db.orders.filter((o) => o.status === 'pending').length,
      shipped: this.db.orders.filter((o) => o.status === 'shipped').length,
    };
  }

  close() { /* JSON 存储无需关闭连接 */ }
}

module.exports = { JsonStorage };
