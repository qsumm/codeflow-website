'use strict';

/**
 * 存储工厂：优先使用 node:sqlite（Node ≥ 22.5），不可用时自动降级为 JSON 文件。
 * 两种实现对外暴露完全一致的接口，服务层无需感知差异。
 */

const fs = require('fs');

const { buildSeedRows } = require('../seed');

function sqliteAvailable() {
  try {
    require('node:sqlite');
    return true;
  } catch (err) {
    return false;
  }
}

/**
 * @param {string} dataDir 数据目录
 * @param {{force?: 'sqlite'|'json'}} options 强制指定实现（测试用）
 */
function createStorage(dataDir, options = {}) {
  fs.mkdirSync(dataDir, { recursive: true });
  const seedRows = buildSeedRows();

  if (options.force !== 'json') {
    try {
      const { SqliteStorage } = require('./sqlite');
      return new SqliteStorage(dataDir).init(seedRows);
    } catch (err) {
      if (options.force === 'sqlite') throw err;
      // eslint-disable-next-line no-console
      console.warn(`[storage] node:sqlite 不可用，降级为 JSON 文件存储：${err.message}`);
    }
  }
  const { JsonStorage } = require('./json');
  return new JsonStorage(dataDir).init(seedRows);
}

module.exports = { createStorage, sqliteAvailable };
