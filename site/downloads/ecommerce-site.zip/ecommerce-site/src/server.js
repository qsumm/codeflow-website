'use strict';

/**
 * HTTP 服务入口：路由分发、静态资源、购物车 session（HttpOnly sid cookie）、优雅退出。
 * 服务端渲染 HTML（模板字符串），表单以 application/x-www-form-urlencoded 提交。
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const config = require('./config');
const { Router } = require('./router');
const { createStorage } = require('./storage');
const { ProductService } = require('./services/products');
const { CartService, CartError } = require('./services/cart');
const { OrderService, OrderError } = require('./services/orders');
const { layout } = require('./views/layout');
const { homePage, productPage } = require('./views/store');
const { cartPage } = require('./views/cart');
const { checkoutPage } = require('./views/checkout');
const { successPage, queryPage } = require('./views/order');
const { adminHome, adminProducts, adminOrders } = require('./views/admin');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

// ---------------------------------------------------------------- 工具

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  for (const part of String(header).split(';')) {
    const index = part.indexOf('=');
    if (index < 0) continue;
    const key = part.slice(0, index).trim();
    const value = part.slice(index + 1).trim();
    if (key) out[key] = decodeURIComponent(value);
  }
  return out;
}

function readBody(req, limit = 256 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    req.on('data', (chunk) => {
      size += chunk.length;
      if (size > limit) {
        reject(new Error('请求体过大'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}

function parseForm(raw) {
  const form = {};
  if (!raw) return form;
  for (const [key, value] of new URLSearchParams(raw)) {
    form[key] = value;
  }
  return form;
}

function sendHtml(res, status, html, extraHeaders = {}) {
  res.writeHead(status, {
    'Content-Type': 'text/html; charset=utf-8',
    'Content-Length': Buffer.byteLength(html),
    'Cache-Control': 'no-cache',
    ...extraHeaders,
  });
  res.end(html);
}

function sendJson(res, status, body) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(payload),
    'Cache-Control': 'no-store',
  });
  res.end(payload);
}

function redirect(res, location, headers = {}) {
  res.writeHead(302, { Location: location, 'Content-Length': 0, ...headers });
  res.end();
}

function flashUrl(base, type, text) {
  const url = new URL(base, 'http://localhost');
  if (text) url.searchParams.set(type === 'error' ? 'err' : 'ok', text);
  return url.pathname + url.search;
}

// ---------------------------------------------------------------- 服务装配

function createApp(options = {}) {
  const dataDir = options.dataDir || config.DATA_DIR;
  const storage = createStorage(dataDir, options.storageOptions);
  const products = new ProductService(storage);
  const cart = new CartService(storage, products);
  const orders = new OrderService(storage, cart);
  const adminPassword = options.adminPassword !== undefined ? options.adminPassword : config.ADMIN_PASSWORD;

  const router = new Router();

  const ctx = (req, res, extra = {}) => ({
    req,
    res,
    storage,
    products,
    cart,
    orders,
    adminPassword,
    ...extra,
  });

  const cartCount = (sid) => cart.list(sid).count;

  // ---------------------------------------------------------- 商店
  router.get('/', (c) => {
    const category = c.query.get('category') || '';
    const keyword = c.query.get('q') || '';
    const list = products.list({ category, keyword });
    const page = homePage({ products: list, categories: products.categories(), activeCategory: category, keyword });
    sendHtml(c.res, 200, layout({ ...page, cartCount: cartCount(c.sid), flash: c.flash }));
  });

  router.get('/product/:id', (c) => {
    const product = products.get(c.params.id);
    if (!product || !product.onSale) {
      sendHtml(c.res, 404, layout({
        title: '商品不存在',
        body: '<h1 class="page-title">商品不存在</h1><div class="empty">该商品不存在或已下架，<a href="/" style="color:var(--brand)">返回首页</a>。</div>',
        cartCount: cartCount(c.sid),
      }));
      return;
    }
    const related = products.list({ category: product.category }).filter((p) => p.id !== product.id).slice(0, 4);
    const page = productPage({ product, related });
    sendHtml(c.res, 200, layout({ ...page, cartCount: cartCount(c.sid), flash: c.flash }));
  });

  // ---------------------------------------------------------- 购物车
  router.post('/cart/add', (c) => {
    try {
      cart.add(c.sid, c.form.product_id, c.form.qty || 1);
      redirect(c.res, flashUrl('/cart', 'ok', '已加入购物车'));
    } catch (err) {
      const message = err instanceof CartError ? err.message : '加入购物车失败';
      redirect(c.res, flashUrl('/cart', 'error', message));
    }
  });

  router.get('/cart', (c) => {
    const { items, total, count } = cart.list(c.sid);
    const page = cartPage({ items, total, count });
    sendHtml(c.res, 200, layout({ ...page, cartCount: count, flash: c.flash }));
  });

  router.post('/cart/update', (c) => {
    try {
      cart.update(c.sid, c.form.product_id, c.form.qty);
      redirect(c.res, flashUrl('/cart', 'ok', '数量已更新'));
    } catch (err) {
      const message = err instanceof CartError ? err.message : '更新失败';
      redirect(c.res, flashUrl('/cart', 'error', message));
    }
  });

  router.post('/cart/remove', (c) => {
    cart.remove(c.sid, c.form.product_id);
    redirect(c.res, flashUrl('/cart', 'ok', '已删除该商品'));
  });

  // ---------------------------------------------------------- 结算下单
  router.get('/checkout', (c) => {
    const { items, total, count } = cart.list(c.sid);
    const page = checkoutPage({ items, total, count, values: {}, error: '' });
    sendHtml(c.res, 200, layout({ ...page, cartCount: count, flash: c.flash }));
  });

  router.post('/checkout', (c) => {
    try {
      const order = orders.create({
        sid: c.sid,
        receiver: c.form.receiver,
        phone: c.form.phone,
        address: c.form.address,
      });
      redirect(c.res, `/order/success/${encodeURIComponent(order.orderNo)}`);
    } catch (err) {
      const message = err instanceof OrderError ? err.message : '下单失败，请重试';
      const { items, total, count } = cart.list(c.sid);
      const page = checkoutPage({
        items,
        total,
        count,
        values: { receiver: c.form.receiver, phone: c.form.phone, address: c.form.address },
        error: message,
      });
      sendHtml(c.res, 400, layout({ ...page, cartCount: count }));
    }
  });

  router.get('/order/success/:orderNo', (c) => {
    const order = orders.query(c.params.orderNo);
    if (!order) {
      sendHtml(c.res, 404, layout({
        title: '订单不存在',
        body: '<h1 class="page-title">订单不存在</h1><div class="empty">未找到该订单号，<a href="/order/query" style="color:var(--brand)">去订单查询</a>。</div>',
        cartCount: cartCount(c.sid),
      }));
      return;
    }
    const page = successPage({ order });
    sendHtml(c.res, 200, layout({ ...page, cartCount: cartCount(c.sid), flash: c.flash }));
  });

  router.get('/order/query', (c) => {
    const orderNo = (c.query.get('order_no') || '').trim();
    let order = null;
    let error = '';
    if (orderNo) {
      order = orders.query(orderNo);
      if (!order) error = `未找到订单号 ${orderNo}，请核对后重试。`;
    }
    const page = queryPage({ order, orderNo, error });
    sendHtml(c.res, orderNo && !order ? 404 : 200, layout({ ...page, cartCount: cartCount(c.sid), flash: c.flash }));
  });

  router.post('/order/cancel', (c) => {
    try {
      orders.cancel((c.form.order_no || '').trim(), c.sid);
      redirect(c.res, flashUrl(`/order/query?order_no=${encodeURIComponent(c.form.order_no || '')}`, 'ok', '订单已取消，库存已回滚'));
    } catch (err) {
      const message = err instanceof OrderError ? err.message : '取消失败';
      redirect(c.res, flashUrl(`/order/query?order_no=${encodeURIComponent(c.form.order_no || '')}`, 'error', message));
    }
  });

  // ---------------------------------------------------------- 管理端
  const requireAdmin = (c) => {
    if (!c.adminPassword) return true;
    return c.cookies.admin_pw === c.adminPassword;
  };

  const adminGuard = (c, next) => {
    if (requireAdmin(c)) {
      next();
      return;
    }
    const body = `
      <h1 class="page-title">管理端登录</h1>
      <p class="page-sub">该部署启用了管理口令保护（环境变量 ADMIN_PASSWORD）。</p>
      <div class="panel" style="max-width:380px">
        <div class="panel-body">
          <form method="post" action="/admin/login">
            <div class="field">
              <label for="password">管理口令</label>
              <input type="password" id="password" name="password" autocomplete="current-password">
            </div>
            <button class="btn btn-block" type="submit">登录</button>
          </form>
        </div>
      </div>`;
    sendHtml(c.res, 401, layout({ title: '管理端登录', active: 'admin', body, cartCount: cartCount(c.sid), flash: c.flash }));
  };

  router.get('/admin/login', (c) => {
    const body = `
      <h1 class="page-title">管理端登录</h1>
      <p class="page-sub">请输入管理口令。</p>
      <div class="panel" style="max-width:380px">
        <div class="panel-body">
          <form method="post" action="/admin/login">
            <div class="field">
              <label for="password">管理口令</label>
              <input type="password" id="password" name="password" autocomplete="current-password">
            </div>
            <button class="btn btn-block" type="submit">登录</button>
          </form>
        </div>
      </div>`;
    sendHtml(c.res, 200, layout({ title: '管理端登录', active: 'admin', body, cartCount: cartCount(c.sid) }));
  });

  router.post('/admin/login', (c) => {
    if (c.form.password === c.adminPassword) {
      redirect(c.res, '/admin', { 'Set-Cookie': `admin_pw=${encodeURIComponent(c.adminPassword)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${config.SESSION_MAX_AGE}` });
      return;
    }
    redirect(c.res, flashUrl('/admin/login', 'error', '管理口令不正确'));
  });

  router.get('/admin', (c) => adminGuard(c, () => {
    const page = adminHome({ stats: storage.stats() });
    sendHtml(c.res, 200, layout({ ...page, cartCount: cartCount(c.sid), flash: c.flash }));
  }));

  router.get('/admin/products', (c) => adminGuard(c, () => {
    const page = adminProducts({ products: products.list({ onSaleOnly: false }) });
    sendHtml(c.res, 200, layout({ ...page, cartCount: cartCount(c.sid), flash: c.flash }));
  }));

  router.post('/admin/products/:id/toggle', (c) => adminGuard(c, () => {
    const onSale = c.form.on_sale === '1';
    products.toggle(c.params.id, onSale);
    redirect(c.res, flashUrl('/admin/products', 'ok', onSale ? '商品已上架' : '商品已下架'));
  }));

  router.post('/admin/products/:id/update', (c) => adminGuard(c, () => {
    const price = Number(c.form.price);
    const stock = Number(c.form.stock);
    if (!Number.isFinite(price) || price <= 0) {
      redirect(c.res, flashUrl('/admin/products', 'error', '价格必须为正数'));
      return;
    }
    if (!Number.isInteger(stock) || stock < 0) {
      redirect(c.res, flashUrl('/admin/products', 'error', '库存必须为非负整数'));
      return;
    }
    products.update(c.params.id, { price: Math.round(price * 100) / 100, stock });
    redirect(c.res, flashUrl('/admin/products', 'ok', '商品已更新'));
  }));

  router.get('/admin/orders', (c) => adminGuard(c, () => {
    const status = c.query.get('status') || '';
    const page = adminOrders({ orders: orders.list(status), status });
    sendHtml(c.res, 200, layout({ ...page, cartCount: cartCount(c.sid), flash: c.flash }));
  }));

  router.post('/admin/orders/:orderNo/ship', (c) => adminGuard(c, () => {
    try {
      orders.ship(c.params.orderNo);
      redirect(c.res, flashUrl('/admin/orders', 'ok', `订单 ${c.params.orderNo} 已发货`));
    } catch (err) {
      const message = err instanceof OrderError ? err.message : '发货失败';
      redirect(c.res, flashUrl('/admin/orders', 'error', message));
    }
  }));

  // ---------------------------------------------------------- 健康检查
  router.get('/healthz', (c) => {
    sendJson(c.res, 200, {
      ok: true,
      service: 'ecommerce-site',
      storage: storage.kind,
      uptime: Math.round(process.uptime()),
      ...storage.stats(),
    });
  });

  return { router, storage, products, cart, orders };
}

// ---------------------------------------------------------------- HTTP 入口

function createServer(options = {}) {
  const app = createApp(options);

  const server = http.createServer(async (req, res) => {
    const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const pathname = decodeURIComponent(url.pathname);
    const cookies = parseCookies(req.headers.cookie);

    // 购物车 session：首次访问生成 HttpOnly sid
    let sid = cookies[config.SESSION_COOKIE];
    let setCookie = null;
    if (!sid) {
      sid = crypto.randomBytes(16).toString('hex');
      setCookie = `${config.SESSION_COOKIE}=${sid}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${config.SESSION_MAX_AGE}`;
    }
    const cookieHeaders = setCookie ? { 'Set-Cookie': setCookie } : {};
    // 先落 cookie 头，保证 302 重定向等场景也能带上 sid
    if (setCookie) res.setHeader('Set-Cookie', setCookie);

    // 静态资源
    if (pathname.startsWith('/static/')) {
      const target = path.resolve(config.STATIC_DIR, pathname.replace('/static/', ''));
      if (!target.startsWith(config.STATIC_DIR)) {
        sendHtml(res, 403, '<h1>403</h1>');
        return;
      }
      fs.readFile(target, (err, data) => {
        if (err) {
          sendHtml(res, 404, '<h1>404 资源不存在</h1>');
          return;
        }
        res.writeHead(200, {
          'Content-Type': MIME[path.extname(target).toLowerCase()] || 'application/octet-stream',
          'Content-Length': data.length,
          'Cache-Control': 'no-cache',
        });
        res.end(data);
      });
      return;
    }

    const matched = app.router.match(req.method || 'GET', pathname);
    if (!matched) {
      sendHtml(res, 404, layout({
        title: '页面不存在',
        body: `<h1 class="page-title">404</h1><div class="empty">页面不存在，<a href="/" style="color:var(--brand)">返回首页</a>。</div>`,
        cartCount: app.cart.list(sid).count,
      }));
      return;
    }
    if (matched.methodNotAllowed) {
      sendHtml(res, 405, layout({
        title: '方法不支持',
        body: '<h1 class="page-title">405</h1><div class="empty">请求方法不被支持。</div>',
        cartCount: app.cart.list(sid).count,
      }));
      return;
    }

    let form = {};
    if ((req.method || 'GET').toUpperCase() === 'POST') {
      try {
        form = parseForm(await readBody(req));
      } catch (err) {
        sendHtml(res, 413, layout({ title: '请求过大', body: '<h1 class="page-title">413</h1>' }));
        return;
      }
    }

    const flash = {};
    const okText = url.searchParams.get('ok');
    const errText = url.searchParams.get('err');
    if (okText) flash.text = okText;
    else if (errText) flash.text = errText;
    if (okText) flash.type = 'info';
    else if (errText) flash.type = 'error';

    const context = {
      req,
      res,
      sid,
      cookies,
      query: url.searchParams,
      form,
      params: matched.params,
      flash: flash.text ? flash : null,
      storage: app.storage,
      products: app.products,
      cart: app.cart,
      orders: app.orders,
      adminPassword: options.adminPassword !== undefined ? options.adminPassword : config.ADMIN_PASSWORD,
    };

    try {
      await matched.handler(context);
    } catch (err) {
      // eslint-disable-next-line no-console
      console.error('[server error]', err);
      sendHtml(res, 500, layout({
        title: '服务器错误',
        body: '<h1 class="page-title">500</h1><div class="empty">服务器内部错误，请稍后重试。</div>',
        cartCount: app.cart.list(sid).count,
      }));
    }

    // handler 已负责写响应（redirect / html / json）
  });

  server.app = app;
  return server;
}

function start() {
  const server = createServer();
  server.listen(config.PORT, config.HOST, () => {
    // eslint-disable-next-line no-console
    console.log(`[ecommerce-site] 服务已启动: http://localhost:${config.PORT}`);
    // eslint-disable-next-line no-console
    console.log(`[ecommerce-site] 管理端: http://localhost:${config.PORT}/admin  存储: ${server.app.storage.kind}`);
    // eslint-disable-next-line no-console
    console.log(`[ecommerce-site] 数据目录: ${config.DATA_DIR}`);
  });

  const shutdown = (signal) => {
    // eslint-disable-next-line no-console
    console.log(`[ecommerce-site] 收到 ${signal}，正在关闭...`);
    server.close(() => {
      try { server.app.storage.close(); } catch (_) { /* ignore */ }
      process.exit(0);
    });
    setTimeout(() => process.exit(0), 3000).unref();
  };
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  return server;
}

if (require.main === module) {
  start();
}

module.exports = { createServer, start, createApp };
