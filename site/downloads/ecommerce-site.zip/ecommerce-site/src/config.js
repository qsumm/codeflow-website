'use strict';

/**
 * 全局配置：端口、路径、环境变量。
 * 所有路径均相对于交付目录解析，保证「解压即可跑」。
 */

const path = require('path');

const ROOT_DIR = path.resolve(__dirname, '..');

function num(value, fallback) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

module.exports = {
  ROOT_DIR,
  SRC_DIR: path.join(ROOT_DIR, 'src'),
  STATIC_DIR: path.join(ROOT_DIR, 'src', 'static'),
  DATA_DIR: process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(ROOT_DIR, 'data'),
  LOG_DIR: path.join(ROOT_DIR, 'logs'),
  REPORT_DIR: path.join(ROOT_DIR, 'report'),

  PORT: num(process.env.PORT, 8802),
  HOST: process.env.HOST || '127.0.0.1',

  // 管理端口令：留空 = 免登录（演示态）；设置 ADMIN_PASSWORD 后需口令保护
  ADMIN_PASSWORD: process.env.ADMIN_PASSWORD || '',

  SESSION_COOKIE: 'sid',
  SESSION_MAX_AGE: 7 * 24 * 3600, // 7 天

  ORDER_STATUS: {
    PENDING: 'pending',
    SHIPPED: 'shipped',
    CANCELLED: 'cancelled',
  },

  ORDER_STATUS_LABEL: {
    pending: '待发货',
    shipped: '已发货',
    cancelled: '已取消',
  },
};
