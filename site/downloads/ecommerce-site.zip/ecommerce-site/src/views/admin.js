'use strict';

/** 管理端视图：概览、商品管理、订单管理（服务端渲染表单） */

const { escapeHtml, money } = require('./layout');
const { statusBadge, formatTime } = require('./order');

/** 管理端概览 */
function adminHome({ stats }) {
  const cards = [
    { label: '商品总数', value: stats.products },
    { label: '在售商品', value: stats.onSale },
    { label: '订单总数', value: stats.orders },
    { label: '待发货', value: stats.pending },
    { label: '已发货', value: stats.shipped },
  ].map((c) => `
      <div class="stat-card">
        <div class="stat-value">${c.value}</div>
        <div class="stat-label">${escapeHtml(c.label)}</div>
      </div>`).join('');

  const body = `
    <h1 class="page-title">管理端概览</h1>
    <p class="page-sub">商品上下架与库存价格、订单发货状态，均在此管理；改动会立刻反映到商店前台。</p>
    <div class="stat-grid">${cards}</div>
    <div class="admin-actions">
      <a class="btn" href="/admin/products">商品管理</a>
      <a class="btn btn-ghost" href="/admin/orders">订单管理</a>
      <a class="btn btn-ghost" href="/">返回商店</a>
    </div>
  `;
  return { title: '管理端', active: 'admin', body };
}

/** 商品管理列表 */
function adminProducts({ products }) {
  const rows = products.map((p) => `
      <tr data-product="${escapeHtml(p.id)}">
        <td>
          <img class="cart-thumb" src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" width="320" height="240">
        </td>
        <td>
          <div style="font-weight:600">${escapeHtml(p.name)}</div>
          <div style="color:var(--muted);font-size:12px">${escapeHtml(p.id)} · ${escapeHtml(p.category)}</div>
        </td>
        <td>
          <form method="post" action="/admin/products/${encodeURIComponent(p.id)}/update" class="inline-form">
            <input type="number" name="price" step="0.01" min="0.01" value="${money(p.price)}" aria-label="价格">
            <input type="number" name="stock" step="1" min="0" value="${p.stock}" aria-label="库存">
            <button class="btn btn-sm" type="submit">保存</button>
          </form>
        </td>
        <td><span class="${p.onSale ? 'badge badge-shipped' : 'badge badge-cancelled'}">${p.onSale ? '已上架' : '已下架'}</span></td>
        <td>
          <form method="post" action="/admin/products/${encodeURIComponent(p.id)}/toggle" class="inline-form">
            <input type="hidden" name="on_sale" value="${p.onSale ? '0' : '1'}">
            <button class="btn btn-ghost btn-sm" type="submit">${p.onSale ? '下架' : '上架'}</button>
          </form>
        </td>
      </tr>`).join('');

  const body = `
    <h1 class="page-title">商品管理</h1>
    <p class="page-sub">共 ${products.length} 个商品（含已下架）。改价 / 改库存点击「保存」，上下架切换即时生效。</p>
    <div class="panel">
      <div class="panel-head">
        <h2>商品列表</h2>
        <div class="right"><a class="btn btn-ghost" href="/admin">返回概览</a><a class="btn btn-ghost" href="/admin/orders">订单管理</a></div>
      </div>
      <table class="compact">
        <thead><tr><th style="width:84px">图片</th><th>商品</th><th style="width:280px">价格 / 库存</th><th style="width:90px">状态</th><th style="width:100px">操作</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>
  `;
  return { title: '商品管理', active: 'admin', body };
}

/** 订单管理列表 */
function adminOrders({ orders, status = '' }) {
  const rows = orders.map((o) => `
      <tr data-order="${escapeHtml(o.orderNo)}">
        <td style="font-family:ui-monospace,Menlo,monospace">${escapeHtml(o.orderNo)}</td>
        <td>${escapeHtml(o.receiver)}<div style="color:var(--muted);font-size:12px">${escapeHtml(o.phone)}</div></td>
        <td>${o.items.map((i) => `${escapeHtml(i.name)} × ${i.qty}`).join('、')}</td>
        <td>¥${money(o.total)}</td>
        <td>${statusBadge(o.status)}</td>
        <td style="color:var(--muted);font-size:12px">${escapeHtml(formatTime(o.createdAt))}</td>
        <td>
          ${o.status === 'pending' ? `
          <form method="post" action="/admin/orders/${encodeURIComponent(o.orderNo)}/ship" class="inline-form">
            <button class="btn btn-sm" type="submit">发货</button>
          </form>` : '<span style="color:var(--muted);font-size:12px">—</span>'}
        </td>
      </tr>`).join('');

  const filter = ['', 'pending', 'shipped', 'cancelled'].map((s) => {
    const label = { '': '全部状态', pending: '待发货', shipped: '已发货', cancelled: '已取消' }[s];
    return `<a class="chip${status === s ? ' active' : ''}" href="/admin/orders${s ? `?status=${s}` : ''}">${label}</a>`;
  }).join('');

  const body = `
    <h1 class="page-title">订单管理</h1>
    <p class="page-sub">共 ${orders.length} 笔订单。点击「发货」将订单从「待发货」流转为「已发货」，前台按单号查询即可见。</p>
    <div class="chips" style="margin-bottom:16px">${filter}</div>
    <div class="panel">
      <div class="panel-head">
        <h2>订单列表</h2>
        <div class="right"><a class="btn btn-ghost" href="/admin">返回概览</a><a class="btn btn-ghost" href="/admin/products">商品管理</a></div>
      </div>
      <table class="compact">
        <thead><tr><th style="width:180px">订单号</th><th style="width:120px">收货人</th><th>商品</th><th style="width:90px">金额</th><th style="width:90px">状态</th><th style="width:150px">下单时间</th><th style="width:90px">操作</th></tr></thead>
        <tbody>${rows || '<tr><td colspan="7" style="text-align:center;color:var(--muted);padding:36px">暂无订单</td></tr>'}</tbody>
      </table>
    </div>
  `;
  return { title: '订单管理', active: 'admin', body };
}

module.exports = { adminHome, adminProducts, adminOrders };
