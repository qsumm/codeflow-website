'use strict';

/** 视图公共部分：HTML 转义、页面骨架、导航与页脚 */

function escapeHtml(value) {
  return String(value == null ? '' : value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function money(value) {
  return Number(value || 0).toFixed(2);
}

/**
 * 页面骨架
 * @param {{title:string, active?:string, body:string, cartCount?:number, flash?:{type:string,text:string}}} options
 */
function layout({ title, active = '', body, cartCount = 0, flash = null }) {
  const navItems = [
    { key: 'home', href: '/', text: '首页' },
    { key: 'cart', href: '/cart', text: `购物车${cartCount ? ` (${cartCount})` : ''}` },
    { key: 'query', href: '/order/query', text: '订单查询' },
    { key: 'admin', href: '/admin', text: '管理端' },
  ];
  const nav = navItems
    .map((item) => `<a href="${item.href}"${item.key === active ? ' class="active"' : ''}>${escapeHtml(item.text)}</a>`)
    .join('');

  const flashHtml = flash && flash.text
    ? `<div class="alert alert-${flash.type === 'error' ? 'error' : 'info'}">${escapeHtml(flash.text)}</div>`
    : '';

  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(title)} · 云选商城</title>
<link rel="icon" href="/static/favicon.svg">
<link rel="stylesheet" href="/static/style.css">
</head>
<body>
<header class="site-header">
  <div class="header-inner">
    <a class="brand" href="/"><span class="brand-mark"></span>云选商城</a>
    <nav class="site-nav">${nav}</nav>
  </div>
</header>
<main>
${flashHtml}
${body}
</main>
<footer class="site-footer">云选商城 · 演示站点 · 端口 8802 · 服务端渲染，无外部依赖</footer>
<script src="/static/app.js" defer></script>
</body>
</html>`;
}

module.exports = { layout, escapeHtml, money };
