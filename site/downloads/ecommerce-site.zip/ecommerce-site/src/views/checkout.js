'use strict';

/** 结算视图：收货人 / 电话 / 地址表单 + 订单摘要 */

const { escapeHtml, money } = require('./layout');

function checkoutPage({ items, total, count, values = {}, error = '' }) {
  const rows = items.map((item) => `
      <tr>
        <td>${escapeHtml(item.name)} × ${item.qty}</td>
        <td style="text-align:right">¥${money(item.subtotal)}</td>
      </tr>`).join('');

  const body = `
    <h1 class="page-title">结算下单</h1>
    <p class="page-sub">填写收货信息后提交订单，提交成功会生成订单号，可用于查询订单状态。</p>
    ${error ? `<div class="alert alert-error">${escapeHtml(error)}</div>` : ''}
    ${items.length === 0 ? '<div class="empty">购物车为空，<a href="/" style="color:var(--brand)">先去选购</a>。</div>' : `
    <div class="checkout-grid">
      <div class="panel">
        <div class="panel-head"><h2>收货信息</h2></div>
        <div class="panel-body">
          <form method="post" action="/checkout">
            <div class="field">
              <label for="receiver">收货人姓名</label>
              <input type="text" id="receiver" name="receiver" maxlength="20" value="${escapeHtml(values.receiver || '')}" placeholder="请输入收货人姓名">
            </div>
            <div class="field">
              <label for="phone">联系电话</label>
              <input type="text" id="phone" name="phone" maxlength="20" value="${escapeHtml(values.phone || '')}" placeholder="手机号或固定电话">
              <div class="hint">支持 11 位手机号或 7-12 位固定电话。</div>
            </div>
            <div class="field">
              <label for="address">收货地址</label>
              <textarea id="address" name="address" rows="3" maxlength="200" placeholder="省 / 市 / 区 + 详细地址">${escapeHtml(values.address || '')}</textarea>
            </div>
            <button class="btn btn-block" type="submit">提交订单</button>
          </form>
        </div>
      </div>
      <div class="panel">
        <div class="panel-head"><h2>订单摘要</h2></div>
        <div class="panel-body">
          <table class="compact"><tbody>${rows}</tbody></table>
          <div class="summary" style="border-top:1px solid var(--line)">
            <span>应付（${count} 件）</span><span class="total">¥${money(total)}</span>
          </div>
        </div>
      </div>
    </div>`}
  `;
  return { title: '结算下单', active: 'cart', body };
}

module.exports = { checkoutPage };
