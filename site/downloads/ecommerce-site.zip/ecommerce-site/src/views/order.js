'use strict';

/** 订单视图：下单成功页 + 按订单号查询页 */

const { escapeHtml, money } = require('./layout');

const STATUS_LABEL = { pending: '待发货', shipped: '已发货', cancelled: '已取消' };
const STATUS_CLASS = { pending: 'badge badge-pending', shipped: 'badge badge-shipped', cancelled: 'badge badge-cancelled' };

function statusBadge(status) {
  return `<span class="${STATUS_CLASS[status] || 'badge'}">${escapeHtml(STATUS_LABEL[status] || status)}</span>`;
}

function orderItemsTable(order) {
  const rows = order.items.map((item) => `
      <tr>
        <td>${escapeHtml(item.name)}</td>
        <td style="text-align:right">¥${money(item.price)} × ${item.qty}</td>
        <td style="text-align:right">¥${money(item.price * item.qty)}</td>
      </tr>`).join('');
  return `<table class="compact">
      <thead><tr><th>商品</th><th style="text-align:right">单价 × 数量</th><th style="text-align:right">小计</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>`;
}

/** 下单成功页 */
function successPage({ order }) {
  const body = `
    <div class="result-card">
      <div class="result-icon">✓</div>
      <h1 style="font-size:22px;margin:6px 0 4px">下单成功</h1>
      <p class="page-sub" style="margin:0">请记录订单号，可在「订单查询」页随时查看订单状态。</p>
      <div class="order-no">${escapeHtml(order.orderNo)}</div>
      ${orderItemsTable(order)}
      <div style="display:flex;justify-content:flex-end;gap:14px;align-items:center;margin:14px 0 20px">
        <span>订单金额</span><span style="font-size:20px;font-weight:700;color:#e8590c">¥${money(order.total)}</span>
      </div>
      <dl class="kv" style="margin:0 auto;max-width:520px">
        <dt>订单状态</dt><dd>${statusBadge(order.status)}</dd>
        <dt>下单时间</dt><dd>${escapeHtml(formatTime(order.createdAt))}</dd>
        <dt>收货人</dt><dd>${escapeHtml(order.receiver)}　${escapeHtml(order.phone)}</dd>
        <dt>收货地址</dt><dd>${escapeHtml(order.address)}</dd>
      </dl>
      <div style="display:flex;gap:10px;justify-content:center;margin-top:22px;flex-wrap:wrap">
        <a class="btn" href="/order/query?order_no=${encodeURIComponent(order.orderNo)}">查询订单状态</a>
        <a class="btn btn-ghost" href="/">继续购物</a>
      </div>
    </div>
  `;
  return { title: '下单成功', active: 'query', body };
}

/** 订单查询页（?order_no= 命中时展示结果） */
function queryPage({ order = null, orderNo = '', error = '' }) {
  const resultHtml = order ? `
      <div class="panel" style="margin-top:22px">
        <div class="panel-head">
          <h2>订单 ${escapeHtml(order.orderNo)}</h2>
          <div class="right">${statusBadge(order.status)}</div>
        </div>
        <div class="panel-body">
          ${orderItemsTable(order)}
          <div style="display:flex;justify-content:flex-end;gap:14px;align-items:center;margin:14px 0 20px">
            <span>订单金额</span><span style="font-size:20px;font-weight:700;color:#e8590c">¥${money(order.total)}</span>
          </div>
          <div style="display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:26px">
            <dl class="kv">
              <dt>下单时间</dt><dd>${escapeHtml(formatTime(order.createdAt))}</dd>
              ${order.shippedAt ? `<dt>发货时间</dt><dd>${escapeHtml(formatTime(order.shippedAt))}</dd>` : ''}
              <dt>收货人</dt><dd>${escapeHtml(order.receiver)}　${escapeHtml(order.phone)}</dd>
              <dt>收货地址</dt><dd>${escapeHtml(order.address)}</dd>
            </dl>
            <div>
              <div style="font-weight:600;margin-bottom:10px">订单进度</div>
              <ul class="timeline">
                <li><div><b>待发货</b>　用户提交订单</div><div class="t">${escapeHtml(formatTime(order.createdAt))}</div></li>
                ${order.status === 'shipped' ? `<li><div><b>已发货</b>　管理员已发货</div><div class="t">${escapeHtml(formatTime(order.shippedAt || order.createdAt))}</div></li>` : ''}
                ${order.status === 'cancelled' ? '<li><div><b>已取消</b>　订单已取消，库存已回滚</div></li>' : ''}
              </ul>
              ${order.status === 'pending' ? `
              <form method="post" action="/order/cancel" class="inline-form" style="margin-top:12px">
                <input type="hidden" name="order_no" value="${escapeHtml(order.orderNo)}">
                <button class="btn btn-ghost btn-sm" type="submit" data-confirm="确认取消该订单？取消后库存将回滚。">取消订单</button>
              </form>` : ''}
            </div>
          </div>
        </div>
      </div>` : '';

  const body = `
    <h1 class="page-title">订单查询</h1>
    <p class="page-sub">输入下单成功后获得的订单号，查询订单状态与明细。</p>
    ${error ? `<div class="alert alert-error">${escapeHtml(error)}</div>` : ''}
    <div class="panel" style="max-width:640px">
      <div class="panel-body">
        <form method="get" action="/order/query">
          <div class="field">
            <label for="order_no">订单号</label>
            <input type="text" id="order_no" name="order_no" value="${escapeHtml(orderNo)}" placeholder="例如 NO202611120530001234">
            <div class="hint">订单号格式为「NO + 年月日时分秒 + 4 位数字」。</div>
          </div>
          <button class="btn" type="submit">查询订单</button>
        </form>
      </div>
    </div>
    ${resultHtml}
  `;
  return { title: '订单查询', active: 'query', body };
}

function formatTime(iso) {
  if (!iso) return '-';
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return '-';
  const pad = (n) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
}

module.exports = { successPage, queryPage, statusBadge, formatTime };
