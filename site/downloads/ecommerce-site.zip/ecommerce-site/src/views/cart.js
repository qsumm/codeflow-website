'use strict';

/** 购物车视图：列表、改数量、删除、合计 */

const { escapeHtml, money } = require('./layout');

function cartPage({ items, total, count }) {
  if (!items.length) {
    return {
      title: '购物车',
      active: 'cart',
      body: `
        <h1 class="page-title">购物车</h1>
        <p class="page-sub">购物车保存在服务端会话中（HttpOnly sid cookie），换浏览器互不影响。</p>
        <div class="empty">购物车还是空的，<a href="/" style="color:var(--brand)">去逛逛</a> 挑几件好物吧。</div>
      `,
    };
  }

  const rows = items.map((item) => `
      <tr data-product="${escapeHtml(item.productId)}">
        <td><img class="cart-thumb" src="${escapeHtml(item.image)}" alt="${escapeHtml(item.name)}" width="320" height="240"></td>
        <td>
          <a href="/product/${encodeURIComponent(item.productId)}" style="font-weight:600">${escapeHtml(item.name)}</a>
          <div style="color:var(--muted);font-size:12px">${escapeHtml(item.category)} · ${escapeHtml(item.productId)}</div>
        </td>
        <td>¥${money(item.price)}</td>
        <td>
          <form method="post" action="/cart/update" class="inline-form">
            <input type="hidden" name="product_id" value="${escapeHtml(item.productId)}">
            <input class="qty-input" type="number" name="qty" min="0" max="${Math.min(99, item.stock)}" value="${item.qty}" aria-label="数量">
            <button class="btn btn-ghost btn-sm" type="submit">更新</button>
          </form>
        </td>
        <td>¥${money(item.subtotal)}</td>
        <td>
          <form method="post" action="/cart/remove" class="inline-form">
            <input type="hidden" name="product_id" value="${escapeHtml(item.productId)}">
            <button class="link-danger" type="submit">删除</button>
          </form>
        </td>
      </tr>`).join('');

  const body = `
    <h1 class="page-title">购物车</h1>
    <p class="page-sub">共 ${count} 件商品，修改数量后点击「更新」即时联动合计。</p>
    <div class="panel">
      <div class="panel-head"><h2>商品清单</h2><div class="right"><a class="btn btn-ghost" href="/">继续购物</a></div></div>
      <table class="compact">
        <thead><tr><th style="width:84px">图片</th><th>商品</th><th style="width:100px">单价</th><th style="width:160px">数量</th><th style="width:100px">小计</th><th style="width:80px">操作</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="summary">
        <span>合计（${count} 件）</span>
        <span class="total">¥${money(total)}</span>
        <a class="btn" href="/checkout">去结算</a>
      </div>
    </div>
  `;
  return { title: '购物车', active: 'cart', body };
}

module.exports = { cartPage };
