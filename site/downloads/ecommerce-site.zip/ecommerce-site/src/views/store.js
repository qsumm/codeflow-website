'use strict';

/** 商店视图：首页商品列表（响应式卡片网格）与商品详情页 */

const { escapeHtml, money } = require('./layout');

/**
 * 首页
 * @param {{products:Array, categories:Array, activeCategory:string, keyword:string}} options
 */
function homePage({ products, categories, activeCategory = '', keyword = '' }) {
  const chips = [`<a class="chip${activeCategory ? '' : ' active'}" href="/">全部</a>`]
    .concat(categories.map((c) => `<a class="chip${activeCategory === c ? ' active' : ''}" href="/?category=${encodeURIComponent(c)}">${escapeHtml(c)}</a>`))
    .join('');

  const cards = products.map((p) => `
      <article class="card" data-product="${escapeHtml(p.id)}">
        <a class="card-media" href="/product/${encodeURIComponent(p.id)}">
          <img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" loading="lazy" width="320" height="240">
        </a>
        <div class="card-body">
          <span class="tag">${escapeHtml(p.category)}</span>
          <h3 class="card-title"><a href="/product/${encodeURIComponent(p.id)}">${escapeHtml(p.name)}</a></h3>
          <p class="card-desc">${escapeHtml(p.description)}</p>
          <div class="card-price">¥${money(p.price)}<small>库存 ${p.stock}</small></div>
          <div class="card-actions">
            <form method="post" action="/cart/add" class="inline-form">
              <input type="hidden" name="product_id" value="${escapeHtml(p.id)}">
              <input type="hidden" name="qty" value="1">
              <button class="btn" type="submit"${p.stock <= 0 ? ' disabled' : ''}>加入购物车</button>
            </form>
            <a class="btn btn-ghost" href="/product/${encodeURIComponent(p.id)}">详情</a>
          </div>
        </div>
      </article>`).join('');

  const body = `
    <h1 class="page-title">全部商品</h1>
    <p class="page-sub">共 ${products.length} 件在售商品，支持按分类与关键词筛选。</p>
    <form class="toolbar" method="get" action="/">
      <div class="search">
        <input type="search" name="q" value="${escapeHtml(keyword)}" placeholder="搜索商品名称 / 描述" aria-label="搜索商品">
      </div>
      <div class="chips">${chips}</div>
      ${activeCategory ? `<input type="hidden" name="category" value="${escapeHtml(activeCategory)}">` : ''}
      <button class="btn btn-ghost" type="submit">筛选</button>
    </form>
    ${products.length ? `<div class="product-grid">${cards}</div>` : '<div class="empty">没有匹配的商品，换个关键词或分类试试。</div>'}
  `;
  return { title: '首页', active: 'home', body };
}

/**
 * 商品详情
 * @param {{product:Object, related:Array}} options
 */
function productPage({ product, related = [] }) {
  const relatedCards = related.map((p) => `
      <article class="card">
        <a class="card-media" href="/product/${encodeURIComponent(p.id)}">
          <img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" loading="lazy" width="320" height="240">
        </a>
        <div class="card-body">
          <span class="tag">${escapeHtml(p.category)}</span>
          <h3 class="card-title"><a href="/product/${encodeURIComponent(p.id)}">${escapeHtml(p.name)}</a></h3>
          <div class="card-price">¥${money(p.price)}</div>
        </div>
      </article>`).join('');

  const body = `
    <div class="breadcrumb"><a href="/">首页</a> / <span>${escapeHtml(product.category)}</span> / <span>${escapeHtml(product.name)}</span></div>
    <div class="detail">
      <div class="detail-media"><img src="${escapeHtml(product.image)}" alt="${escapeHtml(product.name)}" width="320" height="240"></div>
      <div>
        <span class="tag">${escapeHtml(product.category)}</span>
        <h1>${escapeHtml(product.name)}</h1>
        <div class="price">¥${money(product.price)}</div>
        <div class="detail-meta">
          <span>库存 <b>${product.stock}</b></span>
          <span>商品编号 <b>${escapeHtml(product.id)}</b></span>
          <span>状态 <b>${product.onSale ? '在售' : '已下架'}</b></span>
        </div>
        <p class="desc">${escapeHtml(product.description)}</p>
        ${product.onSale ? `
        <form method="post" action="/cart/add" class="qty-row">
          <input type="hidden" name="product_id" value="${escapeHtml(product.id)}">
          <label for="qty">数量</label>
          <input type="number" id="qty" name="qty" min="1" max="${Math.min(99, product.stock)}" value="1">
          <button class="btn" type="submit">加入购物车</button>
          <a class="btn btn-ghost" href="/cart">查看购物车</a>
        </form>` : '<p class="alert alert-error">该商品已下架，暂时无法购买。</p>'}
      </div>
    </div>
    ${relatedCards ? `<h2 class="page-title" style="margin-top:32px;font-size:20px">同类商品</h2><div class="product-grid">${relatedCards}</div>` : ''}
  `;
  return { title: product.name, active: 'home', body };
}

module.exports = { homePage, productPage };
