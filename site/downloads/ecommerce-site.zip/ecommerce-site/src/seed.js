'use strict';

/**
 * 种子数据：10 个商品、4 个分类，首次启动自动入库（幂等，不覆盖已有数据）。
 * 价格区间 9.9 ~ 299.0，库存 5 ~ 100；图片为本地 SVG 占位图（按分类配色）。
 */

const CATEGORIES = ['数码配件', '家居生活', '食品饮料', '图书文具'];

const PRODUCTS = [
  {
    id: 'p01', name: '无线蓝牙耳机', category: '数码配件', price: 199.0, stock: 50,
    description: '半入耳式设计，单次续航 6 小时，配合充电盒可达 30 小时，支持快速充电。',
  },
  {
    id: 'p02', name: '65W 氮化镓充电器', category: '数码配件', price: 129.0, stock: 80,
    description: '双 C 口 + 单 A 口，可为笔记本与手机同时供电，体积小巧支持折叠插脚。',
  },
  {
    id: 'p03', name: '87 键机械键盘', category: '数码配件', price: 299.0, stock: 20,
    description: '客制化热插拔轴体，PBT 双色键帽，全键无冲，附带 type-c 走线。',
  },
  {
    id: 'p04', name: '便携移动电源 20000mAh', category: '数码配件', price: 159.0, stock: 35,
    description: '22.5W 快充，自带一线式出流线与数显电量，双向 Type-C 接口。',
  },
  {
    id: 'p05', name: '陶瓷保温杯 500ml', category: '家居生活', price: 89.0, stock: 100,
    description: '316 不锈钢内胆，真空保温 12 小时，杯口防漏设计可单手开合。',
  },
  {
    id: 'p06', name: '记忆棉护颈枕', category: '家居生活', price: 139.0, stock: 45,
    description: '慢回弹记忆棉，颈椎支撑分区曲线，可拆洗亲肤枕套，附赠收纳袋。',
  },
  {
    id: 'p07', name: '香薰蜡烛礼盒', category: '家居生活', price: 79.0, stock: 60,
    description: '天然大豆蜡，无烟少灰，燃烧时长约 20 小时，附玻璃烛杯与火柴。',
  },
  {
    id: 'p08', name: '精品挂耳咖啡 10 片', category: '食品饮料', price: 59.0, stock: 90,
    description: '中浅烘焙，水洗处理，入口柔和带柑橘酸质，独立挂耳锁鲜包装。',
  },
  {
    id: 'p09', name: '每日坚果 30 包', category: '食品饮料', price: 49.9, stock: 100,
    description: '六种坚果果仁配比，独立小包每日一袋，非油炸轻烘焙。',
  },
  {
    id: 'p10', name: '硬壳笔记本 A5', category: '图书文具', price: 19.9, stock: 5,
    description: '100g 米白道林纸，180° 平摊硬壳封面，附 3 枚便签贴。',
  },
];

const CATEGORY_HUE = {
  数码配件: 214,
  家居生活: 158,
  食品饮料: 24,
  图书文具: 282,
};

/** 生成单个商品的 SVG 占位图（按分类配色 + 品类几何图形） */
function buildSvg(index, category) {
  const hue = CATEGORY_HUE[category] || 210;
  const shapes = [
    '<circle cx="160" cy="120" r="52" fill="rgba(255,255,255,.9)"/><circle cx="160" cy="120" r="20" fill="rgba(255,255,255,.55)"/>',
    '<rect x="96" y="66" width="128" height="108" rx="16" fill="rgba(255,255,255,.9)"/><rect x="140" y="46" width="40" height="24" rx="6" fill="rgba(255,255,255,.95)"/>',
    '<path d="M88 186 L160 58 L232 186 Z" fill="rgba(255,255,255,.9)"/><circle cx="160" cy="140" r="18" fill="rgba(255,255,255,.55)"/>',
    '<rect x="92" y="72" width="136" height="96" rx="12" fill="rgba(255,255,255,.9)"/><path d="M92 168 L160 108 L228 168 Z" fill="rgba(255,255,255,.55)"/>',
    '<ellipse cx="160" cy="120" rx="70" ry="44" fill="rgba(255,255,255,.9)"/><ellipse cx="160" cy="120" rx="30" ry="18" fill="rgba(255,255,255,.55)"/>',
    '<rect x="100" y="52" width="120" height="140" rx="60" fill="rgba(255,255,255,.9)"/><rect x="124" y="76" width="72" height="92" rx="36" fill="rgba(255,255,255,.55)"/>',
  ];
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="320" height="240" viewBox="0 0 320 240" role="img" aria-label="${category}">` +
    `<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">` +
    `<stop offset="0%" stop-color="hsl(${hue},70%,60%)"/><stop offset="100%" stop-color="hsl(${(hue + 38) % 360},62%,42%)"/>` +
    `</linearGradient></defs>` +
    `<rect width="320" height="240" fill="url(#bg)"/>${shapes[index % shapes.length]}</svg>`;
  return svg;
}

/** 种子商品（含图片路径与上架状态） */
function buildSeedRows() {
  return PRODUCTS.map((p, index) => ({
    id: p.id,
    name: p.name,
    price: p.price,
    stock: p.stock,
    category: p.category,
    image: `/static/img/${p.id}.svg`,
    description: p.description,
    onSale: p.id !== 'p10', // p10 预置为已下架，用于验证「下架商品前台不可见」
    createdAt: new Date().toISOString(),
  }));
}

module.exports = { CATEGORIES, PRODUCTS, CATEGORY_HUE, buildSeedRows, buildSvg };
