/* 极简前端增强：二次确认（data-confirm）与购物车数量快捷调整。
   页面主体为服务端渲染，本文件仅做渐进增强，断网/禁用 JS 也能完成下单。 */

document.addEventListener('click', (event) => {
  const target = event.target.closest('[data-confirm]');
  if (!target) return;
  const message = target.getAttribute('data-confirm');
  if (message && !window.confirm(message)) {
    event.preventDefault();
    event.stopPropagation();
  }
});

document.addEventListener('change', (event) => {
  const input = event.target.closest('.qty-input');
  if (!input) return;
  const form = input.closest('form');
  if (!form) return;
  const button = form.querySelector('button[type="submit"]');
  if (button) button.click();
});
